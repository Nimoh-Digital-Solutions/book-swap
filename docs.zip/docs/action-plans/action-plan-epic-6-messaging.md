# Action Plan — Epic 6: Messaging

> Generated: 2026-03-23
> Next unimplemented epic in order (Epics 1–5 complete).

---

## 1. Story Status Overview

| ID | Title | Priority | Status | Notes |
|----|-------|----------|--------|-------|
| US-601 | In-App Chat | P0 | ✅ Implemented | Message model, ChatConsumer WebSocket, REST API, ChatPanel UI, 34 FE + 25 BE tests |
| US-602 | Safe Meetup Location Suggestions | P1 | ✅ Implemented | MeetupLocation model with PostGIS, curated Amsterdam seed data, MeetupSuggestionPanel UI |

**Legend**: ✅ Implemented · ⚠️ Partial · ❌ Pending

---

## 2. Gaps in Previously Implemented Stories

### Gap: [WebSocket infrastructure] — ExampleConsumer still in place

- **AC not met**: The Epic 5 plan intended to replace `ExampleConsumer` with a `NotificationConsumer` but deferred it in favour of HTTP polling.
- **Evidence**: `backend/bookswap/routing.py` still routes `ws/example/` to `ExampleConsumer`. `backend/bookswap/consumers.py` contains only the echo consumer.
- **Fix needed**: Epic 6 Phase 2 replaces the example consumer with a real `ChatConsumer` at `ws/chat/{exchange_id}/`. A lightweight `NotificationConsumer` at `ws/notifications/` can also be added now (preparation for Epic 9) but is optional.

### Gap: [WsMessage types] — Frontend WebSocket types are story-generation leftovers

- **AC not met**: `frontend/src/services/websocket.types.ts` defines `WsChunkMessage`, `WsCompleteMessage`, `WsErrorMessage` — all from a story-generation template, not BookSwap chat.
- **Evidence**: The discriminated union `WsMessage` has no `chat.message`, `chat.typing`, or `chat.read` variants.
- **Fix needed**: Phase 3 of this plan extends the `WsMessage` union with chat-specific message types while keeping the generic error type.

### Gap: [Exchange status guard] — No chat-ready flag in ExchangeDetailPage

- **AC not met**: US-601 AC1 requires chat to be available only after both users accept conditions (status `active` or later). The `ExchangeDetailPage` currently shows no chat section.
- **Evidence**: `ExchangeDetailPage` renders status badges, actions, and conditions — but no chat component or "Chat with your partner" link.
- **Fix needed**: Phase 4 adds a `ChatPanel` component rendered when `exchange.status` is in `['active', 'swap_confirmed', 'completed', 'return_requested', 'returned']`, with read-only mode for terminal states.

_(No other gaps found in previously implemented stories that relate to Epic 6.)_

---

## 3. Implementation Plan — Epic 6: Messaging

### Context

Epic 6 introduces the in-app chat system that allows matched book partners to coordinate their swap meetup. Chat is unlocked only after both parties accept exchange conditions (US-503, status `active`). It uses Django Channels WebSockets for real-time message delivery and typing indicators. US-602 adds a "suggest a meetup spot" feature that queries nearby public locations (libraries, cafes, parks) based on both users' locations. This epic serves both the **book seeker** and the **book owner** once they become active exchange partners. It depends on Epic 5 being complete (exchange status machine) and enables a smoother path to Epic 7 (ratings, post-swap) by keeping all coordination in-app.

### Stories Covered

- **US-601**: In-App Chat (P0)
- **US-602**: Safe Meetup Location Suggestions (P1)

---

### Phase 1 — Data Layer: Message & MeetupLocation Models ✅ COMPLETE

> **Completed**: 2026-03-23 · **Branch**: `feat/epic-6-messaging` · **Commit**: `0f17e17`
> **Tests**: 355 BE passing · **Lint**: ruff clean

**Goal**: Create the `Message` and `MeetupLocation` models with all fields needed for the chat system and meetup suggestions, then run migrations.

**Files to create / modify**:
- `backend/apps/messaging/__init__.py` — new Django app
- `backend/apps/messaging/apps.py` — `MessagingConfig`
- `backend/apps/messaging/models.py` — `Message`, `MeetupLocation`
- `backend/apps/messaging/admin.py` — basic admin registration
- `backend/apps/messaging/migrations/0001_initial.py` — auto-generated
- `backend/config/settings/base.py` — add `'apps.messaging'` to `INSTALLED_APPS`

**What to build**:

#### 1a. `Message` Model

| Field | Type | Notes |
|-------|------|-------|
| `id` | UUIDField (PK) | `default=uuid.uuid4` |
| `exchange` | FK → ExchangeRequest | `related_name='messages'`, `on_delete=CASCADE` |
| `sender` | FK → User | `related_name='sent_messages'`, `on_delete=CASCADE` |
| `content` | TextField | Max 1000 chars (validated in serializer), the message text |
| `image` | ImageField | Optional; upload to `chat_images/`, max 5MB (validated), null/blank |
| `read_at` | DateTimeField | Null; set when recipient opens the chat and message is visible |
| `created_at` | DateTimeField | `auto_now_add=True` (via `TimeStampedModel`) |
| `updated_at` | DateTimeField | `auto_now=True` (via `TimeStampedModel`) |

**Constraints / indexes**:
```python
class Meta:
    ordering = ['created_at']
    indexes = [
        models.Index(fields=['exchange', 'created_at'], name='msg_exchange_created'),
        models.Index(fields=['sender', 'created_at'], name='msg_sender_created'),
    ]
```

**Validation**:
- At least one of `content` or `image` must be provided (model-level `clean()` or serializer validation)
- `content` max 1000 characters
- `image` max 5MB, JPEG/PNG only

#### 1b. `MeetupLocation` Model (US-602)

| Field | Type | Notes |
|-------|------|-------|
| `id` | UUIDField (PK) | `default=uuid.uuid4` |
| `name` | CharField(200) | Location name (e.g. "OBA Oosterdok") |
| `address` | CharField(300) | Street address |
| `category` | CharField(30) | Choices: `library`, `cafe`, `park`, `station` |
| `location` | PointField (PostGIS) | Spatial coordinates, `srid=4326` |
| `city` | CharField(100) | City name (e.g. "Amsterdam") |
| `is_active` | BooleanField | Default `True`; allows soft-disabling locations |
| `created_at` | DateTimeField | `auto_now_add=True` |

**Constraints / indexes**:
```python
class Meta:
    ordering = ['name']
    indexes = [
        models.Index(fields=['category', 'is_active'], name='meetup_cat_active'),
    ]
```

**Seed data**: A management command `seed_meetup_locations` that populates ~20 curated Amsterdam locations (libraries, cafes, parks, stations) with real coordinates. Can also be extended later to query Overpass/OSM dynamically.

#### 1c. Category Choices

```python
class MeetupCategory(models.TextChoices):
    LIBRARY = 'library', 'Library'
    CAFE = 'cafe', 'Cafe'
    PARK = 'park', 'Park'
    STATION = 'station', 'Train Station'
```

**Acceptance criteria addressed**: US-601 AC2 (message persistence), US-601 AC3 (read status), US-601 AC5 (image sharing), US-601 AC6 (chat history persisted), US-602 AC2–AC4 (location data)

---

### Phase 2 — Backend API: REST Endpoints & WebSocket Consumer ✅ COMPLETE

> **Completed**: 2026-03-23 · **Branch**: `feat/epic-6-messaging` · **Commit**: `4f6b196`
> **Tests**: 355 BE passing (25 new messaging tests) · **Lint**: ruff clean

**Goal**: Expose the chat data through REST endpoints for message history and mark-read, plus a Django Channels `ChatConsumer` for real-time messaging and typing indicators. Also expose meetup location suggestions.

**Files to create / modify**:
- `backend/apps/messaging/serializers.py` — `MessageSerializer`, `MessageCreateSerializer`, `MeetupLocationSerializer`, `MeetupSuggestionSerializer`
- `backend/apps/messaging/views.py` — `MessageViewSet`, `MeetupLocationViewSet`
- `backend/apps/messaging/urls.py` — register routes
- `backend/apps/messaging/permissions.py` — `IsExchangeParticipant` (reuse from exchanges or import)
- `backend/apps/messaging/consumers.py` — `ChatConsumer`
- `backend/bookswap/routing.py` — replace `ExampleConsumer` route with `ChatConsumer` route
- `backend/bookswap/consumers.py` — remove `ExampleConsumer` (or keep as reference and add chat import to routing)
- `backend/config/urls.py` — add `path('api/v1/messaging/', include('apps.messaging.urls'))`
- `backend/apps/messaging/management/commands/seed_meetup_locations.py` — seed command

**Serializers to build**:

#### 2a. `MessageSerializer` (read)

- `id`, `exchange` (UUID), `sender` (nested: id, username, avatar), `content`, `image` (URL), `read_at`, `created_at`
- Used for both list and WebSocket broadcast

#### 2b. `MessageCreateSerializer` (write)

Validates:
- `content` — optional, max 1000 chars
- `image` — optional, max 5MB, JPEG/PNG only
- At least one of `content` or `image` must be provided
- Exchange must be in a chat-eligible status: `active`, `swap_confirmed` (writable)
- Exchange must NOT be in a read-only status: `completed`, `return_requested`, `returned`, `declined`, `cancelled`, `expired`
- Sender must be a participant of the exchange

#### 2c. `MeetupLocationSerializer` (read)

- `id`, `name`, `address`, `category`, `city`, `latitude`, `longitude`, `distance_from_requester`, `distance_from_owner`
- Distance fields are annotated in the queryset

#### 2d. `MeetupSuggestionSerializer` (read)

- Wraps `MeetupLocationSerializer` with a `suggestion_text` field that formats the chat-insertable message: "How about meeting at [Name]? It's [X km] from you and [Y km] from me."

**REST Endpoints**:

| Method | Path | Auth | Description | Story |
|--------|------|------|-------------|-------|
| GET | `/api/v1/messaging/exchanges/{exchange_id}/messages/` | IsAuthenticated + IsExchangeParticipant | List messages for an exchange (paginated, oldest first) | US-601 |
| POST | `/api/v1/messaging/exchanges/{exchange_id}/messages/` | IsAuthenticated + IsExchangeParticipant | Send a message via REST fallback (also available via WS) | US-601 |
| POST | `/api/v1/messaging/exchanges/{exchange_id}/messages/mark-read/` | IsAuthenticated + IsExchangeParticipant | Mark all unread messages as read (set `read_at`) | US-601 |
| GET | `/api/v1/messaging/exchanges/{exchange_id}/meetup-suggestions/` | IsAuthenticated + IsExchangeParticipant | Get nearby meetup locations sorted by distance from midpoint | US-602 |

**WebSocket Consumer — `ChatConsumer`**:

Route: `ws/chat/{exchange_id}/`

**Connection flow**:
1. Authenticate via JWT token in query parameter (`?token=<jwt>`)
2. Validate exchange exists and status allows chat (status in `active`, `swap_confirmed`)
3. Validate user is a participant (requester or owner)
4. If status is terminal (`completed`, `returned`, `declined`, `cancelled`, `expired`): connect as read-only (can receive but not send)
5. Add to channel group `chat_{exchange_id}`
6. Accept connection

**Message types (client → server)**:

| Type | Payload | Action |
|------|---------|--------|
| `chat.message` | `{ text: string, image?: base64 }` | Validate, save to DB, broadcast to group |
| `chat.typing` | `{}` | Broadcast typing indicator to partner (not saved) |
| `chat.read` | `{ message_id: string }` | Update `read_at` on the message, notify sender |

**Message types (server → client)**:

| Type | Payload | Description |
|------|---------|-------------|
| `chat.message` | `MessageSerializer` data | New message broadcast |
| `chat.typing` | `{ user_id, display_name }` | Partner is typing |
| `chat.read` | `{ message_id, read_at }` | Message was read by recipient |
| `chat.error` | `{ message: string }` | Validation error (e.g. message too long, chat locked) |

**Rate limiting**:
- Client-side: max 5 messages per 10 seconds (US-601 EC3)
- Server-side: track per-user message count in Redis with 10-second sliding window; reject excess with `chat.error`

**Chat lock logic** (US-601 AC8):
- Chat becomes read-only after exchange status reaches `completed` AND either (a) both users have rated, or (b) 7 days after completion
- On connect, check if chat is locked: if so, send `{ type: 'chat.locked', reason: '...' }` and reject `chat.message` sends
- The lock check queries the `ratings` app (Epic 7) — if Epic 7 is not yet built, default to the 7-day timer only

**Nimoh-stack conventions to follow**:
- UUID PKs, `created_at`/`updated_at` on every model (via `TimeStampedModel`)
- `get_queryset()` scoped to exchange participants
- `permission_classes` declared explicitly on every view and action
- `select_related('sender')` on message queries to avoid N+1
- Async consumer using `AsyncJsonWebsocketConsumer` with `database_sync_to_async` for ORM calls
- Redis channel layer configured in `CHANNEL_LAYERS` setting (already present)

**Acceptance criteria addressed**: US-601 AC1–AC8, US-602 AC1–AC5

---

### Phase 3 — Frontend Services & Hooks ✅ COMPLETE

> **Completed**: 2026-03-23 · **Branch**: `feat/epic-6-messaging` · **Commit**: `c4e4841`
> **Tests**: 762 FE passing · **Lint**: ESLint clean

**Goal**: Wire the messaging API and WebSocket into the frontend data layer with TypeScript types, services, TanStack Query hooks, and Zod schemas.

**Files to create**:
- `frontend/src/features/messaging/types/messaging.types.ts` — TypeScript interfaces for Message, MeetupLocation, WS message types
- `frontend/src/features/messaging/services/messaging.service.ts` — axios wrappers for REST endpoints
- `frontend/src/features/messaging/hooks/messagingKeys.ts` — TanStack Query key factory
- `frontend/src/features/messaging/hooks/useMessages.ts` — infinite query hook (paginated message history, oldest first)
- `frontend/src/features/messaging/hooks/useSendMessage.ts` — mutation hook (REST fallback for sending)
- `frontend/src/features/messaging/hooks/useMarkMessagesRead.ts` — mutation hook
- `frontend/src/features/messaging/hooks/useMeetupSuggestions.ts` — query hook
- `frontend/src/features/messaging/hooks/useChatWebSocket.ts` — hook wrapping `useWebSocket` with chat-specific message handling, auto-append to query cache, typing state
- `frontend/src/features/messaging/schemas/messaging.schemas.ts` — Zod validation schema for message form
- `frontend/src/features/messaging/index.ts` — barrel export

**Files to modify**:
- `frontend/src/configs/apiEndpoints.ts` — add `messaging` group
- `frontend/src/services/websocket.types.ts` — extend `WsMessage` union with chat message types

**Key patterns**:

#### 3a. API Endpoints (add to `apiEndpoints.ts`)

```typescript
const MESSAGING = `${V1}/messaging` as const;

messaging: {
  messages: (exchangeId: string) => `${MESSAGING}/exchanges/${exchangeId}/messages/`,
  sendMessage: (exchangeId: string) => `${MESSAGING}/exchanges/${exchangeId}/messages/`,
  markRead: (exchangeId: string) => `${MESSAGING}/exchanges/${exchangeId}/messages/mark-read/`,
  meetupSuggestions: (exchangeId: string) => `${MESSAGING}/exchanges/${exchangeId}/meetup-suggestions/`,
},
```

#### 3b. WebSocket URL pattern

```typescript
// Constructed from VITE_WS_URL env variable
const chatWsUrl = (exchangeId: string) => `${WS_BASE}/ws/chat/${exchangeId}/`;
```

#### 3c. TypeScript Types

```typescript
export interface ChatMessage {
  id: string;
  exchange: string;
  sender: {
    id: string;
    username: string;
    avatar: string | null;
  };
  content: string;
  image: string | null;
  read_at: string | null;
  created_at: string;
}

export interface MeetupLocation {
  id: string;
  name: string;
  address: string;
  category: 'library' | 'cafe' | 'park' | 'station';
  city: string;
  latitude: number;
  longitude: number;
  distance_from_requester: number | null;
  distance_from_owner: number | null;
}

export interface MeetupSuggestion extends MeetupLocation {
  suggestion_text: string;
}
```

#### 3d. WebSocket Message Types (extend `websocket.types.ts`)

```typescript
export interface WsChatMessage {
  type: 'chat.message';
  id: string;
  exchange: string;
  sender: { id: string; username: string; avatar: string | null };
  content: string;
  image: string | null;
  read_at: string | null;
  created_at: string;
}

export interface WsChatTyping {
  type: 'chat.typing';
  user_id: string;
  display_name: string;
}

export interface WsChatRead {
  type: 'chat.read';
  message_id: string;
  read_at: string;
}

export interface WsChatLocked {
  type: 'chat.locked';
  reason: string;
}
```

#### 3e. `useChatWebSocket` Hook Design

- Connects to `ws/chat/{exchangeId}/` when `enabled` is true (exchange status is chat-eligible)
- On `chat.message`: prepend/append message to the TanStack Query infinite query cache (`messagingKeys.messages(exchangeId)`)
- On `chat.typing`: set `isPartnerTyping` state with a 3-second auto-clear timeout
- On `chat.read`: update message `read_at` in cache optimistically
- On `chat.locked`: set `isChatLocked` state (prevent sends)
- Exposes: `sendMessage(text, image?)`, `sendTyping()`, `isPartnerTyping`, `isChatLocked`, `isConnected`
- Client-side rate limit: track send timestamps, reject if > 5 in last 10 seconds

#### 3f. TanStack Query Key Factory

```typescript
export const messagingKeys = {
  all: ['messaging'] as const,
  messages: (exchangeId: string) => [...messagingKeys.all, 'messages', exchangeId] as const,
  meetupSuggestions: (exchangeId: string) => [...messagingKeys.all, 'meetup', exchangeId] as const,
};
```

**Nimoh-stack conventions to follow**:
- `credentials: 'include'` on the API client
- Key factory pattern: `messagingKeys.all()`, `.messages(exchangeId)`, `.meetupSuggestions(exchangeId)`
- No access token in localStorage — use Zustand memory store for auth
- Token passed to WebSocket via query parameter (already supported by `createWebSocket`)

**Acceptance criteria addressed**: US-601 AC2 (real-time), AC3 (read status), AC7 (typing indicator), US-602 AC5 (formatted suggestion message)

---

### Phase 4 — Frontend UI ✅ COMPLETE

> **Completed**: 2026-03-23 · **Branch**: `feat/epic-6-messaging` · **Commit**: `1a7fb90`
> **Tests**: 762 FE passing · **Lint**: ESLint clean

**Goal**: Build the chat UI components and the meetup suggestion panel that users interact with.

**Files to create**:
- `frontend/src/features/messaging/pages/ChatPage.tsx` — standalone chat page (optional, for deep-linking `/exchanges/:id/chat`)
- `frontend/src/features/messaging/components/ChatPanel/ChatPanel.tsx` — embeddable chat panel for ExchangeDetailPage
- `frontend/src/features/messaging/components/ChatPanel/ChatPanel.test.tsx` — tests
- `frontend/src/features/messaging/components/MessageBubble/MessageBubble.tsx` — individual message bubble (own vs partner styling)
- `frontend/src/features/messaging/components/MessageBubble/MessageBubble.test.tsx` — tests
- `frontend/src/features/messaging/components/MessageInput/MessageInput.tsx` — text input + image upload + send button
- `frontend/src/features/messaging/components/MessageInput/MessageInput.test.tsx` — tests
- `frontend/src/features/messaging/components/TypingIndicator/TypingIndicator.tsx` — animated dots when partner is typing
- `frontend/src/features/messaging/components/ChatHeader/ChatHeader.tsx` — partner info + online status
- `frontend/src/features/messaging/components/MeetupSuggestionPanel/MeetupSuggestionPanel.tsx` — meetup location cards
- `frontend/src/features/messaging/components/MeetupSuggestionPanel/MeetupSuggestionPanel.test.tsx` — tests
- `frontend/src/features/messaging/i18n/en.json` — English strings
- `frontend/src/features/messaging/i18n/fr.json` — French strings

**Files to modify**:
- `frontend/src/features/exchanges/pages/ExchangeDetailPage.tsx` — add `<ChatPanel>` section when exchange status is chat-eligible
- `frontend/src/routes/config/paths.ts` — optionally add `CHAT: '/exchanges/:id/chat'` path
- `frontend/src/routes/config/routesConfig.tsx` — optionally add chat route

**Component Design**:

#### 4a. `ChatPanel` (main container)

- Receives `exchangeId` as prop
- Uses `useMessages(exchangeId)` for infinite-scroll history (load older on scroll-up)
- Uses `useChatWebSocket(exchangeId)` for real-time
- Uses `useMarkMessagesRead(exchangeId)` to mark messages read when panel is visible (Intersection Observer)
- Layout: `ChatHeader` → scrollable message list → `TypingIndicator` → `MessageInput`
- Read-only mode: when exchange status is terminal, hide `MessageInput` and show "This chat is now read-only" banner
- Auto-scroll to bottom on new messages (unless user has scrolled up to read history)

#### 4b. `MessageBubble`

- Receives `message: ChatMessage` and `isOwn: boolean`
- Own messages: right-aligned, accent background
- Partner messages: left-aligned, muted background
- Shows: message text, optional image (thumbnail, click to expand), timestamp, read receipt icon (single check = sent, double check = read)
- Image: click opens a lightbox/modal with full-size image

#### 4c. `MessageInput`

- Text area with auto-resize (max 4 lines visible, scrollable after)
- Character counter: "250 / 1000"
- Image attachment button: opens file picker, shows preview thumbnail before send
- Send button: disabled when empty and no image attached
- Enter sends (Shift+Enter for newline)
- Debounced typing indicator: sends `chat.typing` WS message 500ms after last keystroke, with 3s cooldown

#### 4d. `TypingIndicator`

- Shows "[Partner name] is typing…" with animated dots
- Auto-hides after 3 seconds of no typing events
- Positioned just above the `MessageInput`

#### 4e. `ChatHeader`

- Partner's avatar, display name, swap count badge
- Connection status indicator (green dot = connected, grey = offline)
- "Suggest a meetup spot" button (opens `MeetupSuggestionPanel`)

#### 4f. `MeetupSuggestionPanel` (US-602)

- Triggered by button in `ChatHeader`
- Opens as a slide-up sheet or side panel
- Uses `useMeetupSuggestions(exchangeId)` to fetch locations
- Displays cards grouped by category (Library, Cafe, Park, Station)
- Each card: name, address, distance from each user
- "Select" button on each card: inserts formatted message into `MessageInput`: "How about meeting at [Name]? It's [X km] from you and [Y km] from me."
- Close button returns to chat

**Integration with ExchangeDetailPage**:

Add a collapsible "Chat with your partner" section in `ExchangeDetailPage` when status is in `['active', 'swap_confirmed', 'completed', 'return_requested', 'returned']`:

```tsx
{isChatEligible(exchange.status) && (
  <ChatPanel exchangeId={exchange.id} isReadOnly={isChatReadOnly(exchange)} />
)}
```

Helper functions:
- `isChatEligible(status)`: returns `true` for `active`, `swap_confirmed`, `completed`, `return_requested`, `returned`
- `isChatReadOnly(exchange)`: returns `true` for `completed` (and 7 days passed or both rated), `returned`, `declined`, `cancelled`, `expired`

**UX notes** (from the user story's specifications):
- Messages appear within 1 second of sending (US-601 AC2) — WebSocket handles this
- Chat shows: message text, sender avatar, timestamp, read status (US-601 AC3)
- Max 1 image per message, same upload rules as book photos (US-601 AC5)
- Typing indicator shown when partner is typing (US-601 AC7)
- Chat locked after exchange completed + both rated or 7 days (US-601 AC8)
- Network disconnection: show "Connecting..." status; queue messages locally (US-601 EC2)
- No phone number / email blocking in MVP (US-601 EC4)

**Acceptance criteria addressed**: US-601 AC1–AC8, US-602 AC1–AC5

---

### Phase 5 — Integration & Acceptance Criteria Check ✅ COMPLETE

> **Completed**: 2026-03-23 · **Branch**: `feat/epic-6-messaging` · **Commit**: `3ed8745`
> **Tests**: 796 FE passing (34 new) + 355 BE passing = 1,151 total · **Lint**: ESLint + ruff clean

**Goal**: Connect everything end-to-end and verify every AC is met.

**Tasks**:
- [x] Register `apps.messaging` in `config/settings/base.py` `INSTALLED_APPS`
- [x] Register messaging URLs in `config/urls.py`
- [x] Update `bookswap/routing.py` to route `ws/chat/{exchange_id}/` to `ChatConsumer`
- [x] Remove or repurpose `ExampleConsumer` from `bookswap/consumers.py`
- [x] Run `seed_meetup_locations` management command to populate initial Amsterdam data
- [x] Add MSW handlers in `frontend/src/test/mocks/handlers.ts` for messaging endpoints (messages list, send, mark-read, meetup-suggestions)
- [x] Add WebSocket mock in tests (mock `useChatWebSocket` for component tests)
- [x] Write backend tests: `backend/apps/messaging/tests/test_messaging_api.py`
  - Happy path: send message (REST), list messages, mark read
  - Auth: unauthenticated user gets 401
  - Permission: non-participant gets 403
  - Validation: empty message (no content, no image) gets 400
  - Validation: message > 1000 chars gets 400
  - Status guard: sending message to `pending` exchange gets 400
  - Status guard: sending message to `completed` exchange gets 400 (read-only)
  - Image upload: valid JPEG accepted, non-image rejected
  - Meetup suggestions: returns locations sorted by distance from midpoint
- [x] Write backend tests: `backend/apps/messaging/tests/test_messaging_api.py` (25 tests across 5 classes)
- [x] Write frontend tests: Vitest + Testing Library for `MessageBubble` (6), `TypingIndicator` (2), `MessageInput` (8), `ChatHeader` (7), `MeetupSuggestionPanel` (11) — 34 tests total
- [x] Verify all translations are in `en.json`, `fr.json`, and `nl.json`
- [x] Test WebSocket reconnection: existing `createWebSocket` service handles auto-reconnect with exponential backoff
- [ ] Test offline queueing: deferred — local message queueing not implemented in MVP (messages sent via REST fallback)

**Acceptance Criteria Checklist**:

| ID | Acceptance Criterion | Covered in Phase |
|----|---------------------|-----------------|
| US-601 AC1 | Chat available only after both accept conditions (status `active`) | Phase 2 (consumer connect guard) + Phase 4 (UI guard) |
| US-601 AC2 | Real-time messaging: < 1 second delivery | Phase 2 (WebSocket consumer) + Phase 3 (useChatWebSocket) |
| US-601 AC3 | Message shows: text, avatar, timestamp, read status | Phase 4 (MessageBubble) |
| US-601 AC4 | Text messages max 1000 chars | Phase 2 (serializer validation) + Phase 4 (MessageInput counter) |
| US-601 AC5 | Image sharing: 1 image per message, same rules as book photos | Phase 1 (model field) + Phase 2 (validation) + Phase 4 (MessageInput) |
| US-601 AC6 | Chat history persisted, accessible from "My Exchanges" | Phase 1 (DB model) + Phase 2 (list endpoint) + Phase 4 (ChatPanel) |
| US-601 AC7 | Typing indicator shown when partner is typing | Phase 2 (consumer typing broadcast) + Phase 4 (TypingIndicator) |
| US-601 AC8 | Chat locked after completion + both rated or 7 days | Phase 2 (consumer lock check) + Phase 4 (read-only mode) |
| US-602 AC1 | "Suggest a meetup spot" button in chat | Phase 4 (ChatHeader button) |
| US-602 AC2 | List of suggested public locations near both users | Phase 1 (MeetupLocation model) + Phase 2 (endpoint) |
| US-602 AC3 | Categories: Libraries, Cafes, Parks, Stations | Phase 1 (MeetupCategory choices) |
| US-602 AC4 | Each suggestion shows: name, address, distance from each user | Phase 2 (annotated queryset) + Phase 4 (MeetupSuggestionPanel) |
| US-602 AC5 | Selecting inserts formatted message into chat | Phase 4 (MeetupSuggestionPanel → MessageInput integration) |

**Edge Cases to handle**:

| ID | Edge Case | Where to handle |
|----|-----------|----------------|
| US-601 EC1 | Partner offline — message stored, seen on next open | Phase 2 (message saved to DB regardless of WS delivery) |
| US-601 EC2 | Network disconnection — "Connecting..." + local queue | Phase 3 (useChatWebSocket reconnect) + Phase 4 (UI status) |
| US-601 EC3 | Rapid messages (spam) — max 5 per 10 seconds | Phase 2 (Redis sliding window) + Phase 3 (client-side guard) |
| US-601 EC4 | Phone number / email in chat — no blocking in MVP | No action needed (documented as intentional) |
| US-602 EC1 | Both users same neighborhood — show nearest 3–5 locations | Phase 2 (queryset ordered by distance, limit 5) |
| US-602 EC2 | One user missing location — show all curated without distance | Phase 2 (fallback queryset without distance annotation) |

---

## 4. What's Not in This Plan

- **WebSocket `NotificationConsumer`** (Epic 9 scope): A general notification WebSocket channel for the nav bell badge is not included here. Epic 6 only adds the chat-specific `ChatConsumer`. The existing HTTP polling for incoming request count (`useIncomingRequestCount` at 60s) remains.
- **Chat message email batching** (Epic 9 scope): US-901 specifies email notifications for new chat messages with 15-minute batching. This is addressed in Epic 9 (Notifications), not here.
- **Profanity filter** (Epic 8 scope): US-701 mentions a profanity filter on review text. A similar filter for chat messages could be added in Epic 8 (Trust & Safety) but is not required by US-601.
- **Chat read-only after both rated**: The full "both rated" check requires Epic 7 (Ratings). Until Epic 7 is built, chat lock defaults to 7 days after completion only.

---

## 5. Suggested Commit Sequence

1. `feat(messaging): add Message & MeetupLocation models + migrations — Epic 6 Phase 1`
2. `feat(messaging): add REST API + ChatConsumer WebSocket — Epic 6 Phase 2`
3. `feat(messaging): add Frontend services, hooks & types — Epic 6 Phase 3`
4. `feat(messaging): build ChatPanel, MessageBubble, MeetupSuggestionPanel UI — Epic 6 Phase 4`
5. `test(messaging): add acceptance-criteria tests for chat & meetup — Epic 6 Phase 5`
