# Action Plan — Epic 7: Ratings & Reviews

> Generated: 2026-03-23
> Next unimplemented epic in order (Epics 1–6 complete).

---

## 1. Story Status Overview

| ID | Title | Priority | Status | Notes |
|----|-------|----------|--------|-------|
| US-701 | Rate Your Swap Partner | P0 | ✅ Implemented | Rating model, REST API, FE service/hooks/UI, 43 new tests (24 BE + 19 FE). Branch `feat/epic-7-ratings`. |

**Legend**: ✅ Implemented · ⚠️ Partial · ❌ Pending

---

## 2. Gaps in Previously Implemented Stories

### Gap: [US-504 → US-701] — No rating prompt after swap completion

- **AC not met**: US-701 AC1 — "Rating prompt shown after exchange completion (US-504)"
- **Evidence**: `ExchangeDetailPage.tsx` handles the `completed` state but renders no rating prompt or CTA. The `confirm_swap` action in `backend/apps/exchanges/views.py` transitions to `completed` but does not trigger any rating-related logic.
- **Fix needed**: Phase 4 of this plan adds a `RatingPrompt` component in `ExchangeDetailPage` shown when status is `completed` and the current user has not yet rated.

### Gap: [US-601 AC8] — Chat lock "both rated" check defaults to 7-day timer only

- **AC not met**: US-601 AC8 — "Chat locked after completion + both rated or 7 days"
- **Evidence**: `ChatConsumer` in `backend/apps/messaging/consumers.py` uses a 7-day-only timer for chat lock since Epic 7 did not exist at the time. The comment in Epic 6's plan says "if Epic 7 is not yet built, default to the 7-day timer only."
- **Fix needed**: Phase 5 of this plan updates `ChatConsumer.is_chat_locked()` to also check if both users have submitted ratings via the new `Rating` model.

### Gap: [User model] — `avg_rating` / `rating_count` / `swap_count` are stub fields with no update logic

- **AC not met**: US-701 Technical Notes — "Trigger on INSERT: recalculate avg_rating on the rated_id user"
- **Evidence**: `avg_rating`, `rating_count`, and `swap_count` on the `User` model (`backend/bookswap/models.py` lines 84–97) are always `0`. No signal, task, or trigger recalculates them.
- **Fix needed**: Phase 2 adds a Django signal (`post_save` on `Rating`) that triggers a Celery task `update_user_rating_stats` to recalculate these fields. Phase 2 also adds a signal on exchange `completed` status to increment `swap_count`.

_(No other gaps found in previously implemented stories that relate to Epic 7.)_

---

## 3. Implementation Plan — Epic 7: Ratings & Reviews

### Context

Epic 7 introduces the post-exchange rating system that lets both swap partners rate their experience after a completed exchange. This is the trust backbone of BookSwap — users see each other's average rating and rating count on profiles, exchange cards, and book listings. The epic has a single story (US-701) but touches multiple layers: a new `ratings` Django app, REST API endpoints, a Celery task for aggregate recalculation, frontend rating submission UI, and integration with the existing exchange completion flow and chat lock logic. It depends on Epic 5 (exchange status machine, specifically `completed` status) and Epic 6 (chat lock "both rated" check).

### Stories Covered

- **US-701**: Rate Your Swap Partner (P0)

---

### Phase 1 — Data Layer: Rating Model ✅ COMPLETE — `d40f9b8` (2025-07-22)

**Goal**: Create the `Rating` model in a new `apps/ratings/` Django app and run migrations.

**Files to create / modify**:
- `backend/apps/ratings/__init__.py` — new Django app
- `backend/apps/ratings/apps.py` — `RatingsConfig`
- `backend/apps/ratings/models.py` — `Rating`
- `backend/apps/ratings/admin.py` — basic admin registration
- `backend/apps/ratings/migrations/0001_initial.py` — auto-generated
- `backend/config/settings/base.py` — add `'apps.ratings'` to `INSTALLED_APPS`

**What to build**:

#### 1a. `Rating` Model

| Field | Type | Notes |
|-------|------|-------|
| `id` | UUIDField (PK) | `default=uuid.uuid4` |
| `exchange` | FK → ExchangeRequest | `related_name='ratings'`, `on_delete=CASCADE` |
| `rater` | FK → User | `related_name='ratings_given'`, `on_delete=CASCADE` — the user submitting the rating |
| `rated` | FK → User | `related_name='ratings_received'`, `on_delete=CASCADE` — the partner being rated |
| `score` | PositiveSmallIntegerField | Validators: `MinValueValidator(1)`, `MaxValueValidator(5)` |
| `comment` | CharField(300) | `blank=True` — optional text review |
| `is_flagged` | BooleanField | `default=False` — set by profanity filter; flagged reviews hidden until admin approves |
| `created_at` | DateTimeField | `auto_now_add=True` (via `TimeStampedModel`) |
| `updated_at` | DateTimeField | `auto_now=True` (via `TimeStampedModel`) |

**Constraints / indexes**:
```python
class Meta:
    ordering = ['-created_at']
    constraints = [
        models.UniqueConstraint(
            fields=['exchange', 'rater'],
            name='unique_rating_per_exchange_per_rater',
        ),
    ]
    indexes = [
        models.Index(fields=['rated', 'created_at'], name='rating_rated_created'),
        models.Index(fields=['exchange'], name='rating_exchange'),
    ]
```

**Model-level validation** (`clean()`):
- `rater` must be a participant of `exchange` (either requester or owner)
- `rated` must be the other participant (auto-derived: if rater is requester, rated is owner, and vice versa)
- `exchange.status` must be `completed` or `returned`
- Rating window: `exchange.updated_at` (when it became `completed`) must be within 30 days of now

**Acceptance criteria addressed**: US-701 AC2 (1–5 star), AC3 (optional text, max 300 chars), AC4 (30-day window), AC5 (immutable — unique constraint prevents second submission), EC2 (unique constraint blocks double-rating)

---

### Phase 2 — Backend API: REST Endpoints & Signals ✅ COMPLETE — `adf4a18` (2025-07-22)

**Goal**: Expose rating submission and retrieval through authenticated REST endpoints. Wire up signals to recalculate user aggregate stats.

**Tests**: 24 BE tests (379 total). Fixed Celery shared_task binding + test settings (memory broker).

**Files to create / modify**:
- `backend/apps/ratings/serializers.py` — `RatingSerializer`, `RatingCreateSerializer`, `ExchangeRatingStatusSerializer`
- `backend/apps/ratings/views.py` — `RatingViewSet`
- `backend/apps/ratings/urls.py` — register routes
- `backend/apps/ratings/permissions.py` — `IsExchangeParticipant`
- `backend/apps/ratings/signals.py` — `post_save` on `Rating` → trigger aggregate recalculation
- `backend/apps/ratings/tasks.py` — `update_user_rating_stats` Celery task
- `backend/apps/ratings/utils.py` — basic profanity filter utility
- `backend/config/urls.py` — add `path('api/v1/ratings/', include('apps.ratings.urls'))`

**Serializers to build**:

#### 2a. `RatingSerializer` (read)

- `id`, `exchange` (UUID), `rater` (nested: id, username, avatar), `rated` (nested: id, username, avatar), `score`, `comment`, `created_at`
- For flagged ratings: return `comment` as empty string unless requesting user is the rater or an admin

#### 2b. `RatingCreateSerializer` (write)

Validates:
- `score` — required, integer 1–5
- `comment` — optional, max 300 characters, trimmed
- Exchange must be in status `completed` or `returned`
- Rating window: exchange completion must be within last 30 days (`exchange.updated_at + 30 days > now`)
- Rater must be a participant of the exchange
- No existing rating from this rater for this exchange (DB constraint catches this too, but give a friendly error)
- Profanity check on `comment`: if flagged, set `is_flagged=True` on the rating (still saved, but hidden from public until admin review)
- Auto-derive `rated` from the exchange (the other participant)

#### 2c. `ExchangeRatingStatusSerializer` (read)

- `exchange_id`, `my_rating` (RatingSerializer | null), `partner_rating` (RatingSerializer | null), `can_rate` (boolean — true if within 30-day window and haven't rated yet), `rating_deadline` (ISO date — exchange.updated_at + 30 days)

**REST Endpoints**:

| Method | Path | Auth | Description | Story |
|--------|------|------|-------------|-------|
| POST | `/api/v1/ratings/exchanges/{exchange_id}/` | IsAuthenticated + IsExchangeParticipant | Submit a rating for the exchange partner | US-701 |
| GET | `/api/v1/ratings/exchanges/{exchange_id}/` | IsAuthenticated + IsExchangeParticipant | Get rating status for an exchange (my rating, partner's rating, can I still rate?) | US-701 |
| GET | `/api/v1/ratings/users/{user_id}/` | IsAuthenticated | List public ratings received by a user (paginated, newest first). Excludes flagged ratings. | US-701 |

**Signals & Tasks**:

#### 2d. `post_save` Signal on `Rating`

On new `Rating` creation:
1. Trigger `update_user_rating_stats.delay(rated_id=rating.rated_id)` Celery task
2. Check if both participants have now rated → if so, update chat lock status (for Epic 6 integration)

#### 2e. `update_user_rating_stats` Celery Task

Recalculates for the given user:
```python
from django.db.models import Avg, Count

stats = Rating.objects.filter(rated=user, is_flagged=False).aggregate(
    avg=Avg('score'),
    count=Count('id'),
)
user.avg_rating = stats['avg'] or 0
user.rating_count = stats['count']
user.save(update_fields=['avg_rating', 'rating_count'])
```

#### 2f. `swap_count` Increment

Add a signal (or extend existing exchange signal) that increments `swap_count` on both users when an exchange transitions to `completed`. This addresses the gap where `swap_count` is always 0.

Check if this already exists in `backend/apps/exchanges/signals.py` or `backend/bookswap/signals.py` — if not, add it in this phase.

#### 2g. Basic Profanity Filter

A simple utility function in `backend/apps/ratings/utils.py`:
- Maintain a list of blocked terms (loaded from a text file or hardcoded list for MVP)
- Case-insensitive substring match
- Returns `True` if any blocked term is found in the comment text
- Used by `RatingCreateSerializer` to set `is_flagged=True`

**Nimoh-stack conventions to follow**:
- UUID PKs, `created_at`/`updated_at` on every model (via `TimeStampedModel`)
- `get_queryset()` scoped appropriately: exchange ratings scoped to participants, user ratings public but filtered
- `permission_classes` declared explicitly on every view and action
- `select_related('rater', 'rated', 'exchange')` on rating queries to avoid N+1
- Split serializers: `RatingCreateSerializer` (write) vs `RatingSerializer` (read)

**Acceptance criteria addressed**: US-701 AC1 (prompt trigger from backend), AC2 (score 1–5), AC3 (comment max 300), AC4 (30-day window), AC5 (immutable — unique constraint), AC6 (silent expiry — no backend action needed, frontend just hides the prompt), AC7 (skip — frontend concern, no backend action), EC1 (profanity filter), EC2 (unique constraint)

---

### Phase 3 — Frontend Services & Hooks ✅ COMPLETE — `d29832c` (2025-07-22)

**Goal**: Wire the ratings API into the frontend data layer with TypeScript types, API service functions, TanStack Query hooks, and Zod schemas.

**Files to create**:
- `frontend/src/features/ratings/types/rating.types.ts` — TypeScript interfaces
- `frontend/src/features/ratings/services/rating.service.ts` — axios wrappers for REST endpoints
- `frontend/src/features/ratings/hooks/ratingKeys.ts` — TanStack Query key factory
- `frontend/src/features/ratings/hooks/useExchangeRatingStatus.ts` — query hook (get rating status for an exchange)
- `frontend/src/features/ratings/hooks/useSubmitRating.ts` — mutation hook (POST rating)
- `frontend/src/features/ratings/hooks/useUserRatings.ts` — query hook (paginated list of ratings received by a user)
- `frontend/src/features/ratings/schemas/rating.schemas.ts` — Zod validation schema for rating form
- `frontend/src/features/ratings/index.ts` — barrel export

**Files to modify**:
- `frontend/src/configs/apiEndpoints.ts` — add `ratings` endpoint group

**Key patterns**:

#### 3a. API Endpoints (add to `apiEndpoints.ts`)

```typescript
/** Ratings endpoints. */
const RATINGS = `${V1}/ratings` as const;

ratings: {
  exchangeRating: (exchangeId: string) => `${RATINGS}/exchanges/${exchangeId}/`,
  userRatings: (userId: string) => `${RATINGS}/users/${userId}/`,
},
```

#### 3b. TypeScript Types

```typescript
export interface Rating {
  id: string;
  exchange: string;
  rater: {
    id: string;
    username: string;
    avatar: string | null;
  };
  rated: {
    id: string;
    username: string;
    avatar: string | null;
  };
  score: number;
  comment: string;
  created_at: string;
}

export interface ExchangeRatingStatus {
  exchange_id: string;
  my_rating: Rating | null;
  partner_rating: Rating | null;
  can_rate: boolean;
  rating_deadline: string;
}

export interface RatingCreatePayload {
  score: number;
  comment?: string;
}

export interface PaginatedRatings {
  count: number;
  next: string | null;
  previous: string | null;
  results: Rating[];
}
```

#### 3c. Zod Schema

```typescript
import { z } from 'zod';

export const ratingSchema = z.object({
  score: z.number().int().min(1).max(5),
  comment: z.string().max(300).optional().default(''),
});

export type RatingFormData = z.infer<typeof ratingSchema>;
```

#### 3d. TanStack Query Key Factory

```typescript
export const ratingKeys = {
  all: ['ratings'] as const,
  exchangeStatus: (exchangeId: string) =>
    [...ratingKeys.all, 'exchange', exchangeId] as const,
  userRatings: (userId: string) =>
    [...ratingKeys.all, 'user', userId] as const,
};
```

#### 3e. `useExchangeRatingStatus` Hook

- Fetches `GET /api/v1/ratings/exchanges/{exchangeId}/`
- Returns `{ data: ExchangeRatingStatus, isLoading, isError }`
- Enabled only when exchange status is `completed` or `returned`

#### 3f. `useSubmitRating` Mutation Hook

- POSTs to `/api/v1/ratings/exchanges/{exchangeId}/`
- On success: invalidates `ratingKeys.exchangeStatus(exchangeId)` and `ratingKeys.userRatings(partnerId)`
- Also invalidates the exchange detail query to refresh any rating-dependent UI

#### 3g. `useUserRatings` Hook

- Fetches `GET /api/v1/ratings/users/{userId}/` with pagination
- Used on the `PublicProfilePage` to show received ratings
- Enabled only when `rating_count >= 3` (same threshold as the existing display logic)

**Nimoh-stack conventions to follow**:
- `credentials: 'include'` on the API client
- Key factory pattern: `ratingKeys.all()`, `.exchangeStatus(exchangeId)`, `.userRatings(userId)`
- No access token in localStorage — use Zustand memory store for auth

**Acceptance criteria addressed**: US-701 AC1 (fetch rating status), AC2 (submit score), AC3 (submit comment), AC5 (mutation disallowed after first submission — `can_rate: false`)

---

### Phase 4 — Frontend UI ✅ COMPLETE — `924c29b` (2025-07-22)

**Goal**: Build the rating submission UI and the ratings display components.

**Files to create**:
- `frontend/src/features/ratings/components/RatingPrompt/RatingPrompt.tsx` — modal/card shown after exchange completion
- `frontend/src/features/ratings/components/RatingPrompt/RatingPrompt.test.tsx` — tests
- `frontend/src/features/ratings/components/StarRating/StarRating.tsx` — interactive star picker (1–5)
- `frontend/src/features/ratings/components/StarRating/StarRating.test.tsx` — tests
- `frontend/src/features/ratings/components/StarDisplay/StarDisplay.tsx` — read-only star display (for profile, exchange card)
- `frontend/src/features/ratings/components/StarDisplay/StarDisplay.test.tsx` — tests
- `frontend/src/features/ratings/components/RatingCard/RatingCard.tsx` — individual rating display (for user profile)
- `frontend/src/features/ratings/components/RatingCard/RatingCard.test.tsx` — tests
- `frontend/src/features/ratings/components/RatingsList/RatingsList.tsx` — paginated list of ratings on PublicProfilePage
- `frontend/src/features/ratings/components/RatingsList/RatingsList.test.tsx` — tests
- `frontend/src/features/ratings/index.ts` — re-export public components
- `frontend/public/locales/en/ratings.json` — English strings
- `frontend/public/locales/fr/ratings.json` — French strings
- `frontend/public/locales/nl/ratings.json` — Dutch strings

**Files to modify**:
- `frontend/src/features/exchanges/pages/ExchangeDetailPage.tsx` — add `<RatingPrompt>` section when exchange status is `completed`/`returned` and user hasn't rated
- `frontend/src/features/profile/pages/PublicProfilePage.tsx` — add `<RatingsList>` section below the existing stats card when `rating_count >= 3`

**Component Design**:

#### 4a. `RatingPrompt` (main submission component)

- Receives `exchangeId: string` and `partnerName: string` as props
- Uses `useExchangeRatingStatus(exchangeId)` to check if user can still rate
- If `can_rate` is `false` and `my_rating` exists: show "You rated this exchange ★X" with the submitted rating (read-only)
- If `can_rate` is `false` and `my_rating` is null: show nothing (window expired, AC6)
- If `can_rate` is `true`: show rating form
  - Heading: "How was your swap with [Partner Name]?"
  - `<StarRating>` component for score selection (1–5, required)
  - Optional textarea for comment (max 300 chars, character counter)
  - "Submit Rating" button (disabled until score selected)
  - "Skip" link/button — dismisses the prompt without submitting (AC7)
  - Shows countdown: "X days left to rate" based on `rating_deadline`
- On submit success: show confirmation message "Thanks for your rating!" and switch to read-only view
- On submit error: show inline error message

#### 4b. `StarRating` (interactive picker)

- Receives `value: number | null`, `onChange: (score: number) => void`, `disabled?: boolean`
- 5 star icons in a row
- Hover effect: stars light up on hover to preview selection
- Click: sets the score
- Keyboard accessible: arrow keys to adjust, Enter to confirm
- `aria-label`: "Rate {value} out of 5 stars"

#### 4c. `StarDisplay` (read-only)

- Receives `score: number`, `size?: 'sm' | 'md' | 'lg'`
- Renders filled/empty stars based on score (supports half-stars for averages)
- Used in `ExchangeParticipant` cards, `PublicProfilePage` stats, and `RatingCard`

#### 4d. `RatingCard`

- Receives `rating: Rating`
- Shows: rater avatar, rater username, star score, comment text, date
- Used in `RatingsList`

#### 4e. `RatingsList`

- Receives `userId: string`
- Uses `useUserRatings(userId)` with pagination
- Renders a list of `<RatingCard>` components
- "Load more" button for pagination
- Empty state: should not be shown if `rating_count < 3` (the parent guards this)

**Integration with ExchangeDetailPage**:

Add a `RatingPrompt` section in `ExchangeDetailPage` when status is `completed` or `returned`:

```tsx
{(exchange.status === 'completed' || exchange.status === 'returned') && (
  <RatingPrompt
    exchangeId={exchange.id}
    partnerName={isRequester ? exchange.owner.username : exchange.requester.username}
  />
)}
```

**Integration with PublicProfilePage**:

Add a `RatingsList` section below the existing stats card:

```tsx
{showRating && (
  <RatingsList userId={id!} />
)}
```

**UX notes** (from US-701):
- Rating prompt is non-blocking — shown as a card/section on ExchangeDetailPage, not a forced modal (AC1)
- "Skip" option clearly available (AC7)
- Rating is final — no edit button shown after submission (AC5)
- Countdown timer shows remaining days in the 30-day window (AC4)
- If partner has also rated, show their rating below yours (nice-to-have, not required by AC)

**i18n keys** (all three locales — en, fr, nl):

```json
{
  "ratings.prompt.title": "How was your swap with {{partnerName}}?",
  "ratings.prompt.subtitle": "Your rating helps build trust in the BookSwap community.",
  "ratings.prompt.scoreLabel": "Rating",
  "ratings.prompt.commentLabel": "Write a short review (optional)",
  "ratings.prompt.commentPlaceholder": "How was the exchange experience?",
  "ratings.prompt.submit": "Submit Rating",
  "ratings.prompt.skip": "Skip",
  "ratings.prompt.daysLeft": "{{count}} day left to rate",
  "ratings.prompt.daysLeft_other": "{{count}} days left to rate",
  "ratings.prompt.success": "Thanks for your rating!",
  "ratings.prompt.alreadyRated": "You rated this exchange",
  "ratings.prompt.expired": "Rating window has closed",
  "ratings.stars.label": "Rate {{value}} out of 5 stars",
  "ratings.card.by": "by {{username}}",
  "ratings.list.title": "Reviews",
  "ratings.list.loadMore": "Load more reviews",
  "ratings.list.empty": "No reviews yet"
}
```

**Acceptance criteria addressed**: US-701 AC1 (prompt after completion), AC2 (1–5 stars), AC3 (optional text), AC4 (30-day window countdown), AC5 (immutable — read-only after submit), AC6 (silent expiry — prompt hidden), AC7 (skip option)

---

### Phase 5 — Integration & Acceptance Criteria Check ✅ COMPLETE — `7a485ab` (2025-07-22)

**Goal**: Connect everything end-to-end, wire up cross-epic integrations, and verify every AC is met.

**Tests**: 19 FE tests (815 total). MSW handlers added. 1,194 total tests (379 BE + 815 FE).

**Tasks**:
- [ ] Register `apps.ratings` in `config/settings/base.py` `INSTALLED_APPS`
- [ ] Register ratings URLs in `config/urls.py`: `path('api/v1/ratings/', include('apps.ratings.urls'))`
- [ ] Run migrations: `python manage.py makemigrations ratings && python manage.py migrate`
- [ ] Wire up the `swap_count` increment signal — ensure both users' `swap_count` is incremented when exchange reaches `completed`
- [ ] Wire up the `update_user_rating_stats` Celery task — triggered by `Rating` `post_save` signal
- [ ] Update `ChatConsumer.is_chat_locked()` in `backend/apps/messaging/consumers.py` to check if both users have rated (in addition to the 7-day timer) — this closes the Epic 6 gap
- [ ] Add MSW handlers in `frontend/src/test/mocks/handlers.ts` for rating endpoints (exchange rating status, submit rating, user ratings list)
- [ ] Write backend tests: `backend/apps/ratings/tests/test_ratings_api.py`
  - Happy path: submit rating (score + comment), verify response
  - Submit rating (score only, no comment), verify response
  - Auth: unauthenticated user gets 401
  - Permission: non-participant gets 403
  - Validation: score 0 → 400, score 6 → 400
  - Validation: comment > 300 chars → 400
  - Status guard: rating exchange in `pending` status → 400
  - Status guard: rating exchange in `active` status → 400
  - Window guard: rating after 30 days → 400
  - Duplicate guard: second rating from same user → 400 (unique constraint)
  - Profanity flag: comment with blocked term → saved with `is_flagged=True`
  - Aggregate update: after rating, `avg_rating` and `rating_count` on rated user are updated
  - Get exchange rating status: returns `can_rate`, `my_rating`, `partner_rating`, `rating_deadline`
  - User ratings list: returns paginated ratings, excludes flagged
- [ ] Write frontend tests: Vitest + Testing Library
  - `StarRating` — renders 5 stars, click sets value, hover preview, keyboard navigation, disabled state (6 tests)
  - `StarDisplay` — renders correct filled/empty stars for various scores (4 tests)
  - `RatingPrompt` — shows form when can_rate=true, shows read-only when already rated, hides when expired, submit flow, skip button, character counter (8 tests)
  - `RatingCard` — renders rater info, score, comment, date (3 tests)
  - `RatingsList` — renders list, pagination, empty guard (4 tests)
- [ ] Verify all translations are in `en/ratings.json`, `fr/ratings.json`, and `nl/ratings.json`
- [ ] Verify `PublicProfilePage` integration: ratings list shows below stats when `rating_count >= 3`
- [ ] Verify `ExchangeDetailPage` integration: `RatingPrompt` shows for completed/returned exchanges

**Acceptance Criteria Checklist**:

| ID | Acceptance Criterion | Covered in Phase |
|----|---------------------|-----------------|
| AC1 | Rating prompt shown after exchange completion — non-blocking modal or dedicated page | Phase 4 (`RatingPrompt` in `ExchangeDetailPage`) |
| AC2 | Star rating: 1–5 stars (required to submit) | Phase 1 (model validators) + Phase 2 (serializer) + Phase 4 (`StarRating` component) |
| AC3 | Optional text review: max 300 characters | Phase 1 (model field) + Phase 2 (serializer) + Phase 4 (textarea with char counter) |
| AC4 | User can rate within 30 days of exchange completion | Phase 2 (serializer window validation) + Phase 4 (countdown display + hide when expired) |
| AC5 | Rating is final and cannot be edited | Phase 1 (unique constraint) + Phase 2 (serializer rejects duplicate) + Phase 4 (read-only after submit) |
| AC6 | If user doesn't rate within 30 days: opportunity expires silently | Phase 2 (`can_rate: false` when window expires) + Phase 4 (prompt hidden) |
| AC7 | "Skip" option available — user is not forced to rate | Phase 4 (Skip button on `RatingPrompt`) |

**Edge Cases to handle**:

| ID | Edge Case | Where to handle |
|----|-----------|----------------|
| EC1 | 1-star rating with abusive text → profanity filter, flagged for admin | Phase 2 (`is_flagged=True` via profanity util, excluded from public list) |
| EC2 | User tries to rate same exchange twice → blocked at DB level | Phase 1 (unique constraint) + Phase 2 (friendly 400 error) |

---

## 4. What's Not in This Plan

- **Admin dashboard for flagged reviews** (Epic 8 scope): US-802 mentions an admin dashboard for reviewing reports. Flagged ratings from the profanity filter will be stored with `is_flagged=True` and excluded from public display, but the admin UI to approve/reject them is deferred to Epic 8 (Trust & Safety).
- **Email notification for "Rate your swap"** (Epic 9 scope): US-901 specifies email notifications for exchange events. A reminder email to rate after swap completion is a natural extension but belongs in Epic 9 (Notifications).
- **Rating aggregation display on book cards / browse results**: The `UserPublicSerializer` already exposes `avg_rating` (hidden when `rating_count < 3`). No changes needed to the browse/discovery features — they already read the User model fields that will now be populated.

---

## 5. Suggested Commit Sequence

1. `feat(ratings): add Rating model + migrations — Epic 7 Phase 1`
2. `feat(ratings): expose rating REST API with profanity filter + user stats signals — Epic 7 Phase 2`
3. `feat(ratings): add Frontend services, hooks & Zod schemas — Epic 7 Phase 3`
4. `feat(ratings): build RatingPrompt, StarRating, RatingsList UI — Epic 7 Phase 4`
5. `test(ratings): add acceptance-criteria tests + chat lock integration — Epic 7 Phase 5`
