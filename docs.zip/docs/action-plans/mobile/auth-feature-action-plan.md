# BookSwap Mobile — Auth Feature Action Plan

> **Goal:** Bring the BookSwap mobile auth feature up to the same structural quality as
> the SpeakLinka mobile app, while keeping BookSwap's own brand identity and design.
>
> **Reference:** SpeakLinka mobile auth at `speak-linka/mobile/src/features/auth/`

---

## Gap Analysis: SpeakLinka vs BookSwap (current)

| Area | SpeakLinka | BookSwap (current) | Priority |
|------|-----------|---------|----------|
| Form validation | React Hook Form + Zod (shared `@shared/schemas`) | Raw `useState`, no validation | HIGH |
| API calls | TanStack Query mutations (`useLogin`, `useRegister`, etc.) | Direct `http.post` in screens | HIGH |
| Auth components | Composed: `AuthScreenWrapper`, `AuthInput`, `AuthButton`, `LoginHero`, `LoginForm`, `LoginFooter` | Inline `TextInput` / `TouchableOpacity` | HIGH |
| Design system | Uses theme tokens, `LinearGradient`, branded colors | Hard-coded `#2563EB` blue, white bg, no `useColors()` | HIGH |
| Splash / Hydration | Dedicated branded `SplashScreen` with `getMe` + refresh fallback | `RootNavigator` hydrates from stored JSON, no server verification | MEDIUM |
| Rate limiting | Client-side cooldown (5 attempts / 10 min) | None | MEDIUM |
| Remember Me | Toggle + `AppState` listener to clear tokens on background | Not implemented | MEDIUM |
| Biometric login | Refresh token → `getMe` = actual session restoration | `authenticateAsync` only, no session effect (no-op) | HIGH |
| Email verification | Full flow: `VerificationPending` (polling) → `Verified` (deep link) | Endpoints exist in `apiEndpoints.ts`, no screens | LOW |
| Password change | Authenticated screen | Endpoint exists, no screen | LOW |
| Error handling | Toast system (`showErrorToast`) | `Alert.alert` | MEDIUM |
| Dark mode in auth | Auth screens respect `useColors()` | Auth screens ignore theme entirely | MEDIUM |
| Social auth (Google) | Google Sign-In via `@react-native-google-signin` | Not implemented | LOW |
| Magic link | Request magic-link email screen | Not implemented | LOW |

---

## Design Direction

BookSwap brand — **not** a copy of SpeakLinka's visual design:

- **Background:** Dark green (`#1a2f23`) gradient
- **Accent:** Golden (`#E4B643`) for CTAs, highlights, active states
- **Text on dark:** Cream (`#f5f5dc`) / white
- **Logo:** Hexagonal book-swap mark from `assets/icon.png`
- **Input style:** Semi-transparent glass with `rgba(255,255,255,0.08)` borders, light text
- **Buttons:** Solid golden primary, outline secondary
- **Radius:** `12px` inputs, `16px` cards (matches existing theme tokens)

Same *structural patterns* as SpeakLinka (composed components, themed, accessible) but a
distinct look.

---

## Phase 1 — Auth Foundation (reusable components + design tokens)

Files to create under `mobile/src/features/auth/components/`:

| # | Task | File(s) | Details |
|---|------|---------|---------|
| 1.1 | `AuthScreenWrapper` | `AuthScreenWrapper.tsx` | Dark green gradient bg (`expo-linear-gradient` or solid), `SafeAreaView`, `KeyboardAvoidingView`, optional `ScrollView`. Uses `useColors()` for dark mode. |
| 1.2 | `AuthInput` | `AuthInput.tsx` | `forwardRef` TextInput with Lucide icon prefix, themed borders (default / focus / error), optional right action (show/hide password toggle). Glass-style on dark bg. |
| 1.3 | `AuthButton` | `AuthButton.tsx` | Primary (golden bg + dark text) and outline (transparent bg + golden border) variants. Loading spinner state. Disabled state. |
| 1.4 | `AuthLogo` | `AuthLogo.tsx` | BookSwap icon (`require('../../../../assets/icon.png')`) + "BookSwap" wordmark. Props for size variants. |

**Acceptance:** All four components render correctly in light and dark mode using `useColors()`.

---

## Phase 2 — Form Validation + Auth Mutations

### 2A — Validation schemas

| # | Task | File(s) | Details |
|---|------|---------|---------|
| 2.1 | Login schema | `features/auth/schemas/auth.schemas.ts` | Zod: `email_or_username` (non-empty string), `password` (min 8). |
| 2.2 | Register schema | same file | Zod: `email` (email), `username` (3-30 chars, alphanumeric + underscore), `first_name`, `last_name`, `password` (min 8), `password_confirm` (must match). |
| 2.3 | Forgot password schema | same file | Zod: `email` (email). |

### 2B — TanStack Query mutations

| # | Task | File(s) | Details |
|---|------|---------|---------|
| 2.4 | `useLogin` | `features/auth/hooks/useLogin.ts` | Mutation: `http.post(API.auth.login)` → `setAuth(user, access, refresh)` → `getMe()` → `setUser(fullUser)`. |
| 2.5 | `useRegister` | `features/auth/hooks/useRegister.ts` | Mutation: `http.post(API.auth.register)`. Server field errors mapped with RHF `setError`. |
| 2.6 | `useForgotPassword` | `features/auth/hooks/useForgotPassword.ts` | Mutation: `http.post(API.auth.passwordReset)`. |
| 2.7 | `useLogout` | `features/auth/hooks/useLogout.ts` | Mutation: clear tokens, query cache, Sentry user, WebSocket disconnect. Optionally call `API.auth.logout` server-side. |
| 2.8 | Auth API module | `features/auth/api/auth.api.ts` | Centralised API: `login`, `register`, `getMe`, `refreshToken`, `forgotPassword`, `logout`. Raw `axios` for unauth, `http` for auth'd. |

**Acceptance:** Mutations work with mock/real backend. Login stores tokens + user.

---

## Phase 3 — Redesign Auth Screens

| # | Task | File(s) | Details |
|---|------|---------|---------|
| 3.1 | Redesign `LoginScreen` | `features/auth/screens/LoginScreen.tsx` | Composed from `AuthScreenWrapper` + `AuthLogo` + `LoginForm` + `LoginFooter`. RHF + Zod. Remember-me toggle. Rate limiting (5 attempts / 10 min cooldown). Working biometric re-entry (refresh → getMe). "Forgot password" + "Create account" links. BookSwap palette. |
| 3.2 | Create `LoginForm` | `features/auth/components/login/LoginForm.tsx` | RHF `Controller`s wrapping `AuthInput`. Remember-me row. Rate-limit banner. Submit via `AuthButton`. |
| 3.3 | Create `LoginHero` | `features/auth/components/login/LoginHero.tsx` | `AuthLogo` + welcome title + subtitle. |
| 3.4 | Create `LoginFooter` | `features/auth/components/login/LoginFooter.tsx` | "Forgot password?" + "Don't have an account? Register" links. |
| 3.5 | Redesign `RegisterScreen` | `features/auth/screens/RegisterScreen.tsx` | Composed from `AuthScreenWrapper` + hero + `RegisterForm` + footer. RHF + Zod. Server-side error mapping (`setError`). |
| 3.6 | Create `RegisterForm` | `features/auth/components/register/RegisterForm.tsx` | All fields via `AuthInput`. Password strength indicator. |
| 3.7 | Create `RegisterFooter` | `features/auth/components/register/RegisterFooter.tsx` | "Already have an account? Sign in" link. |
| 3.8 | Redesign `ForgotPasswordScreen` | `features/auth/screens/ForgotPasswordScreen.tsx` | Composed from `AuthScreenWrapper` + back link + hero + email form + success state. |

**Acceptance:** All three screens render with BookSwap branding, validate input, handle
errors via toasts, and support dark mode.

---

## Phase 4 — Splash Screen + Biometric + Hydration

| # | Task | File(s) | Details |
|---|------|---------|---------|
| 4.1 | Create `SplashScreen` | `features/auth/screens/SplashScreen.tsx` | BookSwap branded (dark green + golden logo + spinner). Hydration: stored access → `getMe`; if 401 → refresh → `getMe`; if fail → `logout()` → `setHydrated()`. |
| 4.2 | Fix biometric login | `features/auth/screens/LoginScreen.tsx`, `hooks/useBiometric.ts` | On biometric success: read stored refresh → `authApi.refreshToken()` → `authApi.getMe()` → `setAuth()`. Actual session restoration, not a no-op. |
| 4.3 | Update `RootNavigator` | `navigation/RootNavigator.tsx` | Show `SplashScreen` until `isHydrated`. Remove inline `hydrate()` call. Route: Splash → (Auth \| Main). |
| 4.4 | Update `AuthStack` | `navigation/AuthStack.tsx` | Add `SplashScreen` as initial route (or keep it outside the stack in `RootNavigator`). |

**Acceptance:** App boots with branded splash, verifies session with the server, biometric
button on login actually restores a session.

---

## Phase 5 — Polish

| # | Task | File(s) | Details |
|---|------|---------|---------|
| 5.1 | Replace `Alert.alert` with toasts | all auth screens | Use `showErrorToast` / `showSuccessToast` from `@/components/Toast`. |
| 5.2 | Dark mode support | all auth screens + components | All colors via `useColors()`. Verify light and dark. |
| 5.3 | Update deep links | `navigation/linking.ts` | Add `forgot-password` path to auth linking config. |
| 5.4 | Add `PasswordStrengthIndicator` | `features/auth/components/PasswordStrengthIndicator.tsx` | Visual strength bar (weak/medium/strong) for register screen. |
| 5.5 | Keyboard UX | all auth screens | `returnKeyType="next"` → focus next input via refs. `returnKeyType="done"` on last field → submit. |

---

## Phase 6 — Future (not in this sprint)

These can be added later once the core auth is solid:

| # | Task | Notes |
|---|------|-------|
| 6.1 | Email verification flow | `VerificationPendingScreen` (polling) + `VerifiedScreen` (deep link exchange token) |
| 6.2 | Magic link login | Request screen + deep link handler |
| 6.3 | Password change screen | Authenticated, uses `API.auth.passwordChange` |
| 6.4 | Social auth (Google) | `@react-native-google-signin/google-signin` + backend endpoint |
| 6.5 | Biometric timeout settings | Settings screen to choose lock timeout (5min / 15min / always / never) |

---

## Implementation Order

```
Phase 1 (foundation)  →  Phase 2 (validation + mutations)  →  Phase 3 (screens)
                                                                    ↓
                                                            Phase 4 (splash + biometric)
                                                                    ↓
                                                            Phase 5 (polish)
```

Each phase builds on the previous. Phases 1-3 are the core work. Phase 4 adds
session reliability. Phase 5 is refinement.

---

## Files Affected (summary)

**New files (~18):**
- `features/auth/components/AuthScreenWrapper.tsx`
- `features/auth/components/AuthInput.tsx`
- `features/auth/components/AuthButton.tsx`
- `features/auth/components/AuthLogo.tsx`
- `features/auth/components/login/LoginForm.tsx`
- `features/auth/components/login/LoginHero.tsx`
- `features/auth/components/login/LoginFooter.tsx`
- `features/auth/components/register/RegisterForm.tsx`
- `features/auth/components/register/RegisterFooter.tsx`
- `features/auth/components/PasswordStrengthIndicator.tsx`
- `features/auth/schemas/auth.schemas.ts`
- `features/auth/hooks/useLogin.ts`
- `features/auth/hooks/useRegister.ts`
- `features/auth/hooks/useForgotPassword.ts`
- `features/auth/hooks/useLogout.ts`
- `features/auth/api/auth.api.ts`
- `features/auth/screens/SplashScreen.tsx`

**Modified files (~5):**
- `features/auth/screens/LoginScreen.tsx` (full rewrite)
- `features/auth/screens/RegisterScreen.tsx` (full rewrite)
- `features/auth/screens/ForgotPasswordScreen.tsx` (full rewrite)
- `navigation/RootNavigator.tsx` (splash integration)
- `navigation/AuthStack.tsx` (optional splash route)
