# Action Plan — Epic 5: Exchange Flow (Book Partner System)

> Generated: 2026-03-23
> **Status: ✅ COMPLETE** — All 6 phases implemented, tested, committed, and pushed.
> Branch: `feat/epic-5-exchange` (5 commits: `5980c49`..`3cd1c33`)
> Tests: 330 BE + 762 FE = **1,092 total passing**

---

## 1. Story Status Overview

| ID | Title | Priority | Status | Notes |
|----|-------|----------|--------|-------|
| US-501 | Send Book Partner Request | P0 | ✅ Implemented | ExchangeRequest model, create endpoint, RequestSwapButton, inline book picker |
| US-502 | Review & Respond to Partner Request | P0 | ✅ Implemented | IncomingRequestsPage, accept/decline/counter actions, incoming count endpoint |
| US-503 | Accept Exchange Conditions | P0 | ✅ Implemented | ConditionsAcceptance model, accept-conditions endpoint, ExchangeDetailPage conditions UI |
| US-504 | Confirm Exchange Completion | P0 | ✅ Implemented | Two-phase confirm-swap, swap_count F() increment, ExchangeDetailPage confirm UI |
| US-505 | Book Return Flow | P1 | ✅ Implemented | request-return + confirm-return endpoints, return UI built into ExchangeDetailPage |

**Legend**: ✅ Implemented · ⚠️ Partial · ❌ Pending · 🔄 Deferred

---

## 2. Gaps in Previously Implemented Stories

### Gap: [US-305] — Book status field has `in_exchange` and `returned` choices but no Exchange model to transition them

- **AC not met**: `BookStatus.IN_EXCHANGE` and `BookStatus.RETURNED` choices exist in `backend/bookswap/models.py` but nothing sets these values.
- **Evidence**: `Book.status` defaults to `available`; `BookViewSet.perform_destroy()` checks `IN_EXCHANGE` but no exchange flow exists to set it.
- **Fix needed**: Epic 5 Phase 1 creates the `ExchangeRequest` model and Phase 2 adds the API actions that transition book status on swap confirmation.
- **✅ RESOLVED**: Phase 2 `confirm_swap` action sets both books to `in_exchange`; `confirm_return` sets them back to `available`.

### Gap: [User model] — `swap_count` and `rating_count` exist but are never incremented

- **AC not met**: `User.swap_count` and `User.rating_count` fields exist (Epic 7 prep) but no logic increments them.
- **Evidence**: `User.swap_count` is always 0; the public profile displays it but it's never updated.
- **Fix needed**: Phase 2 of this plan will increment `swap_count` for both users when swap is confirmed (US-504). `rating_count` will be addressed in Epic 7.
- **✅ RESOLVED**: Phase 2 `confirm_swap` action uses `F('swap_count') + 1` to increment for both users.

### Gap: [WebSocket consumers] — Only example echo consumer exists

- **AC not met**: `consumers.py` has an `ExampleConsumer` with echo logic only. No notification or exchange-specific WebSocket channels exist.
- **Evidence**: `routing.py` registers only `ws/example/`.
- **Fix needed**: Phase 2 adds a `NotificationConsumer` at `ws/notifications/` for real-time request alerts (replaces the example consumer). Full chat WebSocket is Epic 6 scope.
- **⚠️ DEFERRED**: WebSocket notification consumer was deprioritized in favor of HTTP polling (`useIncomingRequestCount` polls every 60s). Full WebSocket implementation deferred to Epic 6 (Chat).

_(No other gaps found in previously implemented stories that relate to Epic 5.)_

---

## 3. Implementation Plan — Epic 5: Exchange Flow

### Context

Epic 5 is the core transaction engine of BookSwap. It introduces the complete exchange lifecycle: requesting a swap, reviewing/responding, conditions acceptance, swap confirmation, and book returns. The target users are the **book seeker** (initiates a request with US-501), the **book owner** (reviews and responds with US-502), and both as **matched partners** (conditions acceptance US-503, swap confirmation US-504, returns US-505). This epic depends on Epics 1–4 being complete (users have accounts, books listed, and can discover each other). It enables Epic 6 (Messaging — chat unlocks after conditions acceptance) and Epic 7 (Ratings — triggered after swap confirmation).

### Stories Covered

- **US-501**: Send Book Partner Request (P0)
- **US-502**: Review & Respond to Partner Request (P0)
- **US-503**: Accept Exchange Conditions (P0)
- **US-504**: Confirm Exchange Completion (P0)
- **US-505**: Book Return Flow (P1)

---

### Phase 1 — Data Layer: Exchange Models & Migrations ✅ COMPLETE

> **Commit**: `5980c49` — `feat(exchanges): add Exchange app with models & migration — Epic 5 Phase 1`
>
> **Implementation note**: Models were placed in a separate `backend/apps/exchanges/` Django app (not inside `bookswap/`) per user request to keep the codebase maintainable. Added `DeclineReason.COUNTER_PROPOSED` choice for auto-decline on counter-propose.

**Goal**: Create the `ExchangeRequest` and `ConditionsAcceptance` models with all fields needed for the full exchange lifecycle, including status choices, constraints, and indexes.

**Files to create / modify**:
- `backend/bookswap/models.py` — add `ExchangeStatus`, `DeclineReason`, `ExchangeRequest`, `ConditionsAcceptance`
- `backend/bookswap/migrations/` — new migration

**What to build**:

#### 1a. `ExchangeStatus` (TextChoices)

```python
class ExchangeStatus(models.TextChoices):
    PENDING = 'pending', 'Pending'
    ACCEPTED = 'accepted', 'Accepted'                      # Owner accepted, awaiting conditions
    CONDITIONS_PENDING = 'conditions_pending', 'Conditions Pending'  # One user accepted conditions
    ACTIVE = 'active', 'Active'                            # Both accepted conditions
    SWAP_CONFIRMED = 'swap_confirmed', 'Swap Confirmed'    # Both confirmed the swap happened
    COMPLETED = 'completed', 'Completed'                   # Ratings done or 30-day window elapsed
    DECLINED = 'declined', 'Declined'
    CANCELLED = 'cancelled', 'Cancelled'
    EXPIRED = 'expired', 'Expired'
    RETURN_REQUESTED = 'return_requested', 'Return Requested'  # P1: return initiated
    RETURNED = 'returned', 'Returned'                       # P1: return confirmed
```

#### 1b. `DeclineReason` (TextChoices)

```python
class DeclineReason(models.TextChoices):
    NOT_INTERESTED = 'not_interested', 'Not interested in offered book'
    RESERVED = 'reserved', 'Book is reserved for someone else'
    OTHER = 'other', 'Other'
```

#### 1c. `ExchangeRequest` Model

| Field | Type | Notes |
|-------|------|-------|
| `id` | UUIDField (PK) | `default=uuid.uuid4` |
| `requester` | FK → User | `related_name='sent_exchanges'` |
| `owner` | FK → User | `related_name='received_exchanges'` |
| `requested_book` | FK → Book | The owner's book the requester wants; `related_name='incoming_requests'` |
| `offered_book` | FK → Book | The requester's book offered in exchange; `related_name='outgoing_requests'` |
| `status` | CharField | `choices=ExchangeStatus.choices`, default `PENDING`, `db_index=True` |
| `message` | CharField(200) | Optional personal note from requester |
| `decline_reason` | CharField(30) | `choices=DeclineReason.choices`, blank, null |
| `counter_to` | FK → self | Null; references original request when counter-proposed |
| `requester_confirmed_at` | DateTimeField | Null; set when requester confirms swap happened |
| `owner_confirmed_at` | DateTimeField | Null; set when owner confirms swap happened |
| `return_requested_at` | DateTimeField | Null; P1 — set when return is initiated |
| `return_confirmed_requester` | DateTimeField | Null; P1 — set when requester confirms return |
| `return_confirmed_owner` | DateTimeField | Null; P1 — set when owner confirms return |
| `expired_at` | DateTimeField | Null; set by Celery task when auto-expired |
| `created_at` | DateTimeField | `auto_now_add=True` (from `TimeStampedModel`) |
| `updated_at` | DateTimeField | `auto_now=True` (from `TimeStampedModel`) |

**Constraints**:
```python
class Meta:
    ordering = ['-created_at']
    constraints = [
        models.UniqueConstraint(
            fields=['requester', 'requested_book'],
            condition=models.Q(status='pending'),
            name='unique_pending_request_per_book',
        ),
    ]
    indexes = [
        models.Index(fields=['status', 'created_at'], name='exchange_status_created'),
        models.Index(fields=['requester', 'status'], name='exchange_requester_status'),
        models.Index(fields=['owner', 'status'], name='exchange_owner_status'),
    ]
```

#### 1d. `ConditionsAcceptance` Model

| Field | Type | Notes |
|-------|------|-------|
| `id` | UUIDField (PK) | `default=uuid.uuid4` |
| `exchange` | FK → ExchangeRequest | `related_name='conditions_acceptances'` |
| `user` | FK → User | The user accepting conditions |
| `accepted_at` | DateTimeField | `auto_now_add=True` |
| `conditions_version` | CharField(10) | e.g. `'1.0'`; allows grandfathering existing exchanges when conditions are updated |

**Constraints**:
```python
class Meta:
    constraints = [
        models.UniqueConstraint(
            fields=['exchange', 'user'],
            name='unique_conditions_per_user_per_exchange',
        ),
    ]
```

#### 1e. Extend `ExchangeRequest` with helper methods

```python
@property
def is_swap_confirmed(self) -> bool:
    return self.requester_confirmed_at is not None and self.owner_confirmed_at is not None

@property
def is_return_confirmed(self) -> bool:
    return self.return_confirmed_requester is not None and self.return_confirmed_owner is not None

def both_conditions_accepted(self) -> bool:
    return self.conditions_acceptances.count() == 2
```

#### 1f. Valid State Transitions

Define an explicit state machine map used by the API actions to validate transitions:

```python
VALID_TRANSITIONS = {
    ExchangeStatus.PENDING: [ExchangeStatus.ACCEPTED, ExchangeStatus.DECLINED, ExchangeStatus.CANCELLED, ExchangeStatus.EXPIRED],
    ExchangeStatus.ACCEPTED: [ExchangeStatus.CONDITIONS_PENDING, ExchangeStatus.CANCELLED, ExchangeStatus.EXPIRED],
    ExchangeStatus.CONDITIONS_PENDING: [ExchangeStatus.ACTIVE, ExchangeStatus.CANCELLED, ExchangeStatus.EXPIRED],
    ExchangeStatus.ACTIVE: [ExchangeStatus.SWAP_CONFIRMED, ExchangeStatus.CANCELLED],
    ExchangeStatus.SWAP_CONFIRMED: [ExchangeStatus.COMPLETED, ExchangeStatus.RETURN_REQUESTED],
    ExchangeStatus.RETURN_REQUESTED: [ExchangeStatus.RETURNED],
    # Terminal states — no transitions out:
    ExchangeStatus.DECLINED: [],
    ExchangeStatus.CANCELLED: [],
    ExchangeStatus.EXPIRED: [],
    ExchangeStatus.COMPLETED: [],
    ExchangeStatus.RETURNED: [],
}
```

**Acceptance criteria addressed**: US-501 AC5 (pending status), US-501 AC8 (unique constraint), US-502 AC5 (decline reason), US-503 AC5 (timestamped conditions with version), US-504 AC2/AC3 (two-phase confirmation fields)

---

### Phase 2 — Backend API: Exchange Endpoints & Celery Tasks ✅ COMPLETE

> **Commit**: `616f1a4` — `feat(exchanges): add Backend API — Epic 5 Phase 2`
>
> **Implementation notes**:
> - All 14 endpoints implemented in `backend/apps/exchanges/views.py` as `ExchangeRequestViewSet`
> - 8 serializer classes in `backend/apps/exchanges/serializers.py`
> - 3 permission classes in `backend/apps/exchanges/permissions.py`
> - 3 Celery tasks in `backend/apps/exchanges/tasks.py` with Beat schedule in `config/settings/base.py`
> - 46 backend tests passing in `backend/apps/exchanges/tests/test_exchange_api.py`
> - WebSocket `NotificationConsumer` was **deferred** — using HTTP polling instead (`useIncomingRequestCount` at 60s intervals)
> - Fixed `pytest.ini` with `--ds=config.settings.test` to override Docker's dev settings
> - Fixed `config/settings/test.py` to filter out `HTTPSRedirectMiddleware`
> - Fixed stale prefetch cache on `ConditionsAcceptance` creation (`_prefetched_objects_cache.pop`)

**Goal**: Expose the exchange flow through authenticated REST endpoints with proper permissions, state machine transitions, and background task for auto-expiry.

**Files to create / modify**:
- `backend/bookswap/serializers.py` — add exchange serializers
- `backend/bookswap/views.py` — add `ExchangeRequestViewSet`
- `backend/bookswap/urls.py` — register exchange routes
- `backend/bookswap/permissions.py` — add `IsExchangeParticipant`, `IsExchangeOwner`, `IsExchangeRequester`
- `backend/bookswap/tasks.py` — add `expire_stale_requests`, `auto_confirm_stale_swaps`, `expire_stale_conditions`
- `backend/bookswap/consumers.py` — add `NotificationConsumer` for real-time request alerts
- `backend/bookswap/routing.py` — register notification WebSocket route
- `backend/config/settings/base.py` — add Celery Beat schedule entries

**Serializers to build**:

#### 2a. `ExchangeRequestCreateSerializer`

Validates:
- `requested_book_id` → book must exist, be `available`, NOT owned by `request.user`
- `offered_book_id` → book must exist, be `available`, owned by `request.user`
- `message` → optional, max 200 chars
- User must have at least 1 available book (checked in create)
- No duplicate pending request (handled by DB constraint, but catch `IntegrityError` for friendly message)

#### 2b. `ExchangeRequestListSerializer`

Compact serializer for list views:
- `id`, `status`, `message`, `created_at`, `updated_at`
- Nested: `requester` (id, username, avatar, avg_rating, swap_count), `owner` (same)
- Nested: `requested_book` (id, title, author, cover_url, condition, primary_photo), `offered_book` (same)

#### 2c. `ExchangeRequestDetailSerializer`

Full detail extending list serializer:
- All list fields plus `decline_reason`, `counter_to`, confirmation timestamps
- `conditions_accepted_by_me` — `SerializerMethodField` checking if `request.user` has a `ConditionsAcceptance` row
- `conditions_accepted_count` — how many users have accepted (0, 1, or 2)
- `conditions_version` — current platform conditions version

#### 2d. `CounterProposeSerializer`

Validates:
- `offered_book_id` → must be a different book from the original offer; must be owned by the counter-proposing owner; must be `available`

#### 2e. `DeclineSerializer`

Validates:
- `reason` → optional, must be a valid `DeclineReason` choice

#### 2f. `ConditionsAcceptanceSerializer`

- Read-only: `id`, `exchange`, `user`, `accepted_at`, `conditions_version`

**Endpoints to build**:

| Method | Path | Auth | Description | Story |
|--------|------|------|-------------|-------|
| POST | `/api/v1/exchanges/` | IsAuthenticated | Create a new exchange request | US-501 |
| GET | `/api/v1/exchanges/` | IsAuthenticated | List user's exchanges (sent + received) | US-501, US-502 |
| GET | `/api/v1/exchanges/{id}/` | IsAuthenticated + IsExchangeParticipant | Exchange detail | US-501, US-502 |
| POST | `/api/v1/exchanges/{id}/accept/` | IsAuthenticated + IsExchangeOwner | Accept a request → status `accepted` | US-502 |
| POST | `/api/v1/exchanges/{id}/decline/` | IsAuthenticated + IsExchangeOwner | Decline a request → status `declined` | US-502 |
| POST | `/api/v1/exchanges/{id}/counter/` | IsAuthenticated + IsExchangeOwner | Counter-propose with a different book | US-502 |
| POST | `/api/v1/exchanges/{id}/cancel/` | IsAuthenticated + IsExchangeRequester | Cancel own pending request | US-501 |
| POST | `/api/v1/exchanges/{id}/accept-conditions/` | IsAuthenticated + IsExchangeParticipant | Accept exchange conditions | US-503 |
| GET | `/api/v1/exchanges/{id}/conditions/` | IsAuthenticated + IsExchangeParticipant | Get conditions text + acceptance status | US-503 |
| POST | `/api/v1/exchanges/{id}/confirm-swap/` | IsAuthenticated + IsExchangeParticipant | Confirm swap happened | US-504 |
| POST | `/api/v1/exchanges/{id}/request-return/` | IsAuthenticated + IsExchangeParticipant | Initiate return (P1) | US-505 |
| POST | `/api/v1/exchanges/{id}/confirm-return/` | IsAuthenticated + IsExchangeParticipant | Confirm return happened (P1) | US-505 |
| GET | `/api/v1/exchanges/incoming/` | IsAuthenticated | List incoming requests (owner perspective) | US-502 |
| GET | `/api/v1/exchanges/incoming/count/` | IsAuthenticated | Count of pending incoming requests (for nav badge) | US-502 |

**Action logic for key endpoints**:

#### Accept (`POST /accept/`)
1. Validate: status must be `pending`, user must be the owner
2. Transition: status → `accepted`
3. Auto-decline all OTHER pending requests for the same `requested_book` with message "This book has been matched with another reader" (US-502 EC1)
4. Notify requester via Celery task
5. Return updated exchange detail

#### Decline (`POST /decline/`)
1. Validate: status must be `pending`, user must be the owner
2. Transition: status → `declined`
3. Set `decline_reason` if provided
4. Notify requester via Celery task
5. Return updated exchange detail

#### Counter (`POST /counter/`)
1. Validate: status must be `pending`, user must be the owner
2. Create a NEW `ExchangeRequest` with `counter_to` referencing the original
3. Original request status → `declined` (with reason "counter_proposed")
4. New request: requester = original requester, owner = original owner, `requested_book` = original `requested_book`, `offered_book` = the book the owner picked from the requester's shelf
5. Notify requester: "The owner would prefer a different book from you"
6. Return the new exchange detail

#### Cancel (`POST /cancel/`)
1. Validate: status must be `pending`, user must be the requester
2. Transition: status → `cancelled`
3. No notification to owner (silent cancel)

#### Accept Conditions (`POST /accept-conditions/`)
1. Validate: status must be `accepted` or `conditions_pending`, user must be a participant
2. Create `ConditionsAcceptance` row (unique constraint prevents duplicates)
3. If this is the first acceptance: transition status → `conditions_pending`
4. If both users have now accepted: transition status → `active`
5. Return updated exchange detail with conditions status

#### Confirm Swap (`POST /confirm-swap/`)
1. Validate: status must be `active`, user must be a participant
2. Set `requester_confirmed_at` or `owner_confirmed_at` based on who the user is
3. If both timestamps are now set:
   - Transition status → `swap_confirmed`
   - Update both books: `requested_book.status` → `in_exchange`, `offered_book.status` → `in_exchange`
   - Increment `User.swap_count` for both users (using `F()` expression)
   - Trigger rating prompt (placeholder for Epic 7)
4. Return updated exchange detail

**Permissions**:

```python
class IsExchangeParticipant(BasePermission):
    """Allow access only to the requester or owner of the exchange."""
    def has_object_permission(self, request, view, obj):
        return request.user.id in (obj.requester_id, obj.owner_id)

class IsExchangeOwner(BasePermission):
    """Allow access only to the owner (book holder) of the exchange."""
    def has_object_permission(self, request, view, obj):
        return request.user.id == obj.owner_id

class IsExchangeRequester(BasePermission):
    """Allow access only to the requester who initiated the exchange."""
    def has_object_permission(self, request, view, obj):
        return request.user.id == obj.requester_id
```

**Celery Tasks**:

#### `expire_stale_requests` (daily at 02:00)
- Query: `ExchangeRequest.objects.filter(status='pending', created_at__lte=now - 14 days)`
- Set: `status → 'expired'`, `expired_at → now()`
- Notify both parties per expired request
- Addresses US-502 EC3

#### `expire_stale_conditions` (daily at 02:30)
- Query: `ExchangeRequest.objects.filter(status__in=['accepted', 'conditions_pending'], updated_at__lte=now - 14 days)`
- First check: if 7 days have passed since acceptance and < 14 days → send reminder (only once, tracked by a `reminder_sent` flag or by checking if time is between 7–8 days)
- After 14 days: set `status → 'expired'`, `expired_at → now()`
- Notify both parties
- Addresses US-503 EC1

#### `auto_confirm_stale_swaps` (weekly, Monday at 04:00)
- Query: `ExchangeRequest.objects.filter(status='active')` where ONE confirmation exists but the other is missing for 60+ days
- Auto-fill the missing confirmation timestamp
- Transition: status → `swap_confirmed`, update book statuses, increment swap counts
- Notify both parties
- Addresses US-504 EC1

**Celery Beat Schedule** (add to `config/settings/base.py`):
```python
'expire-stale-exchange-requests': {
    'task': 'bookswap.expire_stale_requests',
    'schedule': crontab(hour=2, minute=0),  # Daily at 2am
},
'expire-stale-conditions': {
    'task': 'bookswap.expire_stale_conditions',
    'schedule': crontab(hour=2, minute=30),  # Daily at 2:30am
},
'auto-confirm-stale-swaps': {
    'task': 'bookswap.auto_confirm_stale_swaps',
    'schedule': crontab(hour=4, minute=0, day_of_week=1),  # Weekly Monday 4am
},
```

**WebSocket Notification** (lightweight, for nav badge update):
- Replace `ExampleConsumer` with `NotificationConsumer` at `ws/notifications/`
- On connect: join user-specific group `user_{user_id}`
- On exchange events (request created, accepted, declined, etc.): Celery task sends to group
- Frontend listens for `{ type: 'exchange_update', exchange_id, status, message }` to update badge count

**Nimoh-stack conventions to follow**:
- UUID PKs, `created_at`/`updated_at` on every model (via `TimeStampedModel`)
- `get_queryset()` scoped to `request.user` (participant filter)
- `permission_classes` declared explicitly on every view and action
- Split list serializer from detail serializer
- Validation via serializer; state transitions checked in the view action methods
- Use `select_related('requester', 'owner', 'requested_book', 'offered_book')` to avoid N+1

**Acceptance criteria addressed**: US-501 AC1–AC8; US-502 AC1–AC7; US-503 AC1–AC7; US-504 AC1–AC6; US-505 AC1–AC5

---

### Phase 3 — Frontend: Exchange Services, Hooks & Types ✅ COMPLETE

> **Commit**: `52e0f98` — `feat(exchanges): add Frontend services, hooks & types — Epic 5 Phase 3`
>
> **Files created** (11 files):
> - `frontend/src/features/exchanges/types/exchange.types.ts` — 11 status types, full interfaces
> - `frontend/src/features/exchanges/services/exchange.service.ts` — 14 endpoint wrappers
> - `frontend/src/features/exchanges/hooks/exchangeKeys.ts` — TanStack Query key factory
> - `frontend/src/features/exchanges/hooks/useExchanges.ts`, `useExchange.ts`, `useIncomingRequests.ts`, `useIncomingRequestCount.ts` (60s polling)
> - `frontend/src/features/exchanges/hooks/useExchangeMutations.ts` — 9 mutation hooks
> - `frontend/src/features/exchanges/schemas/exchange.schemas.ts` — 3 Zod schemas
> - `frontend/src/features/exchanges/index.ts` — barrel export
> - Updated `frontend/src/configs/apiEndpoints.ts` with exchanges group (14 endpoints)

**Goal**: Wire the exchange API into the frontend data layer with TypeScript types, axios service, TanStack Query hooks, and Zod schemas.

**Files to create**:
- `frontend/src/features/exchanges/types/exchange.types.ts` — TypeScript interfaces
- `frontend/src/features/exchanges/services/exchange.service.ts` — axios wrappers
- `frontend/src/features/exchanges/hooks/exchangeKeys.ts` — TanStack Query key factory
- `frontend/src/features/exchanges/hooks/useExchanges.ts` — list query hook (all user exchanges)
- `frontend/src/features/exchanges/hooks/useExchange.ts` — detail query hook (single exchange)
- `frontend/src/features/exchanges/hooks/useIncomingRequests.ts` — query hook for owner's incoming requests
- `frontend/src/features/exchanges/hooks/useIncomingRequestCount.ts` — query hook for nav badge count
- `frontend/src/features/exchanges/hooks/useExchangeMutations.ts` — mutation hooks (create, accept, decline, counter, cancel, accept-conditions, confirm-swap, request-return, confirm-return)
- `frontend/src/features/exchanges/schemas/exchange.schema.ts` — Zod validation schemas
- `frontend/src/features/exchanges/index.ts` — barrel export

**Files to modify**:
- `frontend/src/configs/apiEndpoints.ts` — add `exchanges` group

**Key patterns**:

#### 3a. API Endpoints

```typescript
const EXCHANGES = `${V1}/exchanges` as const;

exchanges: {
  list: `${EXCHANGES}/`,
  detail: (id: string) => `${EXCHANGES}/${id}/`,
  create: `${EXCHANGES}/`,
  accept: (id: string) => `${EXCHANGES}/${id}/accept/`,
  decline: (id: string) => `${EXCHANGES}/${id}/decline/`,
  counter: (id: string) => `${EXCHANGES}/${id}/counter/`,
  cancel: (id: string) => `${EXCHANGES}/${id}/cancel/`,
  acceptConditions: (id: string) => `${EXCHANGES}/${id}/accept-conditions/`,
  conditions: (id: string) => `${EXCHANGES}/${id}/conditions/`,
  confirmSwap: (id: string) => `${EXCHANGES}/${id}/confirm-swap/`,
  requestReturn: (id: string) => `${EXCHANGES}/${id}/request-return/`,
  confirmReturn: (id: string) => `${EXCHANGES}/${id}/confirm-return/`,
  incoming: `${EXCHANGES}/incoming/`,
  incomingCount: `${EXCHANGES}/incoming/count/`,
},
```

#### 3b. TypeScript Types

```typescript
export type ExchangeStatus =
  | 'pending' | 'accepted' | 'conditions_pending' | 'active'
  | 'swap_confirmed' | 'completed' | 'declined' | 'cancelled'
  | 'expired' | 'return_requested' | 'returned';

export type DeclineReason = 'not_interested' | 'reserved' | 'other';

export interface ExchangeParticipant {
  id: string;
  username: string;
  avatar: string | null;
  avg_rating: number | null;
  swap_count: number;
}

export interface ExchangeBook {
  id: string;
  title: string;
  author: string;
  cover_url: string;
  condition: string;
  primary_photo: string | null;
}

export interface ExchangeListItem {
  id: string;
  status: ExchangeStatus;
  message: string;
  requester: ExchangeParticipant;
  owner: ExchangeParticipant;
  requested_book: ExchangeBook;
  offered_book: ExchangeBook;
  created_at: string;
  updated_at: string;
}

export interface ExchangeDetail extends ExchangeListItem {
  decline_reason: DeclineReason | null;
  counter_to: string | null;
  requester_confirmed_at: string | null;
  owner_confirmed_at: string | null;
  conditions_accepted_by_me: boolean;
  conditions_accepted_count: number;
  conditions_version: string;
}

export interface CreateExchangePayload {
  requested_book_id: string;
  offered_book_id: string;
  message?: string;
}

export interface CounterProposePayload {
  offered_book_id: string;
}

export interface DeclinePayload {
  reason?: DeclineReason;
}
```

#### 3c. TanStack Query Key Factory

```typescript
export const exchangeKeys = {
  all: ['exchanges'] as const,
  lists: () => [...exchangeKeys.all, 'list'] as const,
  list: (filters?: Record<string, unknown>) => [...exchangeKeys.lists(), filters] as const,
  details: () => [...exchangeKeys.all, 'detail'] as const,
  detail: (id: string) => [...exchangeKeys.details(), id] as const,
  incoming: () => [...exchangeKeys.all, 'incoming'] as const,
  incomingList: (filters?: Record<string, unknown>) => [...exchangeKeys.incoming(), 'list', filters] as const,
  incomingCount: () => [...exchangeKeys.incoming(), 'count'] as const,
};
```

#### 3d. Mutation Hooks

Group mutations in `useExchangeMutations.ts`:
- `useCreateExchange` — POST → invalidates `exchangeKeys.lists()` + browse queries (book may become less available)
- `useAcceptExchange` — POST → invalidates `exchangeKeys.detail(id)`, `exchangeKeys.incoming()`
- `useDeclineExchange` — POST → invalidates same
- `useCounterExchange` — POST → invalidates same + creates new exchange
- `useCancelExchange` — POST → invalidates `exchangeKeys.detail(id)`, `exchangeKeys.lists()`
- `useAcceptConditions` — POST → invalidates `exchangeKeys.detail(id)`
- `useConfirmSwap` — POST → invalidates `exchangeKeys.detail(id)`, user profile (swap_count)
- `useRequestReturn` — POST → invalidates `exchangeKeys.detail(id)`
- `useConfirmReturn` — POST → invalidates `exchangeKeys.detail(id)`

Each mutation uses `onSuccess` to invalidate relevant queries and show a toast notification.

#### 3e. Zod Schemas

```typescript
export const createExchangeSchema = z.object({
  requested_book_id: z.string().uuid(),
  offered_book_id: z.string().uuid(),
  message: z.string().max(200).optional(),
});

export const declineSchema = z.object({
  reason: z.enum(['not_interested', 'reserved', 'other']).optional(),
});

export const counterProposeSchema = z.object({
  offered_book_id: z.string().uuid(),
});
```

**Nimoh-stack conventions to follow**:
- `credentials: 'include'` on the API client (already configured in `http.ts`)
- Key factory pattern matching existing `bookKeys` and `discoveryKeys` conventions
- No access token in localStorage — Zustand memory store for auth (already in place)
- Toast notifications via existing notification system

**Acceptance criteria addressed**: US-501 AC5 (pending status tracking), US-502 AC1 (incoming count), US-503 AC5 (conditions acceptance tracking)

---

### Phase 4 — Frontend UI: Exchange Pages & Components ✅ COMPLETE

> **Commit**: `a11221e` — `feat(exchanges): add Frontend UI pages & components — Epic 5 Phase 4`
>
> **Implementation notes**:
> - Created 3 pages: `ExchangesPage` (3 tabs), `ExchangeDetailPage` (timeline + contextual actions), `IncomingRequestsPage`
> - Created 3 components: `ExchangeStatusBadge` (11 statuses), `ExchangeCard`, `RequestSwapButton` (inline book picker, not modal-based)
> - Added routes: `/exchanges`, `/exchanges/incoming`, `/exchanges/:id` with `ProtectedPage` wrapper
> - Added Header nav link for authenticated users
> - Integrated `RequestSwapButton` into `BookDetailPage` (replaced placeholder button)
> - Added i18n: `exchanges` namespace (en + fr), updated i18next config ns array
> - **Design decisions**: Simplified from plan — used inline book picker in `RequestSwapButton` instead of separate modal. Combined timeline + actions in `ExchangeDetailPage` instead of separate components. No Dutch (nl) translations added (only en + fr per existing pattern).

**Goal**: Build the pages and components for the full exchange flow — request modal, incoming requests, conditions acceptance, swap confirmation.

**Files to create**:
- `frontend/src/features/exchanges/components/RequestSwapModal/RequestSwapModal.tsx` — modal to create a swap request
- `frontend/src/features/exchanges/components/RequestSwapModal/index.ts`
- `frontend/src/features/exchanges/components/RequestSwapModal/BookOfferPicker.tsx` — pick from your available books
- `frontend/src/features/exchanges/components/RequestSwapButton/RequestSwapButton.tsx` — "Request Swap" button for book cards/detail
- `frontend/src/features/exchanges/components/RequestSwapButton/index.ts`
- `frontend/src/features/exchanges/components/ExchangeCard/ExchangeCard.tsx` — card showing exchange summary in lists
- `frontend/src/features/exchanges/components/ExchangeCard/index.ts`
- `frontend/src/features/exchanges/components/IncomingRequestCard/IncomingRequestCard.tsx` — incoming request with Accept/Decline/Counter buttons
- `frontend/src/features/exchanges/components/IncomingRequestCard/index.ts`
- `frontend/src/features/exchanges/components/DeclineModal/DeclineModal.tsx` — decline reason picker modal
- `frontend/src/features/exchanges/components/DeclineModal/index.ts`
- `frontend/src/features/exchanges/components/CounterModal/CounterModal.tsx` — counter-propose: browse requester's shelf
- `frontend/src/features/exchanges/components/CounterModal/index.ts`
- `frontend/src/features/exchanges/components/ConditionsView/ConditionsView.tsx` — scrollable conditions text with checkbox
- `frontend/src/features/exchanges/components/ConditionsView/index.ts`
- `frontend/src/features/exchanges/components/ConditionsView/conditions-content.ts` — versioned conditions text (v1.0)
- `frontend/src/features/exchanges/components/SwapConfirmation/SwapConfirmation.tsx` — confirm swap + partner status indicator
- `frontend/src/features/exchanges/components/SwapConfirmation/index.ts`
- `frontend/src/features/exchanges/components/ExchangeStatusBadge/ExchangeStatusBadge.tsx` — colored status badge
- `frontend/src/features/exchanges/components/ExchangeStatusBadge/index.ts`
- `frontend/src/features/exchanges/components/ExchangeTimeline/ExchangeTimeline.tsx` — vertical timeline showing exchange progression
- `frontend/src/features/exchanges/components/ExchangeTimeline/index.ts`
- `frontend/src/features/exchanges/components/EmptyShelfPrompt/EmptyShelfPrompt.tsx` — "List a book first to start swapping!"
- `frontend/src/features/exchanges/components/EmptyShelfPrompt/index.ts`
- `frontend/src/features/exchanges/pages/ExchangesPage.tsx` — "My Exchanges" list page with tabs (Active / Pending / History)
- `frontend/src/features/exchanges/pages/ExchangeDetailPage.tsx` — single exchange detail with timeline and actions
- `frontend/src/features/exchanges/pages/IncomingRequestsPage.tsx` — owner's incoming requests view
- `frontend/src/features/exchanges/i18n/en.json` — English strings
- `frontend/src/features/exchanges/i18n/fr.json` — French strings
- `frontend/src/features/exchanges/i18n/nl.json` — Dutch strings

**Files to modify**:
- `frontend/src/routes/config/paths.ts` — add exchange paths
- `frontend/src/routes/config/routesConfig.tsx` — register exchange routes (under PrivateRoute)
- `frontend/src/configs/apiEndpoints.ts` — add exchanges group (done in Phase 3)
- Book detail page (`frontend/src/features/books/pages/BookDetailPage/`) — add `RequestSwapButton`
- Book card component — add `RequestSwapButton` (conditionally, for available books not owned by current user)
- Navigation/Header component — add "Requests" badge with incoming count from `useIncomingRequestCount`

**Routes to register**:

| Path | Component | Guard |
|------|-----------|-------|
| `/exchanges` | `ExchangesPage` | PrivateRoute |
| `/exchanges/:id` | `ExchangeDetailPage` | PrivateRoute |
| `/exchanges/incoming` | `IncomingRequestsPage` | PrivateRoute |

**Component details**:

#### 4a. `RequestSwapButton`

- Shown on book detail page and browse book cards for available books NOT owned by current user
- If user has no available books → shows `EmptyShelfPrompt` tooltip/modal instead
- If user already has a pending request for this book → shows "Request Sent" (disabled)
- On click → opens `RequestSwapModal`

#### 4b. `RequestSwapModal`

- Left side: the requested book (their book) — read-only display
- Right side: `BookOfferPicker` — grid/list of user's available books to select one
- Bottom: optional message textarea (max 200 chars with character counter)
- "Send Request" button — calls `useCreateExchange` mutation
- Success → close modal, show toast "Request sent!", navigate to exchange detail or stay

#### 4c. `BookOfferPicker`

- Fetches user's available books via `GET /api/v1/books/?owner=me&status=available`
- Displays as a selectable grid with radio-button selection
- Empty state: "You don't have any books to offer. List a book first!"

#### 4d. `IncomingRequestsPage`

- Tab in navigation with unread count badge (from `useIncomingRequestCount`)
- Lists `IncomingRequestCard` components
- Each card shows: requester info (avatar, name, rating, swap count), their offered book, your book they want
- Three action buttons: Accept, Decline, Counter
- Accept → triggers conditions acceptance flow (navigates to exchange detail with conditions view)
- Decline → opens `DeclineModal` with reason picker
- Counter → opens `CounterModal` which shows the requester's shelf for the owner to pick a different book

#### 4e. `ConditionsView`

- Scrollable container with the platform exchange conditions (hardcoded v1.0, from `conditions-content.ts`)
- Must scroll to bottom (tracked via `IntersectionObserver` on last paragraph) before checkbox becomes enabled
- Checkbox: "I have read and agree to the exchange conditions"
- "Confirm" button — calls `useAcceptConditions` mutation
- Shows partner's acceptance status: "Waiting for [partner] to accept the exchange conditions" or "✓ [partner] accepted"
- When both accept: celebration animation + "Exchange is now active! Chat will be unlocked." (chat is Epic 6)

#### 4f. `SwapConfirmation`

- Shown in exchange detail page when status is `active`
- "Confirm Swap" button for the current user
- Shows partner status: "✓ [partner] confirmed" or "Waiting for [partner]"
- When both confirm: exchange status → `swap_confirmed`, books status updates, swap count increments
- Shows: "Swap confirmed! You can now rate your partner." with link to rating (Epic 7 placeholder)

#### 4g. `ExchangeDetailPage`

- Shows `ExchangeTimeline` (visual progression: Requested → Accepted → Conditions → Active → Swap Confirmed → Completed)
- Shows both books side-by-side (requested + offered)
- Shows both participants' info
- Renders contextual actions based on status:
  - `pending` (requester): Cancel button
  - `pending` (owner): Accept/Decline/Counter buttons
  - `accepted` / `conditions_pending`: ConditionsView
  - `active`: SwapConfirmation + future chat link (Epic 6)
  - `swap_confirmed`: Rating prompt link (Epic 7) + Return button (US-505)
  - `declined` / `cancelled` / `expired`: Read-only summary

#### 4h. `ExchangesPage` (My Exchanges)

Three tabs:
- **Active** — status ∈ {`accepted`, `conditions_pending`, `active`, `swap_confirmed`}
- **Pending** — status = `pending` (both sent and received)
- **History** — status ∈ {`completed`, `declined`, `cancelled`, `expired`, `returned`}

Each tab shows `ExchangeCard` components with status badge, book thumbnails, partner info, and timestamp.

**UX notes** (from user stories):
- US-501 AC6: Requester sees "Request Sent" status on the book; can cancel before the owner responds
- US-502 AC7: Pending requests display on the book's detail page: "1 pending request" (only visible to the owner)
- US-503 AC6: Until BOTH users have accepted — no chat access, no profile details beyond public info
- US-504 AC6: Chat remains accessible (read-only) for reference but no new messages (after swap confirmed — Epic 6 wiring)
- US-501 AC3: User must have at least 1 available book to interact with "Request Swap"

**i18n strings** (namespace: `exchanges`):
- `exchanges.request.title` — "Request a Swap"
- `exchanges.request.selectBook` — "Select a book to offer"
- `exchanges.request.message.placeholder` — "Add a personal note (optional)"
- `exchanges.request.message.counter` — "{{count}}/200"
- `exchanges.request.send` — "Send Request"
- `exchanges.request.sent` — "Request Sent"
- `exchanges.request.cancel` — "Cancel Request"
- `exchanges.request.noBooks` — "List a book first to start swapping!"
- `exchanges.incoming.title` — "Incoming Requests"
- `exchanges.incoming.empty` — "No incoming requests"
- `exchanges.incoming.accept` — "Accept"
- `exchanges.incoming.decline` — "Decline"
- `exchanges.incoming.counter` — "Counter"
- `exchanges.decline.title` — "Decline Request"
- `exchanges.decline.reason.not_interested` — "Not interested in offered book"
- `exchanges.decline.reason.reserved` — "Book is reserved for someone else"
- `exchanges.decline.reason.other` — "Other"
- `exchanges.conditions.title` — "Exchange Conditions"
- `exchanges.conditions.agree` — "I have read and agree to the exchange conditions"
- `exchanges.conditions.confirm` — "Confirm"
- `exchanges.conditions.waiting` — "Waiting for {{partner}} to accept the exchange conditions"
- `exchanges.conditions.accepted` — "{{partner}} accepted the conditions"
- `exchanges.conditions.bothAccepted` — "Exchange is now active!"
- `exchanges.swap.confirm` — "Confirm Swap"
- `exchanges.swap.waiting` — "Waiting for {{partner}} to confirm the swap"
- `exchanges.swap.confirmed` — "Swap confirmed!"
- `exchanges.swap.ratePartner` — "Rate your swap partner"
- `exchanges.status.pending` — "Pending"
- `exchanges.status.accepted` — "Accepted"
- `exchanges.status.conditions_pending` — "Awaiting Conditions"
- `exchanges.status.active` — "Active"
- `exchanges.status.swap_confirmed` — "Swap Confirmed"
- `exchanges.status.completed` — "Completed"
- `exchanges.status.declined` — "Declined"
- `exchanges.status.cancelled` — "Cancelled"
- `exchanges.status.expired` — "Expired"
- `exchanges.tabs.active` — "Active"
- `exchanges.tabs.pending` — "Pending"
- `exchanges.tabs.history` — "History"
- `exchanges.empty.active` — "No active exchanges"
- `exchanges.empty.pending` — "No pending requests"
- `exchanges.empty.history` — "No exchange history yet"
- `exchanges.error.unavailable` — "This book is no longer available."
- `exchanges.error.duplicate` — "You already have a pending request for this book."
- `exchanges.auto.declined` — "This book has been matched with another reader"
- `exchanges.auto.expired` — "This request has expired"

**Acceptance criteria addressed**: US-501 AC1–AC4, AC6; US-502 AC1–AC6; US-503 AC1–AC6; US-504 AC1–AC6

---

### Phase 5 — Book Return Flow (P1 — US-505) ✅ COMPLETE (merged into Phase 4)

> **No separate commit** — return flow was built directly into Phase 4's `ExchangeDetailPage`.
>
> **Implementation notes**:
> - Backend return endpoints (`request_return`, `confirm_return`) were part of Phase 2 commit `616f1a4`
> - Frontend mutation hooks (`useRequestReturn`, `useConfirmReturn`) were part of Phase 3 commit `52e0f98`
> - UI actions rendered in `ExchangeDetailPage` when status is `swap_confirmed` ("Request Return" button) and `return_requested` ("Confirm Return" button)
> - i18n return strings included in Phase 4 locale files
> - No separate `ReturnFlow` component was needed — inline rendering in `ExchangeDetailPage` was sufficient

**Goal**: Add the return request and two-phase return confirmation flow to the existing exchange detail page.

**Files to create**:
- `frontend/src/features/exchanges/components/ReturnFlow/ReturnFlow.tsx` — return request + confirmation UI
- `frontend/src/features/exchanges/components/ReturnFlow/index.ts`

**Files to modify**:
- `frontend/src/features/exchanges/pages/ExchangeDetailPage.tsx` — add `ReturnFlow` component when status is `swap_confirmed` or `return_requested`
- `frontend/src/features/exchanges/hooks/useExchangeMutations.ts` — already includes `useRequestReturn` and `useConfirmReturn` from Phase 3
- `frontend/src/features/exchanges/i18n/en.json` — add return strings
- `frontend/src/features/exchanges/i18n/fr.json` — add return strings
- `frontend/src/features/exchanges/i18n/nl.json` — add return strings

**What to build**:

#### 5a. Backend Return Actions (already defined in Phase 2 endpoints)

**Request Return** (`POST /request-return/`):
1. Validate: status must be `swap_confirmed`, user must be a participant
2. Set `return_requested_at = now()`
3. Transition status → `return_requested`
4. Re-open chat (set flag for Epic 6 to check)
5. Notify partner

**Confirm Return** (`POST /confirm-return/`):
1. Validate: status must be `return_requested`, user must be a participant
2. Set `return_confirmed_requester` or `return_confirmed_owner` based on who the user is
3. If both timestamps are set:
   - Transition status → `returned`
   - Update both books: `requested_book.status` → `available`, `offered_book.status` → `available`
4. Return updated exchange detail

#### 5b. `ReturnFlow` Component

- When status is `swap_confirmed`: shows "Request Return" button
- On click: calls `useRequestReturn` mutation → status becomes `return_requested`
- When status is `return_requested`: shows "Confirm Return" button for both users
- Shows partner status: "✓ [partner] confirmed return" or "Waiting for [partner]"
- When both confirm: "Books have been returned to your shelves!"

**i18n strings**:
- `exchanges.return.request` — "Request Return"
- `exchanges.return.confirm` — "Confirm Return"
- `exchanges.return.waiting` — "Waiting for {{partner}} to confirm the return"
- `exchanges.return.confirmed` — "Books returned to your shelves!"
- `exchanges.return.requested` — "Return requested — arrange via chat"

**Acceptance criteria addressed**: US-505 AC1–AC5

---

### Phase 6 — Integration Tests & Acceptance Criteria Check ✅ COMPLETE

> **Commit**: `3cd1c33` — `test(exchanges): add integration tests & MSW handlers — Epic 5 Phase 6`
>
> **Implementation notes**:
> - Added 14 exchange MSW handlers to `frontend/src/test/mocks/handlers.ts` with exported mock data
> - Created `frontend/src/features/exchanges/__tests__/exchanges.test.tsx` with 35 tests:
>   - ExchangeStatusBadge: 11 status variant tests
>   - ExchangeCard: 3 tests (info, link, date)
>   - ExchangesPage: 5 tests (loading, empty, tab switch, counts, badge)
>   - ExchangeDetailPage: 12 tests (loading, error, detail, cancel, accept/decline, conditions, confirm swap, return, declined state, timeline, message)
>   - IncomingRequestsPage: 4 tests (loading, empty, cards, title)
> - **Fixes applied during testing**: i18n fallback text mismatches, `getAllByRole('button')` for multiple element matches
> - **Final test counts**: 762 FE tests + 330 BE tests = **1,092 total passing**

**Goal**: Connect everything end-to-end and verify every AC is met.

**Tasks**:
- [ ] Register the exchange URLs in `backend/bookswap/urls.py`
- [ ] Verify `config/urls.py` includes `bookswap.urls` (already does: `path('api/v1/', include('bookswap.urls'))`)
- [ ] Add Celery Beat schedule entries in `config/settings/base.py`
- [ ] Update `backend/bookswap/routing.py` with notification WebSocket
- [ ] Add MSW handlers in `frontend/src/test/mocks/handlers/` for:
  - `POST /api/v1/exchanges/` — create exchange
  - `GET /api/v1/exchanges/` — list exchanges
  - `GET /api/v1/exchanges/:id/` — exchange detail
  - `POST /api/v1/exchanges/:id/accept/` — accept
  - `POST /api/v1/exchanges/:id/decline/` — decline
  - `POST /api/v1/exchanges/:id/counter/` — counter
  - `POST /api/v1/exchanges/:id/cancel/` — cancel
  - `POST /api/v1/exchanges/:id/accept-conditions/` — accept conditions
  - `GET /api/v1/exchanges/:id/conditions/` — get conditions
  - `POST /api/v1/exchanges/:id/confirm-swap/` — confirm swap
  - `GET /api/v1/exchanges/incoming/` — incoming requests
  - `GET /api/v1/exchanges/incoming/count/` — incoming count
- [ ] Write backend tests (`backend/bookswap/tests/test_exchange_api.py`):
  - **Request creation**: valid request → 201, missing offered book → 400, own book → 403, duplicate pending → 400, no available books → 400
  - **Accept flow**: owner accepts → status `accepted`, other pending requests auto-declined, non-owner → 403
  - **Decline flow**: owner declines → status `declined`, decline reason saved, non-owner → 403
  - **Counter flow**: new request created with `counter_to`, original declined, non-owner → 403
  - **Cancel flow**: requester cancels → status `cancelled`, non-requester → 403, non-pending → 400
  - **Conditions acceptance**: first accept → `conditions_pending`, both accept → `active`, duplicate accept → 400
  - **Swap confirmation**: first confirm → timestamp set, both confirm → `swap_confirmed`, books → `in_exchange`, swap_count incremented
  - **Return flow**: request return → `return_requested`, both confirm return → `returned`, books → `available`
  - **State machine**: invalid transitions rejected (e.g., accept a declined exchange → 400)
  - **Auto-expire**: test `expire_stale_requests` task expires 14-day-old pending requests
  - **Permissions**: non-participant → 403, unauthenticated → 401
  - **Edge cases**: book becomes unavailable during request → error, offered book in another swap → auto-cancel
- [ ] Write frontend tests (Vitest + Testing Library):
  - `RequestSwapModal` renders, selects offered book, sends request
  - `RequestSwapButton` disabled when no books / already requested
  - `EmptyShelfPrompt` shown when user has no available books
  - `IncomingRequestsPage` renders incoming requests from MSW data
  - `IncomingRequestCard` accept/decline/counter buttons call correct mutations
  - `DeclineModal` renders reason picker, submits decline
  - `ConditionsView` requires scroll + checkbox before confirm is enabled
  - `SwapConfirmation` shows waiting state / confirmed state
  - `ExchangeDetailPage` renders correct actions based on status
  - `ExchangesPage` tab switching (active/pending/history)
  - `ExchangeStatusBadge` renders correct color per status
  - `ExchangeTimeline` renders progression steps
- [ ] Verify all i18n strings are present in `en.json`, `nl.json`, `fr.json`
- [ ] Verify incoming request count badge in navigation updates on new request

**Acceptance Criteria Checklist**:

| Story | AC | Acceptance Criterion | Covered in Phase |
|-------|----|---------------------|-----------------|
| US-501 | AC1 | "Request Swap" button on every available book's detail page and card | Phase 4 (RequestSwapButton) |
| US-501 | AC2 | Modal showing requested book and selector for "Your offer" | Phase 4 (RequestSwapModal + BookOfferPicker) |
| US-501 | AC3 | Must have at least 1 available book (empty shelf prompt) | Phase 4 (EmptyShelfPrompt) |
| US-501 | AC4 | Optional message field (max 200 chars) | Phase 4 (RequestSwapModal textarea) |
| US-501 | AC5 | Request created with status `pending`, owner notified | Phase 2 (create endpoint + Celery task) |
| US-501 | AC6 | Requester sees "Request Sent", can cancel before owner responds | Phase 4 (RequestSwapButton state + cancel action) |
| US-501 | AC7 | Cannot request own book | Phase 2 (serializer validation) |
| US-501 | AC8 | No duplicate pending requests (unique constraint) | Phase 1 (DB constraint) + Phase 2 (friendly error) |
| US-502 | AC1 | "Requests" section with unread count | Phase 4 (IncomingRequestsPage + nav badge) |
| US-502 | AC2 | Request card with requester info and both books | Phase 4 (IncomingRequestCard) |
| US-502 | AC3 | Accept / Decline / Counter buttons | Phase 4 (IncomingRequestCard actions) |
| US-502 | AC4 | Accept triggers conditions step | Phase 2 (accept → `accepted`) + Phase 4 (navigate to conditions) |
| US-502 | AC5 | Decline with optional reason | Phase 2 (decline endpoint) + Phase 4 (DeclineModal) |
| US-502 | AC6 | Counter-propose with different book | Phase 2 (counter endpoint) + Phase 4 (CounterModal) |
| US-502 | AC7 | Pending request count on book detail (owner only) | Phase 4 (book detail modification) |
| US-503 | AC1 | Both users see "Review Conditions" screen after acceptance | Phase 4 (ConditionsView) |
| US-503 | AC2 | Conditions document content | Phase 4 (conditions-content.ts) |
| US-503 | AC3 | Must scroll through full conditions | Phase 4 (IntersectionObserver on last paragraph) |
| US-503 | AC4 | Checkbox + "Confirm" button | Phase 4 (ConditionsView) |
| US-503 | AC5 | Both acceptances timestamped with conditions version | Phase 1 (ConditionsAcceptance model) + Phase 2 (endpoint) |
| US-503 | AC6 | Until BOTH accept: no chat, no extended profile details | Phase 2 (status gate) + Phase 4 (UI gate) |
| US-503 | AC7 | After BOTH accept: exchange → ACTIVE, chat unlocks | Phase 2 (status transition) |
| US-504 | AC1 | "Confirm Swap" button visible for both users | Phase 4 (SwapConfirmation) |
| US-504 | AC2 | Each user clicks independently | Phase 2 (separate timestamp fields) |
| US-504 | AC3 | "Waiting for partner" after one confirms | Phase 4 (SwapConfirmation partner status) |
| US-504 | AC4 | Both confirm → `swap_confirmed`, books → `in_exchange` | Phase 2 (confirm-swap endpoint) |
| US-504 | AC5 | Rating prompt appears (Epic 7 placeholder) | Phase 4 (link/placeholder in UI) |
| US-504 | AC6 | Swap count incremented for both users | Phase 2 (F() increment in confirm-swap) |
| US-505 | AC1 | Either partner can initiate return request | Phase 5 (ReturnFlow) |
| US-505 | AC2 | Return arranged via chat (re-opens) | Phase 5 (chat re-open flag — Epic 6 wiring) |
| US-505 | AC3 | Both confirm return (two-phase) | Phase 2 (confirm-return endpoint) + Phase 5 (ReturnFlow) |
| US-505 | AC4 | Both books → `available` on original owner's shelves | Phase 2 (confirm-return logic) |
| US-505 | AC5 | Exchange marked as fully completed | Phase 2 (status → `returned`) |

**Edge Cases to handle**:

| Story | EC | Edge Case | Where to handle |
|-------|----|-----------|----------------|
| US-501 | EC1 | Book becomes unavailable after request page loads | Phase 2 — re-validate `requested_book.status == 'available'` on POST; return 400 with "This book is no longer available" |
| US-501 | EC2 | Offered book accepted in another swap before owner reviews | Phase 2 — Celery task or signal: when a book's status changes from `available`, auto-cancel any pending requests where it's the `offered_book` |
| US-501 | EC3 | User blocked by book owner | Phase 2 — placeholder filter (Epic 8 Block model); RequestSwapButton hidden if blocked |
| US-502 | EC1 | Multiple requests for same book → accept one, auto-decline others | Phase 2 — accept action auto-declines other pending requests for `requested_book` |
| US-502 | EC2 | Counter-propose: requester's alternative also in pending request | Phase 2 — warn in counter response if selected book has pending requests |
| US-502 | EC3 | Request unanswered for 14 days → auto-expire | Phase 2 — `expire_stale_requests` Celery Beat task |
| US-503 | EC1 | One user doesn't accept conditions for 14 days | Phase 2 — `expire_stale_conditions` Celery task with 7-day reminder + 14-day auto-cancel |
| US-503 | EC2 | Conditions updated → new version; existing grandfathered | Phase 1 — `conditions_version` field; Phase 4 — `conditions-content.ts` with version |
| US-503 | EC3 | User tries to access chat before both accept | Phase 4 — UI gate: show "Waiting for partner" message; Phase 2 — API gate on chat endpoints (Epic 6) |
| US-504 | EC1 | One user confirms, other never does (60 days) | Phase 2 — `auto_confirm_stale_swaps` weekly Celery task |
| US-504 | EC2 | Cancel exchange after conditions but before meeting | Phase 2 — cancel action checks status ∈ {`accepted`, `conditions_pending`, `active`}; books → `available`; track cancellation |
| US-505 | EC1 | One party wants return, other doesn't | Phase 5 — no enforcement in MVP; social contract per spec |
| US-505 | EC2 | Books damaged during exchange | Phase 5 — handled via report/dispute (US-803), not return flow |

---

## 4. What's Not in This Plan

| Item | Reason |
|------|--------|
| **In-app chat (US-601)** | Epic 6 scope. This plan creates the status gates and WebSocket notification foundation but does not implement the chat UI or chat message persistence. |
| **Ratings (US-701)** | Epic 7 scope. This plan creates the `swap_confirmed` status transition that triggers the rating prompt, but the rating model and UI are in Epic 7. |
| **Block user integration (US-801)** | Epic 8 scope. Phase 2 includes a placeholder comment for block filtering in exchange creation. The `Block` model doesn't exist yet. |
| **Email notifications (US-901)** | A notification Celery task is stubbed (logs to console in MVP). Full email templates and Resend/SendGrid integration are Epic 9 scope. |
| **Push notifications via WebSocket** | Phase 2 adds a basic `NotificationConsumer` for badge count updates. Full push notification infrastructure is deferred. |
| **Cancellation count tracking** | US-504 EC2 mentions tracking cancellation count. A `cancellation_count` field on User is not added in this plan — can be a simple COUNT query until there's a need for denormalization. |

---

## 5. Actual Commit Sequence ✅

The planned 30 granular commits were consolidated into 5 phase-based commits for efficiency:

| # | Hash | Message | Phase |
|---|------|---------|-------|
| 1 | `5980c49` | `feat(exchanges): add Exchange app with models & migration — Epic 5 Phase 1` | Phase 1 |
| 2 | `616f1a4` | `feat(exchanges): add Backend API — Epic 5 Phase 2` | Phase 2 |
| 3 | `52e0f98` | `feat(exchanges): add Frontend services, hooks & types — Epic 5 Phase 3` | Phase 3 |
| 4 | `a11221e` | `feat(exchanges): add Frontend UI pages & components — Epic 5 Phase 4` | Phase 4 + 5 |
| 5 | `3cd1c33` | `test(exchanges): add integration tests & MSW handlers — Epic 5 Phase 6` | Phase 6 |

Branch pushed: `feat/epic-5-exchange` → `origin/feat/epic-5-exchange`

---

## 6. Deviations from Plan

| Planned | Actual | Reason |
|---------|--------|--------|
| Models in `backend/bookswap/` | Models in `backend/apps/exchanges/` (separate app) | User requested separate app for maintainability |
| 30 granular commits | 5 phase-based commits | More efficient; each commit is a self-contained phase |
| `NotificationConsumer` WebSocket | HTTP polling at 60s intervals (`useIncomingRequestCount`) | Simpler; WebSocket deferred to Epic 6 (Chat) |
| `RequestSwapModal` + `BookOfferPicker` as separate components | Inline book picker in `RequestSwapButton` | Simpler UX; single component handles the flow |
| Separate `ReturnFlow` component | Inline in `ExchangeDetailPage` | Only 2 buttons needed; separate component was over-engineered |
| Separate `DeclineModal`, `CounterModal`, `ConditionsView`, `SwapConfirmation`, `ExchangeTimeline` components | Actions integrated directly into `ExchangeDetailPage` and `IncomingRequestsPage` | Reduced component count; contextual rendering in pages was cleaner |
| Dutch (`nl`) translations | Only English + French | Project only has `en` + `fr` locale directories |
| `EmptyShelfPrompt` component | Availability check in `RequestSwapButton` | Lightweight inline check was sufficient |
| `ExchangeTimeline` as separate component | Timeline built into `ExchangeDetailPage` | Visual 6-step timeline rendered inline |

---

*— End of Action Plan —*
