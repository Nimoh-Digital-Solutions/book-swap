# Action Plan — Epic 4: Discovery & Search

> Generated: 2026-03-22
> Next fully-pending epic in order — Epics 1, 2 & 3 are implemented and pushed.

---

## 1. Story Status Overview

| ID | Title | Priority | Status | Notes |
|----|-------|----------|--------|-------|
| US-401 | Browse Nearby Books | P0 | ❌ Pending | No spatial browse endpoint; `CataloguePage` is a placeholder with no data |
| US-402 | Distance Filter | P0 | ❌ Pending | `User.preferred_radius` field exists but no filter UI or radius-count endpoint |
| US-403 | Search by Title, Author, ISBN | P0 | ⚠️ Partial | `search_vector` + GIN index + signal exist; no FTS query endpoint for discovery |
| US-404 | Filter by Genre, Language, Condition | P0 | ⚠️ Partial | Backend has basic `genre`/`language` single-value params; no multi-select, no condition filter, no spatial |
| US-405 | Map View | P1 | ❌ Pending | No Leaflet, no map components, no pin clustering |

**Legend**: ✅ Implemented · ⚠️ Partial · ❌ Pending

---

## 2. Gaps in Previously Implemented Stories

### Gap: [US-101] — Live counter "X books near you" on Landing Page

- **AC not met**: AC4 — "A live counter or sample shows 'X books available near you'"
- **Evidence**: `HeroSection` in `HomePage.tsx` renders a static placeholder. No backend endpoint provides a spatial book count.
- **Fix needed**: After Phase 1 of this epic creates the nearby query, add a `GET /api/v1/books/nearby-count/` (AllowAny) and wire it into the landing page hero section.

### Gap: [US-305] — BookViewSet list has no full-text search

- **AC not met**: The `?search=` query param is accepted in `BookListFilters` on the frontend but has no corresponding FTS query in `BookViewSet.get_queryset()`.
- **Evidence**: `BookViewSet.get_queryset()` filters by `owner`, `status` only. No `SearchQuery` or `SearchRank` usage.
- **Fix needed**: Phase 2 of this plan will add full-text search + filter support to the existing `BookViewSet` (or a new `BrowseViewSet`).

### Gap: [US-404 partial] — Backend lacks multi-value genre/language/condition filters

- **AC not met**: Genre/language filters are single-value in `BookListFilters`; condition filter is absent entirely.
- **Evidence**: `book.service.ts` sends `params.set('genre', filters.genre)` (single value). Backend `BookViewSet` has no filtering logic for these params.
- **Fix needed**: Extend the backend queryset filtering and frontend filter types to support comma-separated multi-select.

_(No other gaps found in previously implemented stories that relate to Epic 4.)_

---

## 3. Implementation Plan — Epic 4: Discovery & Search

### Context

Epic 4 transforms BookSwap from an inventory tool into a discovery platform. It introduces spatial browsing (PostGIS distance queries), full-text search, multi-filter panels, and a map view. The target user is the **book seeker** — someone looking for books to swap in their neighbourhood. All four P0 stories (US-401 through US-404) build on the existing `Book` model, `search_vector` GIN index, and `User.location` PointField. US-405 (Map View, P1) adds Leaflet for visual discovery.

### Stories Covered

- **US-401**: Browse Nearby Books (P0)
- **US-402**: Distance Filter (P0)
- **US-403**: Search by Title, Author, or ISBN (P0)
- **US-404**: Filter by Genre, Language, Condition (P0)
- **US-405**: Map View (P1)

---

### Phase 1 — Backend: Spatial Browse Endpoint & Distance Calculation

**Goal**: Create a dedicated browse/nearby endpoint that returns available books within a radius, annotated with distance, sorted by distance, with pagination. Also add a GiST index on `User.location` and a radius-count endpoint.

**Files to create / modify**:
- `backend/bookswap/views.py` — add `BrowseViewSet` with `nearby` action (or add `@action` to `BookViewSet`)
- `backend/bookswap/serializers.py` — add `BrowseBookListSerializer` (extends `BookListSerializer` with `distance` field)
- `backend/bookswap/urls.py` — register the browse endpoint
- `backend/bookswap/models.py` — add GiST index on `User.location` in `Meta.indexes`
- `backend/bookswap/migrations/` — new migration for the GiST index

**What to build**:

#### 1a. GiST Index on `User.location`

Add a spatial index to `User.Meta.indexes`:
```python
from django.contrib.gis.db.models import Index as GistIndex
# or:
models.Index(fields=['location'], name='user_location_gist')
```

PostGIS `PointField` columns get a GiST index by default in Django, but an **explicit** index ensures it's present and named. Verify with `\di` in psql after migration.

#### 1b. `BrowseBookListSerializer`

Extends `BookListSerializer` with:
- `distance` — `SerializerMethodField` → float (km, rounded to 1 decimal place)
- `owner.location` — uses `snap_to_grid()` for privacy (already in `BookOwnerSerializer` parent)

The `distance` annotation is set on the queryset (in metres), serializer converts to km:
```python
def get_distance(self, obj) -> float | None:
    d = getattr(obj, 'distance', None)
    if d is not None:
        return round(d.m / 1000, 1)  # metres → km
    return None
```

#### 1c. Browse Endpoint — `GET /api/v1/books/browse/`

**Query logic** (Django ORM + PostGIS):
1. Get the authenticated user's location (`request.user.location`)
2. If location is `None`, return 400 with `{"detail": "Set your location first."}`
3. Accept `?radius=` query param (metres, default = `request.user.preferred_radius` or 5000)
4. Filter: `Book.objects.filter(status='available')` → exclude `owner=request.user` → exclude `owner__in=blocked_user_ids` (placeholder until Epic 8 Block model exists)
5. Spatial filter: `owner__location__distance_lte=(user_point, D(m=radius))`
6. Annotate: `distance=Distance('owner__location', user_point)`
7. Order by: `distance` (nearest first)
8. Paginate: `PageNumberPagination` with `page_size=20`

**Endpoint**:

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/v1/books/browse/` | IsAuthenticated | Browse nearby available books with distance |

**Response shape** (paginated):
```json
{
  "count": 42,
  "next": "/api/v1/books/browse/?page=2",
  "previous": null,
  "results": [
    {
      "id": "...",
      "title": "...",
      "author": "...",
      "cover_url": "...",
      "condition": "good",
      "language": "en",
      "status": "available",
      "primary_photo": "...",
      "owner": { "id": "...", "username": "...", "avatar": "...", "neighborhood": "...", "avg_rating": 4.5 },
      "distance": 2.3,
      "created_at": "..."
    }
  ]
}
```

#### 1d. Radius Count Endpoint — `GET /api/v1/books/browse/radius-counts/`

Returns the number of available books at each standard radius option for the current user's location. Single query using `CASE WHEN ST_DWithin(...)` to avoid 5 separate queries.

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/v1/books/browse/radius-counts/` | IsAuthenticated | Book count per radius bucket |

**Response**:
```json
{
  "counts": {
    "1000": 3,
    "3000": 12,
    "5000": 23,
    "10000": 45,
    "25000": 67
  }
}
```

#### 1e. Nearby Count for Landing Page — `GET /api/v1/books/nearby-count/`

An `AllowAny` endpoint that accepts `?lat=&lng=&radius=` (from IP geolocation or user cookie) and returns a single count. Addresses the US-101 gap.

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/v1/books/nearby-count/` | AllowAny | Public nearby book count |

**Acceptance criteria addressed**: US-401 AC1, AC2, AC4, AC5, AC6, AC7; US-402 AC5

---

### Phase 2 — Backend: Search, Filters & Advanced Query

**Goal**: Add full-text search (FTS) with distance-boosted ranking, multi-value genre/language/condition filters, and ISBN exact match to the browse endpoint.

**Files to modify**:
- `backend/bookswap/views.py` — extend `BrowseViewSet.get_queryset()` with search + filter params
- `backend/bookswap/serializers.py` — add `BrowseFilterSerializer` for query param validation

**What to build**:

#### 2a. Full-Text Search (`?search=`)

When `search` param is provided:
1. If it looks like an ISBN (10–13 digits after stripping hyphens) → exact `isbn` match
2. Otherwise → `SearchQuery(search_term, search_type='plain')` against `search_vector`
3. Annotate `text_rank = SearchRank(F('search_vector'), query)`
4. Composite ordering: `text_rank * 0.7 + (1 / (1 + distance_km)) * 0.3` — materialized as an annotation
5. Partial match support: use `search_type='plain'` which handles prefix matching with `:*` appended

```python
from django.contrib.postgres.search import SearchQuery, SearchRank
from django.db.models import F, Value, ExpressionWrapper, FloatField

search_query = SearchQuery(search_term, search_type='plain')
qs = qs.filter(search_vector=search_query)
qs = qs.annotate(text_rank=SearchRank(F('search_vector'), search_query))
```

For composite score with distance:
```python
qs = qs.annotate(
    distance_km=ExpressionWrapper(F('distance') / Value(1000.0), output_field=FloatField()),
    composite_score=ExpressionWrapper(
        F('text_rank') * Value(0.7) + Value(1.0) / (Value(1.0) + F('distance_km')) * Value(0.3),
        output_field=FloatField(),
    ),
).order_by('-composite_score')
```

When no search term: order by `distance` (Phase 1 default).

#### 2b. Multi-Value Filters

Accept comma-separated values for genre, language, condition:

| Param | Example | SQL equivalent |
|-------|---------|---------------|
| `genre` | `?genre=fiction,sci-fi` | `genres && ARRAY['fiction','sci-fi']` (array overlap) |
| `language` | `?language=en,nl` | `language IN ('en','nl')` |
| `condition` | `?condition=good,like_new` | `condition IN ('good','like_new')` |

Validation via `BrowseFilterSerializer`:
```python
class BrowseFilterSerializer(serializers.Serializer):
    radius = serializers.IntegerField(min_value=500, max_value=50000, required=False)
    search = serializers.CharField(max_length=200, required=False, allow_blank=True)
    genre = serializers.CharField(max_length=500, required=False)       # comma-separated
    language = serializers.CharField(max_length=100, required=False)    # comma-separated
    condition = serializers.CharField(max_length=200, required=False)   # comma-separated
    ordering = serializers.ChoiceField(choices=['distance', '-created_at', 'relevance'], required=False)
```

#### 2c. Updated Browse Endpoint Summary

| Method | Path | Auth | Query Params | Description |
|--------|------|------|-------------|-------------|
| GET | `/api/v1/books/browse/` | IsAuthenticated | `radius`, `search`, `genre`, `language`, `condition`, `ordering`, `page` | Browse with search + filters |

**Nimoh-stack conventions to follow**:
- UUID PKs, `created_at`/`updated_at` on every model (already in place)
- `get_queryset()` scoped — exclude own books, exclude blocked users
- `permission_classes` declared explicitly on every view
- Validation via serializer before touching the queryset
- ISBN sanitization: strip hyphens/spaces, validate length

**Acceptance criteria addressed**: US-403 AC1–AC4, AC6–AC7; US-404 AC2–AC5; US-402 AC1

---

### Phase 3 — Frontend: Browse/Discovery Page, Distance Filter & Infinite Scroll

**Goal**: Build the core discovery feature module with types, services, hooks, and the main browse page with distance filter and infinite scroll.

**Files to create**:
- `frontend/src/features/discovery/types/discovery.types.ts` — `BrowseFilters`, `BrowseBook` (extends `BookListItem` with `distance`), `RadiusCounts`, `BrowseParams`
- `frontend/src/features/discovery/services/discovery.service.ts` — `browse()`, `radiusCounts()`, `nearbyCount()` axios wrappers
- `frontend/src/features/discovery/hooks/discoveryKeys.ts` — TanStack Query key factory
- `frontend/src/features/discovery/hooks/useBrowseBooks.ts` — `useInfiniteQuery` hook for paginated browse
- `frontend/src/features/discovery/hooks/useRadiusCounts.ts` — query hook for radius counts
- `frontend/src/features/discovery/hooks/useNearbyCount.ts` — query hook for landing page count (AllowAny)
- `frontend/src/features/discovery/hooks/useBrowseFilters.ts` — Zustand store or URL search params state for active filters
- `frontend/src/features/discovery/schemas/browseFilters.schema.ts` — Zod validation schema for filter state
- `frontend/src/features/discovery/components/RadiusSelector/RadiusSelector.tsx` — segmented control: 1, 3, 5, 10, 25 km
- `frontend/src/features/discovery/components/RadiusSelector/index.ts`
- `frontend/src/features/discovery/components/BrowseBookCard/BrowseBookCard.tsx` — extends `BookCard` with distance display ("~2.3 km")
- `frontend/src/features/discovery/components/BrowseBookCard/index.ts`
- `frontend/src/features/discovery/components/SetLocationPrompt/SetLocationPrompt.tsx` — shown when user has no location
- `frontend/src/features/discovery/components/SetLocationPrompt/index.ts`
- `frontend/src/features/discovery/components/BrowseEmptyState/BrowseEmptyState.tsx` — "No books found within X km" + expand button
- `frontend/src/features/discovery/components/BrowseEmptyState/index.ts`

**Files to modify**:
- `frontend/src/configs/apiEndpoints.ts` — add `browse` group:
  ```typescript
  browse: {
    list: `${BOOKS}/browse/`,
    radiusCounts: `${BOOKS}/browse/radius-counts/`,
    nearbyCount: `${BOOKS}/nearby-count/`,
  },
  ```

**Key patterns**:

#### 3a. Types

```typescript
export interface BrowseBook {
  id: string;
  title: string;
  author: string;
  cover_url: string;
  condition: BookCondition;
  language: BookLanguage;
  status: 'available';
  primary_photo: string | null;
  owner: BookOwner;
  distance: number;  // km
  created_at: string;
}

export interface BrowseFilters {
  radius?: number;       // metres
  search?: string;
  genre?: string[];      // multi-select
  language?: string[];   // multi-select
  condition?: string[];  // multi-select
  ordering?: 'distance' | '-created_at' | 'relevance';
}

export interface RadiusCounts {
  counts: Record<string, number>;  // e.g. { "1000": 3, "5000": 23, ... }
}
```

#### 3b. TanStack Query Key Factory

```typescript
export const discoveryKeys = {
  all: ['discovery'] as const,
  browse: () => [...discoveryKeys.all, 'browse'] as const,
  browseList: (filters: BrowseFilters) => [...discoveryKeys.browse(), filters] as const,
  radiusCounts: () => [...discoveryKeys.all, 'radius-counts'] as const,
  nearbyCount: (lat?: number, lng?: number) => [...discoveryKeys.all, 'nearby-count', lat, lng] as const,
};
```

#### 3c. `useBrowseBooks` — Infinite Query

Use `useInfiniteQuery` from TanStack Query with `getNextPageParam` extracting the `next` URL's page parameter. Returns `{ data, fetchNextPage, hasNextPage, isFetchingNextPage }` for infinite scroll.

#### 3d. RadiusSelector

- Segmented control with 5 options: 1, 3, 5, 10, 25 km
- Shows count per option from `useRadiusCounts` (e.g. "5 km (23)")
- Default highlighted: matches `user.preferred_radius / 1000`
- On change: updates filter state and calls `PATCH /api/v1/users/me/` to persist `preferred_radius`

#### 3e. Infinite Scroll

Use `IntersectionObserver` on a sentinel element at the bottom of the list. When visible and `hasNextPage`, call `fetchNextPage()`.

**Nimoh-stack conventions to follow**:
- `credentials: 'include'` on the API client (already configured in `http.ts`)
- Key factory pattern matching existing `bookKeys` convention
- No access token in localStorage — Zustand memory store for auth (already in place)

**Acceptance criteria addressed**: US-401 AC1–AC7; US-402 AC1–AC5

---

### Phase 4 — Frontend: Search Bar, Filter Panel & URL State Management

**Goal**: Add the search bar, genre/language/condition filter panel, filter chips, and sync all filter state to URL query params for shareable links.

**Files to create**:
- `frontend/src/features/discovery/components/SearchBar/SearchBar.tsx` — debounced (300ms) search input with loading indicator
- `frontend/src/features/discovery/components/SearchBar/index.ts`
- `frontend/src/features/discovery/components/FilterPanel/FilterPanel.tsx` — sidebar (desktop) / bottom sheet (mobile) with genre, language, condition multi-select groups
- `frontend/src/features/discovery/components/FilterPanel/index.ts`
- `frontend/src/features/discovery/components/FilterChips/FilterChips.tsx` — active filter chips with remove buttons + "Clear all"
- `frontend/src/features/discovery/components/FilterChips/index.ts`
- `frontend/src/features/discovery/components/FilterGroup/FilterGroup.tsx` — reusable multi-select checkbox group component
- `frontend/src/features/discovery/components/FilterGroup/index.ts`
- `frontend/src/features/discovery/components/MobileFilterSheet/MobileFilterSheet.tsx` — bottom sheet wrapper for mobile filter panel
- `frontend/src/features/discovery/components/MobileFilterSheet/index.ts`
- `frontend/src/features/discovery/hooks/useSearchDebounce.ts` — custom hook wrapping `useDeferredValue` or manual debounce (300ms)
- `frontend/src/features/discovery/hooks/useBrowseUrlState.ts` — sync `BrowseFilters` to/from URL search params via `useSearchParams()`
- `frontend/src/features/discovery/pages/BrowsePage.tsx` — replaces `CataloguePage` placeholder; orchestrates SearchBar + RadiusSelector + FilterPanel + BrowseBookCard grid + infinite scroll

**Files to modify**:
- `frontend/src/pages/CataloguePage/CataloguePage.tsx` — replace placeholder with the real `BrowsePage` (or redirect `/catalogue` to the new feature page)
- `frontend/src/routes/config/paths.ts` — keep `CATALOGUE: '/catalogue'` as-is (or alias `/browse`)
- `frontend/src/routes/config/routesConfig.tsx` — point `CATALOGUE` route to the new `BrowsePage`

**Key patterns**:

#### 4a. SearchBar

- Controlled input with 300ms debounce before updating filter state
- Minimum 3 characters to trigger search (show hint below input for 1–2 chars)
- Loading spinner when `isFetching` from the browse query
- Clear button (`×`) to reset search
- On enter or debounce expiry → update URL `?search=` param

#### 4b. URL State Management (`useBrowseUrlState`)

Reads/writes all filter state to URL search params:
```
/catalogue?search=alchemist&radius=5000&genre=fiction,mystery&language=en&condition=good,like_new
```

Uses `useSearchParams()` from React Router DOM. On mount, parses params into `BrowseFilters`. On filter change, updates params (replacing not pushing to avoid history pollution).

#### 4c. FilterPanel Layout

**Desktop** (≥ 1024px): Fixed sidebar, 280px wide, to the left of the book grid.
**Mobile** (< 1024px): Bottom sheet triggered by a "Filters" button in the toolbar.

Three filter groups, each using `FilterGroup`:
1. **Genre** — multi-select checkboxes from the shared genre list (same as `BookGenrePicker`)
2. **Language** — multi-select: English, Dutch, German, French, Spanish, Other
3. **Condition** — multi-select: New, Like New, Good, Acceptable

"Apply Filters" button on mobile sheet. Immediate update on desktop.

#### 4d. FilterChips

Rendered above the results grid. Each chip shows the filter value with an `×` to remove. "Clear all filters" link when any filter is active. Shows dynamic result count: `"23 books found"`.

#### 4e. BrowsePage Layout

```
┌────────────────────────────────────────────────────┐
│  SearchBar                    [RadiusSelector]     │
│  [FilterChips: fiction × | english × | Clear all]  │
├──────────┬─────────────────────────────────────────┤
│ FilterP. │  BrowseBookCard grid (3-col desktop)    │
│ (desktop)│  ...                                    │
│          │  ...                                    │
│          │  [Load More / Infinite Scroll sentinel] │
│          │  [List/Map toggle → Phase 5]            │
└──────────┴─────────────────────────────────────────┘
```

**UX notes** (from user stories):
- US-403: Search query preserved in URL for shareable links and browser back button
- US-403: "No results" state with query echoed: "No books matching 'xyz' found nearby."
- US-404: AND logic between groups, OR within groups
- US-404: Filter chips removable individually
- US-404: Filters persist during session (via URL params) but reset on logout

**i18n**: Add discovery-related strings to `en.json`, `nl.json`, `fr.json`. Namespace: `discovery`.
- `discovery.search.placeholder` — "Search by title, author, or ISBN..."
- `discovery.search.minChars` — "Type at least 3 characters"
- `discovery.filters.genre` — "Genre"
- `discovery.filters.language` — "Language"
- `discovery.filters.condition` — "Condition"
- `discovery.filters.clearAll` — "Clear all filters"
- `discovery.results.count` — "{{count}} books found"
- `discovery.results.empty` — "No books found within {{radius}} km"
- `discovery.results.emptySearch` — "No books matching '{{query}}' found nearby"
- `discovery.results.expandRadius` — "Try expanding your search radius"
- `discovery.radius.label` — "Distance"
- `discovery.location.required` — "Set your location to discover nearby books"

**Acceptance criteria addressed**: US-403 AC1–AC8; US-404 AC1–AC6

---

### Phase 5 — Frontend: Map View (Leaflet Integration)

**Goal**: Add a list/map view toggle to the browse page with Leaflet + OpenStreetMap tiles, book pins, clustering, and popups.

**Files to create**:
- `frontend/src/features/discovery/components/MapView/MapView.tsx` — Leaflet map container with OpenStreetMap tiles
- `frontend/src/features/discovery/components/MapView/index.ts`
- `frontend/src/features/discovery/components/MapView/BookPin.tsx` — custom pin/marker component for individual books
- `frontend/src/features/discovery/components/MapView/BookCluster.tsx` — cluster component using `react-leaflet-cluster` (or `leaflet.markercluster`)
- `frontend/src/features/discovery/components/MapView/BookPopup.tsx` — popup content: cover, title, author, condition, distance, link to detail
- `frontend/src/features/discovery/components/ViewToggle/ViewToggle.tsx` — list/map toggle button pair
- `frontend/src/features/discovery/components/ViewToggle/index.ts`
- `frontend/src/features/discovery/hooks/useMapBooks.ts` — hook that fetches ALL books within radius (unpaginated or with high limit) for map pins

**Dependencies to install** (npm):
- `leaflet` + `@types/leaflet`
- `react-leaflet`
- `react-leaflet-cluster` (or `@changey/react-leaflet-markercluster`)

**What to build**:

#### 5a. ViewToggle

Two-button toggle: "List" (default, active) / "Map". Stored in local state (not URL — map view isn't shareable).

#### 5b. MapView Component

- Uses `react-leaflet` `MapContainer`, `TileLayer`, `Marker`, `Popup`
- Tile URL: `https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png` with OSM attribution
- Centered on user's location (from auth context / profile)
- Default zoom: calculated from active radius (1km → ~15, 5km → ~13, 25km → ~11)
- User's location: distinct blue circle marker

#### 5c. Book Pins

- Each book rendered as a `Marker` at its owner's snapped location (`owner.location`)
- Custom pin icon (book emoji or BookSwap-branded SVG)
- Multiple books from same owner → grouped at same point; popup lists all books

#### 5d. Clustering

- `react-leaflet-cluster` wraps markers for automatic clustering at low zoom levels
- Cluster shows book count badge

#### 5e. Book Popup

On pin click:
```
┌─────────────────────────────┐
│ [cover] Title               │
│          by Author          │
│          Condition: Good    │
│          ~2.3 km            │
│          [View Book →]      │
└─────────────────────────────┘
```
"View Book" links to `/books/:id` (BookDetailPage).

#### 5f. Data Fetching for Map

- Map mode fetches books via the same browse endpoint but with a higher page size (e.g. `?page_size=200`) or a dedicated `?format=map` param that returns lightweight data (id, title, author, condition, distance, owner.location coordinates)
- Respects the active radius and genre/language/condition filters
- Does NOT re-fetch on map pan/zoom (all data within radius is loaded at once)

**UX notes**:
- US-405 AC7: User's own location as blue dot
- US-405 AC8: Respects distance filter — re-renders when radius changes
- Leaflet CSS must be imported (either globally or within MapView)
- Lazy-load the map: `React.lazy(() => import('./MapView'))` to avoid loading Leaflet JS on list view

**Acceptance criteria addressed**: US-405 AC1–AC8

---

### Phase 6 — Integration Tests & Acceptance Criteria Check

**Goal**: Connect everything end-to-end and verify every AC is met.

**Tasks**:
- [ ] Register the browse URL in `backend/bookswap/urls.py`
- [ ] Verify `config/urls.py` includes `bookswap.urls` (already does: `path('api/v1/', include('bookswap.urls'))`)
- [ ] Add MSW handlers in `frontend/src/test/mocks/handlers/` for:
  - `GET /api/v1/books/browse/` — paginated browse response with distance
  - `GET /api/v1/books/browse/radius-counts/` — counts per radius
  - `GET /api/v1/books/nearby-count/` — public count
- [ ] Write backend tests (`backend/bookswap/tests/test_browse_api.py`):
  - **Spatial tests**: books within radius returned, books outside excluded, distance annotation correct
  - **Own-book exclusion**: user's own books not in results
  - **Search tests**: FTS returns matching books, ISBN exact match, partial title match, composite ranking
  - **Filter tests**: genre overlap, language IN, condition IN, combined filters
  - **Radius counts**: correct counts per bucket
  - **Edge cases**: user without location → 400, zero results → empty page, radius at boundary
- [ ] Write frontend tests (Vitest + Testing Library):
  - `BrowsePage` renders book grid from MSW data
  - `SearchBar` debounces input, shows loading state, updates URL
  - `RadiusSelector` highlights active radius, calls mutation on change
  - `FilterPanel` multi-select toggles, chips rendered, clear all works
  - `BrowseBookCard` shows distance badge
  - `BrowseEmptyState` shown when no results
  - `SetLocationPrompt` shown when user has no location
  - `MapView` renders (Leaflet mocked or snapshot)
  - `ViewToggle` switches between list and map
  - URL state roundtrip: filters → URL → page reload → same filters
- [ ] Verify all i18n strings are present in `en.json`, `nl.json`, `fr.json`
- [ ] Wire the landing page hero section to `useNearbyCount` (US-101 gap fix)
- [ ] Verify `discoveryKeys` cache invalidation: changing radius or filters invalidates browse queries

**Acceptance Criteria Checklist**:

| Story | AC | Acceptance Criterion | Covered in Phase |
|-------|----|---------------------|-----------------|
| US-401 | AC1 | Default home feed shows available books within user's radius | Phase 1 (endpoint) + Phase 3 (BrowsePage) |
| US-401 | AC2 | Default radius: 5km | Phase 1 (User.preferred_radius default) + Phase 3 (RadiusSelector) |
| US-401 | AC3 | Book cards: cover, title, author, condition badge, distance, owner | Phase 3 (BrowseBookCard) |
| US-401 | AC4 | Sorted by distance (nearest first) | Phase 1 (queryset ORDER BY distance) |
| US-401 | AC5 | Paginated: 20/page, infinite scroll | Phase 1 (PageNumberPagination) + Phase 3 (useInfiniteQuery) |
| US-401 | AC6 | Empty state with expand-radius suggestion | Phase 3 (BrowseEmptyState) |
| US-401 | AC7 | Own books excluded | Phase 1 (queryset exclude owner=request.user) |
| US-401 | AC8 | Blocked users' books excluded | Phase 1 (queryset exclude, placeholder until Epic 8) |
| US-402 | AC1 | Radius options: 1, 3, 5, 10, 25 km | Phase 3 (RadiusSelector) |
| US-402 | AC2 | Segmented control / dropdown | Phase 3 (RadiusSelector) |
| US-402 | AC3 | Immediate re-fetch on change | Phase 3 (hook invalidation on filter change) |
| US-402 | AC4 | Persist radius in user preferences | Phase 3 (PATCH /users/me/ on radius change) |
| US-402 | AC5 | Book count per radius option | Phase 1 (radius-counts endpoint) + Phase 3 (RadiusSelector display) |
| US-403 | AC1 | Search bar at top of browse page | Phase 4 (SearchBar) |
| US-403 | AC2 | Free-text across title, author, ISBN | Phase 2 (FTS endpoint) |
| US-403 | AC3 | Combined text relevance + distance ranking | Phase 2 (composite score annotation) |
| US-403 | AC4 | Partial matches (e.g. "Alch" → "The Alchemist") | Phase 2 (SearchQuery plain type) |
| US-403 | AC5 | 300ms debounce, loading state | Phase 4 (SearchBar debounce) |
| US-403 | AC6 | Same card format as browse feed | Phase 3 (BrowseBookCard reused) |
| US-403 | AC7 | "No results" state with query echo | Phase 4 (BrowseEmptyState with search variant) |
| US-403 | AC8 | Search query in URL (shareable) | Phase 4 (useBrowseUrlState) |
| US-404 | AC1 | Filter panel: sidebar desktop, bottom sheet mobile | Phase 4 (FilterPanel + MobileFilterSheet) |
| US-404 | AC2 | AND between groups, OR within | Phase 2 (backend query logic) |
| US-404 | AC3 | Active filters as removable chips | Phase 4 (FilterChips) |
| US-404 | AC4 | "Clear all filters" button | Phase 4 (FilterChips) |
| US-404 | AC5 | Dynamic result count | Phase 4 (BrowsePage header count from query) |
| US-404 | AC6 | Filters persist during session | Phase 4 (URL params persist across navigation) |
| US-405 | AC1 | Toggle list/map view | Phase 5 (ViewToggle) |
| US-405 | AC2 | Leaflet + OSM tiles | Phase 5 (MapView) |
| US-405 | AC3 | Pins at owner approximate location | Phase 5 (BookPin with snapped coords) |
| US-405 | AC4 | Pin popup: cover, title, author, condition, distance | Phase 5 (BookPopup) |
| US-405 | AC5 | Popup click → book detail | Phase 5 (BookPopup link) |
| US-405 | AC6 | Pin clustering | Phase 5 (BookCluster) |
| US-405 | AC7 | User location as blue dot | Phase 5 (MapView user marker) |
| US-405 | AC8 | Respects distance filter | Phase 5 (filter pass-through) |

**Edge Cases to handle**:

| Story | EC | Edge Case | Where to handle |
|-------|----|-----------|----------------|
| US-401 | EC1 | User hasn't set location | Phase 3 — SetLocationPrompt component |
| US-401 | EC2 | All nearby books belong to one user | Phase 1 — no special handling needed (still shown) |
| US-401 | EC3 | Two users at same snapped grid → "< 1 km" | Phase 3 — BrowseBookCard: `distance < 1 ? '< 1 km' : '~X.X km'` |
| US-402 | EC1 | 0 results at selected radius | Phase 3 — BrowseEmptyState with next-best radius suggestion from counts |
| US-403 | EC1 | ISBN search (13 digits) → exact match | Phase 2 — ISBN detection regex in browse queryset |
| US-403 | EC2 | Short query (1–2 chars) → don't trigger | Phase 4 — SearchBar minimum-length guard |
| US-403 | EC3 | Special characters in search | Phase 2 — BrowseFilterSerializer sanitizes input |
| US-404 | EC1 | All filters → 0 books | Phase 4 — BrowseEmptyState with "try relaxing filters" |
| US-405 | EC1 | Multiple books from same owner | Phase 5 — BookPopup lists all books at that location |
| US-405 | EC2 | Zoom out shows wide area | Phase 5 — MarkerCluster handles pin density |

---

## 4. What's Not in This Plan

| Item | Reason |
|------|--------|
| **Blocked users exclusion (US-401 AC8)** | The `Block` model doesn't exist yet (Epic 8: Trust & Safety). Phase 1 includes a placeholder comment in the queryset (`# TODO: exclude blocked_user_ids when Block model exists`). |
| **Caching browse queries (60s per user/radius)** | Performance optimization. Not needed for MVP launch. Can be added via Django cache framework (`cache_page` or manual Redis caching) post-launch. |
| **SSR / SEO for browse page** | User stories reference SSR via Next.js, but the app uses Vite + CSR. SEO for authenticated pages is low-priority. Consider `<meta>` tags for the public nearby-count endpoint. |
| **IP geolocation for unauthenticated browse** | US-101 mentions IP geolocation for landing page count. The `nearby-count` endpoint accepts explicit lat/lng. Actual IP geolocation service integration deferred. |

---

## 5. Suggested Commit Sequence

1. `feat(bookswap): add GiST index on User.location + migration`
2. `feat(bookswap): add BrowseViewSet with spatial browse endpoint and radius-counts`
3. `feat(bookswap): add FTS search, multi-value filters, and composite ranking to browse`
4. `feat(bookswap): add AllowAny nearby-count endpoint for landing page`
5. `feat(discovery): add discovery types, services, hooks, and TanStack Query key factory`
6. `feat(discovery): build BrowsePage with BrowseBookCard grid, RadiusSelector, and infinite scroll`
7. `feat(discovery): add SearchBar with 300ms debounce and URL state management`
8. `feat(discovery): build FilterPanel with genre/language/condition multi-select and filter chips`
9. `feat(discovery): add MobileFilterSheet for responsive filter UX`
10. `feat(discovery): integrate Leaflet MapView with BookPin, clustering, and BookPopup`
11. `feat(discovery): add ViewToggle for list/map mode switching`
12. `fix(home): wire landing page hero to nearby-count endpoint (US-101 gap)`
13. `test(bookswap): add spatial browse, FTS search, and filter acceptance-criteria tests`
14. `test(discovery): add frontend component and integration tests for discovery features`
15. `chore(i18n): add en/nl/fr translations for discovery namespace`

---

*— End of Action Plan —*
