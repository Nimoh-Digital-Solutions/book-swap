# Action Plan — Epic 8: Trust & Safety

> Generated: 2026-03-23
> Next unimplemented epic in order (Epics 1–7 complete).

---

## 1. Story Status Overview

| ID | Title | Priority | Status | Notes |
|----|-------|----------|--------|-------|
| US-801 | Block User | P0 | ❌ Pending | No Block model, no API, no frontend. Tech arch doc has reference schema. |
| US-802 | Report User or Listing | P0 | ❌ Pending | No Report model, no API, no admin review UI. Tech arch doc has reference schema. |
| US-803 | Email Verification Gate | P0 | ⚠️ Partial | Backend `email_verified` field exists on User (via nimoh-base). Backend endpoints `/api/v1/auth/email/verify/` and `/api/v1/auth/email/resend/` exist (nimoh-base). Frontend `apiEndpoints.ts` references them. **Missing**: no frontend pages to handle verification links, no gating logic on protected actions (list books, send requests, send messages), no "verify your email" inline prompts. |
| US-804 | GDPR Privacy Compliance | P0 | ⚠️ Partial | Registration form has privacy policy + ToS checkboxes. Account deletion (30-day grace) is implemented (backend + frontend). `anonymize_deleted_accounts` Celery task exists. **Missing**: no privacy policy page (EN/NL), no terms of service page, no cookie consent banner, no data export endpoint, no DPIA document. |

**Legend**: ✅ Implemented · ⚠️ Partial · ❌ Pending

---

## 2. Gaps in Previously Implemented Stories

### Gap: [US-102 / US-803] — No email verification frontend flow

- **AC not met**: US-102 AC6 — "Verification link activates + redirects" / US-803 AC1-5 — full email verification gate
- **Evidence**: Backend nimoh-base provides `/api/v1/auth/email/verify/` and `/api/v1/auth/email/resend/` endpoints (referenced in `frontend/src/configs/apiEndpoints.ts`). No `EmailVerificationPage` or `EmailVerificationPendingPage` exists in `frontend/src/features/auth/pages/`. No gating middleware or guard in frontend that checks `email_verified` before allowing book listing, exchange requests, or messaging.
- **Fix needed**: Phase 3–4 of this plan adds an `EmailVerificationGate` component, verification pages, and backend permission class `IsEmailVerified`.

### Gap: [US-504 / US-601] — No block filtering on exchange requests or messages

- **AC not met**: US-801 AC3-5 — "blocked user no longer sees blocker's profile or books", "existing exchange auto-cancelled", "existing chat hidden"
- **Evidence**: `apps/exchanges/views.py` and `apps/messaging/views.py` have no block-check logic. `bookswap/views.py` browse/search queries have no block filter. No `Block` model exists anywhere in the backend.
- **Fix needed**: Phase 1–2 of this plan creates the Block model and integrates block filtering into all user-facing queries (books, exchanges, messaging, profiles).

### Gap: [US-804] — Privacy policy link in registration form routes nowhere

- **AC not met**: US-804 AC1 — "Privacy policy page: available in English and Dutch, accessible from footer on every page"
- **Evidence**: `RegisterForm.tsx` line 383 has a `<button>` labelled "Privacy Policy" with no `onClick` handler or link target. No `/privacy-policy` route exists in `paths.ts`. No `PrivacyPolicyPage` component.
- **Fix needed**: Phase 4 of this plan creates the Privacy Policy and Terms of Service pages with bilingual content and links them from the footer and registration form.

### Gap: [US-804] — No data export endpoint

- **AC not met**: US-804 AC6 — "Data export: user can download their data as JSON from Settings"
- **Evidence**: Tech arch doc specifies `GET /api/users/me/data-export/` but no such endpoint exists in `backend/bookswap/urls.py` or `backend/bookswap/views.py`. Settings page (`frontend/src/pages/SettingsPage/SettingsPage.tsx`) only has the "Delete Account" danger zone section.
- **Fix needed**: Phase 2 adds the backend data export endpoint; Phase 4 adds a "Download My Data" button in Settings.

---

## 3. Implementation Plan — Epic 8: Trust & Safety

### Context

Epic 8 introduces the trust and safety layer that must be in place before any public launch. It covers four P0 stories: user blocking, user/listing reporting, email verification gating, and GDPR compliance. These features protect users from harassment (blocking), give them a way to flag problems (reporting), ensure minimum identity trust (email verification before write actions), and satisfy EU GDPR / Dutch UAVG legal requirements (privacy policy, cookie consent, data export). The block system must integrate deeply into existing queries across books, exchanges, messaging, and profiles. The report system needs a simple admin review workflow. This epic touches the core `bookswap` app (Block/Report models), the existing `exchanges` and `messaging` apps (block filtering), and the frontend (new feature module `trust-safety`, plus modifications to existing features).

### Stories Covered

- **US-801**: Block User (P0)
- **US-802**: Report User or Listing (P0)
- **US-803**: Email Verification Gate (P0)
- **US-804**: GDPR Privacy Compliance (P0)

---

### Phase 1 — Data Layer

**Goal**: Create the `Block` and `Report` models in the main `bookswap` app and run migrations. Also add the `IsEmailVerified` permission class.

**Files to create / modify**:
- `backend/bookswap/models.py` — add `Block`, `ReportCategory`, `ReportStatus`, `Report` models
- `backend/bookswap/permissions.py` — add `IsEmailVerified`, `IsNotBlocked` permissions
- `backend/bookswap/admin.py` — register `Block` and `Report` for Django admin

**What to build**:

- **`Block`** (US-801):
  - `id` — UUIDField (PK)
  - `blocker` — FK to User (related_name=`blocking`)
  - `blocked` — FK to User (related_name=`blocked_by`)
  - `created_at` — DateTimeField (auto_now_add)
  - Meta: `unique_together = ('blocker', 'blocked')`, index on `blocker`, index on `blocked`
  - Validation: cannot block yourself

- **`ReportCategory`** (TextChoices — US-802):
  - `INAPPROPRIATE`, `FAKE_LISTING`, `NO_SHOW`, `MISREPRESENTED`, `HARASSMENT`, `SPAM`, `OTHER`

- **`ReportStatus`** (TextChoices):
  - `OPEN`, `REVIEWED`, `RESOLVED`, `DISMISSED`

- **`Report`** (US-802):
  - `id` — UUIDField (PK)
  - `reporter` — FK to User (related_name=`reports_filed`)
  - `reported_user` — FK to User (related_name=`reports_received`)
  - `reported_book` — FK to Book (null=True, blank=True, on_delete=SET_NULL)
  - `reported_exchange` — FK to ExchangeRequest (null=True, blank=True, on_delete=SET_NULL)
  - `category` — CharField (choices=ReportCategory)
  - `description` — CharField (max_length=500, blank=True)
  - `status` — CharField (choices=ReportStatus, default='open')
  - `admin_notes` — TextField (blank=True) — founder's review notes
  - `resolved_at` — DateTimeField (null=True, blank=True)
  - `created_at` — DateTimeField (auto_now_add)
  - Validation: description required when category='other'

- **`IsEmailVerified`** permission class (US-803):
  - Returns `True` if `request.user.email_verified is True` or `request.user.is_social_account is True`
  - Custom message: "Please verify your email to perform this action."

**Acceptance criteria addressed**: US-801 AC1-7 (data layer), US-802 AC1-6 (data layer), US-803 AC2-3 (permission class)

---

### Phase 2 — Backend API

**Goal**: Expose Block, Report, Email Verification Gate, and Data Export through authenticated REST endpoints. Integrate block filtering into all existing user-facing queries.

**Files to create / modify**:
- `backend/bookswap/serializers.py` — add `BlockSerializer`, `BlockListSerializer`, `ReportCreateSerializer`, `ReportListSerializer`, `ReportAdminSerializer`, `DataExportSerializer`
- `backend/bookswap/views.py` — add `BlockViewSet`, `ReportCreateView`, `ReportAdminListView`, `DataExportView`
- `backend/bookswap/urls.py` — register new routes
- `backend/bookswap/tasks.py` — add `send_report_notification_email` Celery task
- `backend/bookswap/services.py` — add `get_blocked_user_ids(user)` helper, `build_data_export(user)` helper
- `backend/bookswap/views.py` — modify `BrowseViewSet.get_queryset()` to exclude blocked users' books
- `backend/bookswap/views.py` — modify `UserDetailView` to return 404 for blocked users
- `backend/apps/exchanges/views.py` — add block check on `create` (cannot send request to/from blocked user), add `IsEmailVerified` permission
- `backend/apps/exchanges/views.py` — modify `get_queryset()` to exclude blocked users' exchanges
- `backend/apps/messaging/views.py` — add block check (cannot send message to blocked user), add `IsEmailVerified` permission
- `backend/apps/messaging/consumers.py` — add block check in WebSocket connect/send

**Endpoints to build**:

| Method | Path | Auth | Description | Story |
|--------|------|------|-------------|-------|
| POST | `/api/v1/users/block/` | IsAuthenticated | Block a user (body: `{blocked_user_id}`) | US-801 |
| DELETE | `/api/v1/users/block/{user_id}/` | IsAuthenticated | Unblock a user | US-801 |
| GET | `/api/v1/users/block/` | IsAuthenticated | List blocked users | US-801 |
| POST | `/api/v1/reports/` | IsAuthenticated + IsEmailVerified | Create a report | US-802 |
| GET | `/api/v1/reports/admin/` | IsAdminUser | List all open reports (admin) | US-802 |
| PATCH | `/api/v1/reports/admin/{id}/` | IsAdminUser | Update report status (admin) | US-802 |
| GET | `/api/v1/users/me/data-export/` | IsAuthenticated | Download all personal data as JSON | US-804 |

**Block integration points** (US-801 AC3-5):

1. **Book queries** (`BrowseViewSet`, `BookViewSet` list): filter out books where `owner_id` is in the user's blocked/blocked_by set
2. **User detail** (`UserDetailView`): return 404 if target user is blocked/blocked_by
3. **Exchange creation** (`ExchangeRequestViewSet.create`): reject if either party is in a block relationship; validate before creating
4. **Active exchanges** (on block action): auto-cancel any pending/accepted/active exchanges between the two users, fire cancellation notifications
5. **Messaging** (`MessageListView`, `ChatConsumer`): hide conversations and prevent new messages between blocked users
6. **Partner request** (on block action): auto-decline any pending partner requests between the two users

**Email verification integration points** (US-803 AC2):

1. **Book creation** (`BookViewSet.create`): require `IsEmailVerified`
2. **Exchange request creation** (`ExchangeRequestViewSet.create`): require `IsEmailVerified`
3. **Message sending** (`MessageListView.create`, `ChatConsumer.receive`): require `IsEmailVerified`

**Data export** (US-804 AC6):

- `build_data_export(user)` collects: user profile fields, all books, all exchange history, all messages sent, all ratings given/received, all blocks, all reports filed
- Returns as structured JSON with clear section headers
- Rate-limited to 1 request per 24 hours per user

**Celery task** (US-802):

- `send_report_notification_email`: sends email to founder/admin email on every new report (via SendGrid)
- Triggered by `Report.post_save` signal

**Nimoh-stack conventions to follow**:
- UUID PKs, created_at/updated_at on every model
- `get_queryset()` scoped to `request.user` where appropriate
- `permission_classes` declared explicitly on every view
- Split list/detail serializers
- `get_blocked_user_ids(user)` returns combined set of IDs the user has blocked + IDs that have blocked the user (bidirectional)

**Acceptance criteria addressed**: US-801 AC1-7, US-802 AC1-6, US-803 AC2, US-804 AC6

---

### Phase 3 — Frontend Services & Hooks

**Goal**: Wire the Block, Report, Email Verification, and Data Export APIs into the frontend data layer. Create the new `trust-safety` feature module.

**Files to create**:
- `frontend/src/features/trust-safety/types/trustSafety.types.ts` — TypeScript interfaces for Block, Report, ReportCategory
- `frontend/src/features/trust-safety/services/blockService.ts` — axios wrappers for block/unblock/list
- `frontend/src/features/trust-safety/services/reportService.ts` — axios wrapper for report creation
- `frontend/src/features/trust-safety/services/dataExportService.ts` — axios wrapper for data export
- `frontend/src/features/trust-safety/hooks/blockKeys.ts` — TanStack Query key factory for blocks
- `frontend/src/features/trust-safety/hooks/useBlocks.ts` — query hook for blocked users list
- `frontend/src/features/trust-safety/hooks/useBlockUser.ts` — mutation hook (block)
- `frontend/src/features/trust-safety/hooks/useUnblockUser.ts` — mutation hook (unblock)
- `frontend/src/features/trust-safety/hooks/useReportUser.ts` — mutation hook (report creation)
- `frontend/src/features/trust-safety/hooks/useDataExport.ts` — mutation hook (data export download)
- `frontend/src/features/trust-safety/hooks/useIsBlocked.ts` — derived hook checking if a specific user is in the blocked list
- `frontend/src/features/trust-safety/schemas/reportSchema.ts` — Zod validation schema for report form
- `frontend/src/features/trust-safety/index.ts` — barrel export
- `frontend/src/features/auth/hooks/useEmailVerificationGate.ts` — hook that checks `user.email_verified` and returns `{ isVerified, showPrompt }`
- `frontend/src/features/auth/services/emailVerificationService.ts` — resend verification email service (uses existing `apiEndpoints.ts` emailResend)

**API endpoints to register** in `frontend/src/configs/apiEndpoints.ts`:
```typescript
blocks: {
  list: `${USERS}/block/`,
  create: `${USERS}/block/`,
  delete: (userId: string) => `${USERS}/block/${userId}/`,
},
reports: {
  create: `${V1}/reports/`,
},
users: {
  // add to existing users group:
  meDataExport: `${USERS}/me/data-export/`,
},
```

**Nimoh-stack conventions to follow**:
- `credentials: 'include'` on the API client
- Key factory pattern: `blockKeys.all()`, `blockKeys.list()`
- Optimistic update on block/unblock mutations (invalidate browse, exchanges, messaging queries)
- No access token in localStorage — uses Zustand memory store via nimoh-base interceptors

**Acceptance criteria addressed**: US-801 AC1-7 (data layer), US-802 AC1-4 (service + validation), US-803 AC3-4 (resend hook), US-804 AC6 (export hook)

---

### Phase 4 — Frontend UI

**Goal**: Build the pages, components, and dialogs users interact with for blocking, reporting, email verification, privacy compliance.

**Files to create**:

**Block UI (US-801)**:
- `frontend/src/features/trust-safety/components/BlockUserButton/BlockUserButton.tsx` — "Block User" button with confirmation dialog
- `frontend/src/features/trust-safety/components/UnblockButton/UnblockButton.tsx` — "Unblock" button for blocked users list
- `frontend/src/features/trust-safety/components/BlockedUsersList/BlockedUsersList.tsx` — list of blocked users with unblock option

**Report UI (US-802)**:
- `frontend/src/features/trust-safety/components/ReportDialog/ReportDialog.tsx` — modal with category dropdown + description field
- `frontend/src/features/trust-safety/components/ReportButton/ReportButton.tsx` — "Report" trigger button (flag icon)

**Email Verification Gate (US-803)**:
- `frontend/src/features/auth/components/EmailVerificationGate/EmailVerificationGate.tsx` — wrapper component that shows inline "verify your email" prompt when unverified user attempts gated action
- `frontend/src/features/auth/pages/EmailVerificationPage.tsx` — handles verification link clicks (reads token from URL, calls verify endpoint, shows success/error)
- `frontend/src/features/auth/pages/EmailVerificationPendingPage.tsx` — "Check your email" screen with resend button (rate-limited to 3/hr)

**GDPR / Privacy (US-804)**:
- `frontend/src/pages/PrivacyPolicyPage/PrivacyPolicyPage.tsx` — bilingual privacy policy (EN/NL toggle), accessible from footer
- `frontend/src/pages/TermsOfServicePage/TermsOfServicePage.tsx` — bilingual terms of service
- `frontend/src/features/trust-safety/components/CookieConsentBanner/CookieConsentBanner.tsx` — lightweight banner: "We use essential cookies. [Accept] [Manage]", persists consent to localStorage with timestamp
- `frontend/src/features/trust-safety/components/DataExportButton/DataExportButton.tsx` — "Download My Data" button for Settings page

**Integration with existing pages**:
- `frontend/src/features/profile/pages/PublicProfilePage.tsx` — add `BlockUserButton` and `ReportButton` to user action menu
- `frontend/src/features/books/pages/BookDetailPage.tsx` — add `ReportButton` to book actions
- `frontend/src/features/exchanges/components/` — add `ReportButton` in chat/exchange context
- `frontend/src/pages/SettingsPage/SettingsPage.tsx` — add "Blocked Users" section, "Download My Data" button, link to privacy policy
- `frontend/src/components/common/Footer/` or layout — add Privacy Policy and ToS links

**i18n files**:
- `frontend/src/features/trust-safety/i18n/en.json` — English strings for block, report, cookie consent
- `frontend/src/features/trust-safety/i18n/fr.json` — French strings (or Dutch `nl.json` per project locale setup)
- `frontend/public/locales/en/trust-safety.json` — if using namespace-based i18n loading
- `frontend/public/locales/nl/trust-safety.json`

**Routes to register** in `frontend/src/routes/config/paths.ts`:
- `PRIVACY_POLICY: '/privacy-policy'` — public
- `TERMS_OF_SERVICE: '/terms-of-service'` — public
- `EMAIL_VERIFY: '/email/verify'` — public (handles verification link)
- `EMAIL_VERIFY_PENDING: '/email/verify/pending'` — public

**In `routesConfig.tsx`**: add the routes above. Privacy/ToS under `AppLayout` (public). Email verify pages under auth routes group (public, no auth required).

**UX notes** (from user stories):
- **Block** (US-801): Confirmation dialog: "Block [display name]? They won't be able to see your profile, books, or send you requests. They won't be notified." Block is silent. "Blocked Users" list in Settings with unblock option.
- **Report** (US-802): Category dropdown with 7 options. Description max 500 chars, required for "Other". Confirmation: "Thanks for reporting. We'll review this within 48 hours." Reported user is NOT notified.
- **Email gate** (US-803): Inline prompt: "Please verify your email to [list books / send requests]. Check your inbox or resend verification email." Resend rate-limited 3/hr. OAuth users auto-verified.
- **Cookie consent** (US-804): "We use essential cookies to run BookSwap. [Accept] [Manage Preferences]". Only essential cookies (auth session) in MVP. Consent logged with timestamp. Banner disappears after accept.

**Acceptance criteria addressed**: US-801 AC1-3,6-7, US-802 AC1-5, US-803 AC1-5, US-804 AC1-4

---

### Phase 5 — Integration & Acceptance Criteria Check

**Goal**: Connect everything end-to-end, verify every AC is met, and ensure existing tests still pass.

**Tasks**:
- [ ] Register the block/report URL routes in `backend/bookswap/urls.py`
- [ ] Register the data export URL in `backend/bookswap/urls.py`
- [ ] Register `Report` and `Block` in Django admin (`backend/bookswap/admin.py`) with list filters and search
- [ ] Add `send_report_notification_email` Celery task + `post_save` signal on `Report`
- [ ] Wire block-check into `ExchangeRequestViewSet.create()` — reject if blocked
- [ ] Wire block-check into `MessageListView` and `ChatConsumer` — reject if blocked
- [ ] Wire `IsEmailVerified` into `BookViewSet.create()`, `ExchangeRequestViewSet.create()`, `MessageListView.create()`
- [ ] Update `BrowseViewSet.get_queryset()` to exclude blocked users' books
- [ ] Update `UserDetailView` to return 404 for blocked users
- [ ] On block creation: auto-cancel pending/accepted exchanges between the pair (backend signal or service method)
- [ ] On block creation: auto-decline pending partner requests between the pair
- [ ] Add MSW handlers in `frontend/src/test/mocks/handlers.ts` for block, report, data-export endpoints
- [ ] Add `CookieConsentBanner` to `App.tsx` or root layout (renders above all content)
- [ ] Wire privacy policy / ToS links in Footer component and registration form
- [ ] Wire email verification pages into route config
- [ ] Verify all translations in both `en.json` and `nl.json`
- [ ] Write backend tests: Block CRUD, block filtering on books/exchanges/messages, Report creation + admin, data export, IsEmailVerified permission
- [ ] Write frontend tests: BlockUserButton, ReportDialog, EmailVerificationGate, CookieConsentBanner, PrivacyPolicyPage, DataExportButton, SettingsPage blocked users section

**Acceptance Criteria Checklist**:

| ID | Acceptance Criterion | Covered in Phase |
|----|---------------------|-----------------|
| **US-801** | | |
| AC1 | "Block User" option on profile page and in chat | Phase 4 (BlockUserButton on PublicProfilePage + exchange chat) |
| AC2 | Confirmation dialog with correct text | Phase 4 (BlockUserButton dialog) |
| AC3 | After blocking: neither sees the other's profile or books | Phase 2 (backend block filter) + Phase 3 (optimistic invalidation) |
| AC4 | Existing active exchange auto-cancelled | Phase 2 (block creation service) + Phase 5 (signal) |
| AC5 | Existing chat hidden from both users | Phase 2 (messaging block filter) |
| AC6 | Block is silent — blocked user not notified | Phase 2 (no notification triggered) |
| AC7 | "Blocked Users" list in Settings with unblock | Phase 4 (BlockedUsersList in SettingsPage) |
| **US-802** | | |
| AC1 | "Report" option on profiles, listings, chat | Phase 4 (ReportButton on PublicProfilePage, BookDetailPage, chat) |
| AC2 | Report form with category dropdown (7 items) | Phase 4 (ReportDialog) |
| AC3 | Description max 500 chars, required for "Other" | Phase 3 (Zod schema) + Phase 4 (ReportDialog) |
| AC4 | Confirmation: "Thanks for reporting…" | Phase 4 (ReportDialog success state) |
| AC5 | Reported user not notified | Phase 2 (no notification triggered) |
| AC6 | Admin dashboard lists open reports | Phase 2 (ReportAdminListView) + Django admin |
| **US-803** | | |
| AC1 | Unverified users CAN browse, view profiles, search | Phase 4 (no gate on browse/profile/search routes) |
| AC2 | Unverified users CANNOT list books, send requests, send messages | Phase 2 (IsEmailVerified on write endpoints) + Phase 4 (EmailVerificationGate) |
| AC3 | Inline prompt with "verify your email" message | Phase 4 (EmailVerificationGate component) |
| AC4 | "Resend" button rate-limited to 3/hr | Phase 3-4 (resend service + UI counter) |
| AC5 | OAuth users auto-verified | Phase 2 (IsEmailVerified checks is_social_account) |
| **US-804** | | |
| AC1 | Privacy policy page in EN + NL, accessible from footer | Phase 4 (PrivacyPolicyPage + Footer link) |
| AC2 | Covers required GDPR sections | Phase 4 (privacy policy content) |
| AC3 | Cookie consent banner on first visit | Phase 4 (CookieConsentBanner) |
| AC4 | Only essential cookies in MVP | Phase 4 (banner text + no analytics) |
| AC5 | DPIA documented for location data | Phase 5 (docs/DPIA-location-data.md) |
| AC6 | Data export from Settings (JSON) | Phase 2 (endpoint) + Phase 4 (DataExportButton) |
| AC7 | Encrypted at rest + in transit | Already covered (PostgreSQL + HTTPS) |

**Edge Cases to handle**:

| ID | Edge Case | Where to handle |
|----|-----------|----------------|
| EC1 | User blocks someone who sent them a pending request | Phase 2: block creation service auto-declines pending requests |
| EC2 | Mutual block (A blocks B, then B blocks A) | Phase 1: both Block records stored; unblock is one-directional |
| EC3 | User reports same person twice | Phase 2: allow duplicate reports (dedup is manual admin review) |
| EC4 | Report about completed exchange | Phase 1: `reported_exchange` FK allows linking to any exchange |
| EC5 | User registers, doesn't verify, returns 30 days later | Phase 3: resend hook always works; expired link → user clicks resend |
| EC6 | User under 16 (Dutch UAVG) | Already handled: registration has DoB field with 16+ age gate |
| EC7 | Block yourself | Phase 1: model validation prevents self-block |
| EC8 | Block/report while not email-verified | Phase 2: block requires only IsAuthenticated; report requires IsEmailVerified |

---

## 4. What's Not in This Plan

- **Admin dashboard UI** (US-802 AC6): For MVP, the Django admin interface is sufficient for report review. A custom React admin page is deferred to a later polish pass.
- **Safe meetup suggestions** (PRD E-7): Deferred to P2 per PRD.
- **Full DPIA document**: A placeholder DPIA markdown file will be created in `docs/DPIA-location-data.md` with the required structure. Detailed legal content requires input from a privacy lawyer — scheduled for pre-launch review.
- **Dutch (NL) privacy policy content**: The plan creates the page structure with EN content and NL placeholders. Full Dutch translation requires professional review.

---

## 5. Suggested Commit Sequence

1. `feat(bookswap): add Block and Report models + migrations`
2. `feat(bookswap): add IsEmailVerified permission class`
3. `feat(bookswap): expose block/unblock/list endpoints + block filtering on books/exchanges/messages`
4. `feat(bookswap): add report creation endpoint + admin list + Celery notification task`
5. `feat(bookswap): add data export endpoint (GET /users/me/data-export/)`
6. `feat(trust-safety): add TanStack Query hooks, services, and Zod schemas for block/report/export`
7. `feat(auth): add email verification gate hook and resend service`
8. `feat(trust-safety): build BlockUserButton, ReportDialog, BlockedUsersList components`
9. `feat(auth): build EmailVerificationPage and EmailVerificationPendingPage`
10. `feat(trust-safety): add CookieConsentBanner component`
11. `feat(trust-safety): add PrivacyPolicyPage and TermsOfServicePage (EN + NL structure)`
12. `feat(trust-safety): add DataExportButton and integrate all components into SettingsPage`
13. `feat(trust-safety): integrate BlockUserButton + ReportButton into PublicProfilePage, BookDetailPage, chat`
14. `test(bookswap): add acceptance-criteria tests for block, report, email gate, data export`
15. `test(trust-safety): add frontend tests for all new components and pages`
16. `docs: add DPIA-location-data.md placeholder`
