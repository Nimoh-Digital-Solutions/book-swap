# Action Plan — Epic 3: Book Listing & Management

> Generated: 2026-03-22
> Next fully-pending epic in order — Epics 1 & 2 are implemented and pushed.

---

## 1. Story Status Overview

| ID | Title | Priority | Status | Notes |
|----|-------|----------|--------|-------|
| US-301 | Add Book via ISBN Scan | P0 | ❌ Pending | No Book model, no ISBN integration, no barcode scanning |
| US-302 | Add Book via Manual Search | P0 | ❌ Pending | No search UI or Open Library API integration |
| US-303 | Upload Book Photos | P0 | ❌ Pending | No image upload pipeline, no BookPhoto model |
| US-304 | Set Book Condition & Details | P0 | ❌ Pending | No condition enum, genre list, or language fields on a Book model |
| US-305 | My Shelf Dashboard | P0 | ❌ Pending | No shelf page or book listing UI |
| US-306 | Wishlist — "Looking For" | P1 | ❌ Pending | No wishlist model or UI |

**Legend**: ✅ Implemented · ⚠️ Partial · ❌ Pending

---

## 2. Gaps in Previously Implemented Stories

> Things that are "done" on paper but have concrete ACs not yet met.

### Gap: [US-101] — Live counter "X books near you" on Landing Page

- **AC not met**: AC4 — "A live counter or sample shows 'X books available near you'"
- **Evidence**: `HeroSection.tsx` renders a static placeholder. No backend endpoint provides a book count. Requires the Book model (this epic) + a spatial count query (Epic 4).
- **Fix needed**: After this epic creates the Book model, add a `GET /api/v1/books/nearby-count/` endpoint (AllowAny) and wire it into the landing page hero section.

### Gap: [US-202] — Listed books section on Public Profile

- **AC not met**: US-202 notes state "Listed books section shows placeholder 'No books listed yet'"
- **Evidence**: `PublicProfilePage` has a placeholder block for books. No Book model or API exists to populate it.
- **Fix needed**: After this epic, add a "Books by this user" section to `PublicProfilePage` using `GET /api/v1/books/?owner={userId}` — deferred to Phase 5 integration.

_(No other gaps found in previously implemented stories that relate to Epic 3.)_

---

## 3. Implementation Plan — Epic 3: Book Listing & Management

### Context

Epic 3 is the first domain feature beyond auth/profile — it introduces the Book entity, the ISBN lookup service, image upload pipeline, and the "My Shelf" dashboard. Without books in the system, no other epic (Discovery, Exchange, Ratings) can function. This epic serves the **book owner** persona. All 5 P0 stories (US-301 through US-305) will be addressed; US-306 (Wishlist, P1) is included as it has no external dependencies and rounds out the feature.

### Stories Covered

- **US-301**: Add Book via ISBN Scan (P0)
- **US-302**: Add Book via Manual Search (P0)
- **US-303**: Upload Book Photos (P0)
- **US-304**: Set Book Condition & Details (P0)
- **US-305**: My Shelf Dashboard (P0)
- **US-306**: Wishlist — "Looking For" (P1)

---

### Phase 1 — Data Layer

**Goal**: Create the `Book`, `BookPhoto`, and `WishlistItem` models with all fields, enums, indexes, and full-text search vector. Run migrations.

**Files to create / modify**:
- `backend/bookswap/models.py` — add `BookCondition`, `BookStatus`, `Book`, `BookPhoto`, `WishlistItem`
- `backend/bookswap/migrations/` — new migration (auto-generated via `makemigrations`)

**What to build**:

- **`BookCondition`** (TextChoices enum):
  - `NEW = 'new'`, `LIKE_NEW = 'like_new'`, `GOOD = 'good'`, `ACCEPTABLE = 'acceptable'`

- **`BookStatus`** (TextChoices enum):
  - `AVAILABLE = 'available'`, `IN_EXCHANGE = 'in_exchange'`, `RETURNED = 'returned'`

- **`Book`** model:
  - `id` — UUID PK (via nimoh-base `AbstractNimohModel` or manual UUID)
  - `owner` — FK → `User`, `on_delete=CASCADE`, `related_name='books'`
  - `isbn` — `CharField(max_length=13, blank=True, db_index=True)` — ISBN-10 or ISBN-13
  - `title` — `CharField(max_length=300, db_index=True)` — required
  - `author` — `CharField(max_length=200, db_index=True)` — required
  - `description` — `TextField(blank=True)` — from API or manual entry
  - `cover_url` — `URLField(blank=True)` — from Open Library / Google Books API
  - `condition` — `CharField(max_length=20, choices=BookCondition.choices)` — required
  - `genres` — `ArrayField(CharField(max_length=50), size=3, default=list)` — max 3 genres
  - `language` — `CharField(max_length=10, choices=LANGUAGE_CHOICES)` — required (en, nl, de, fr, es, other)
  - `status` — `CharField(max_length=20, choices=BookStatus.choices, default='available', db_index=True)`
  - `notes` — `CharField(max_length=200, blank=True)` — optional owner notes
  - `page_count` — `PositiveIntegerField(null=True, blank=True)` — from API metadata
  - `publish_year` — `PositiveIntegerField(null=True, blank=True)` — from API metadata
  - `search_vector` — `SearchVectorField(null=True)` — for PostgreSQL full-text search
  - `created_at` — `DateTimeField(auto_now_add=True)`
  - `updated_at` — `DateTimeField(auto_now=True)`

- **`BookPhoto`** model (separate model instead of `ArrayField` for proper file management):
  - `id` — UUID PK
  - `book` — FK → `Book`, `on_delete=CASCADE`, `related_name='photos'`
  - `image` — `ImageField(upload_to='book_photos/')` — stored on local media (MVP)
  - `position` — `PositiveSmallIntegerField(default=0)` — ordering (0 = primary/thumbnail)
  - `created_at` — `DateTimeField(auto_now_add=True)`
  - Constraint: max 3 photos per book (enforced at serializer level)

- **`WishlistItem`** model (US-306):
  - `id` — UUID PK
  - `user` — FK → `User`, `on_delete=CASCADE`, `related_name='wishlist_items'`
  - `isbn` — `CharField(max_length=13, blank=True)` — optional ISBN-based wish
  - `title` — `CharField(max_length=300, blank=True)` — optional title-based wish
  - `author` — `CharField(max_length=200, blank=True)` — optional
  - `genre` — `CharField(max_length=50, blank=True)` — genre-based wish
  - `cover_url` — `URLField(blank=True)` — thumbnail for display
  - `created_at` — `DateTimeField(auto_now_add=True)`
  - Constraint: max 20 wishlist items per user (serializer-level)
  - Constraint: at least one of `isbn`, `title`, or `genre` must be set (model `clean()`)

**Database indexes** (per Technical Architecture doc):
- GIN index on `search_vector` — full-text search on title + author
- B-tree composite index on `(status, created_at)` — feed queries
- GIN index on `genres` — array overlap filtering
- B-tree on `isbn` — ISBN lookup (via `db_index=True`)

**Search vector setup**:
- Use a Django `SearchVector` signal or override `save()` to update `search_vector` from `title` (weight A) + `author` (weight B) after every create/update.
- Alternatively, create a PostgreSQL trigger via a data migration for better performance.

**Acceptance criteria addressed**: US-301 AC4 (auto-filled data storage), US-303 AC2–AC3 (photo storage), US-304 AC1–AC3 (condition/genre/language fields), US-305 AC2 (status field), US-306 AC1 (wishlist storage)

---

### Phase 2 — Backend API

**Goal**: Expose Book CRUD, ISBN lookup proxy, photo upload, and wishlist through authenticated REST endpoints. Add the `ISBNLookupService` for Open Library + Google Books fallback.

**Files to create / modify**:
- `backend/bookswap/serializers.py` — add `BookSerializer`, `BookListSerializer`, `BookCreateSerializer`, `BookPhotoSerializer`, `WishlistItemSerializer`, `ISBNLookupSerializer`
- `backend/bookswap/views.py` — add `BookViewSet`, `BookPhotoViewSet`, `ISBNLookupView`, `WishlistItemViewSet`
- `backend/bookswap/urls.py` — register new routes (use DRF `DefaultRouter` for viewsets)
- `backend/bookswap/services.py` — add `ISBNLookupService` (Open Library primary, Google Books fallback)
- `backend/bookswap/validators.py` — add `validate_book_photo` (magic-byte validation, size limit, Pillow re-save)

**Endpoints to build**:

| Method | Path | Auth | Description | Story |
|--------|------|------|-------------|-------|
| GET | `/api/v1/books/isbn-lookup/?isbn=<isbn>` | IsAuthenticated | Proxy ISBN lookup → Open Library → Google Books fallback. Returns metadata. Caches result in DB. | US-301, US-302 |
| GET | `/api/v1/books/search-external/?q=<query>` | IsAuthenticated | Proxy title/author search to Open Library. Returns list of book candidates. | US-302 |
| POST | `/api/v1/books/` | IsAuthenticated | Create a new book listing. Owner auto-set to `request.user`. | US-301, US-302, US-304 |
| GET | `/api/v1/books/` | IsAuthenticated | List books (filterable). Default: all available books. `?owner=me` for My Shelf. `?owner={uuid}` for a user's public books. | US-305 |
| GET | `/api/v1/books/{id}/` | IsAuthenticated | Book detail with photos, owner info, distance. | US-304, US-305 |
| PATCH | `/api/v1/books/{id}/` | IsAuthenticated + IsOwner | Update book fields (condition, genres, language, notes, status). | US-305 |
| DELETE | `/api/v1/books/{id}/` | IsAuthenticated + IsOwner | Remove a book listing. Reject if status is `in_exchange`. | US-305 |
| POST | `/api/v1/books/{id}/photos/` | IsAuthenticated + IsOwner | Upload a photo for a book. Max 3 per book. | US-303 |
| DELETE | `/api/v1/books/{id}/photos/{photo_id}/` | IsAuthenticated + IsOwner | Remove a photo. Reject if it's the last one and book is `available`. | US-303 |
| PATCH | `/api/v1/books/{id}/photos/reorder/` | IsAuthenticated + IsOwner | Reorder photos (set `position` field). | US-303 |
| GET | `/api/v1/wishlist/` | IsAuthenticated | List current user's wishlist items. | US-306 |
| POST | `/api/v1/wishlist/` | IsAuthenticated | Add a wishlist item. Max 20 per user. | US-306 |
| DELETE | `/api/v1/wishlist/{id}/` | IsAuthenticated + IsOwner | Remove a wishlist item. | US-306 |

**ISBN Lookup Service** (`ISBNLookupService`):
- Primary: Open Library — `https://openlibrary.org/isbn/{isbn}.json` (free, no API key)
- Fallback: Google Books — `https://www.googleapis.com/books/v1/volumes?q=isbn:{isbn}` (free with key, 1000 req/day)
- External search: `https://openlibrary.org/search.json?q={query}&limit=10`
- Normalize response to a consistent `BookMetadata` dict: `{ isbn, title, author, description, cover_url, page_count, publish_year }`
- Cache ISBN lookup results: if the same ISBN is requested again, return from DB (check `Book.objects.filter(isbn=isbn)` first, then a dedicated `ISBNCache` table or just rely on existing Book records)
- Timeout: 10 seconds per external API call
- Use `httpx` for async-compatible HTTP client (already a dependency for Nominatim service)

**Photo Upload Validation** (`validate_book_photo`):
- Check magic bytes: JPEG (`FF D8 FF`), PNG (`89 50 4E 47`)
- Reject files > 5MB upload size
- Re-save via Pillow: strip EXIF metadata, re-compress to max 1MB, resize longest edge to max 1200px
- Save to `MEDIA_ROOT/book_photos/{user_id}/{book_id}/` path

**Serializer details**:
- `BookListSerializer` (for list views): `id`, `title`, `author`, `cover_url`, `condition`, `language`, `status`, `primary_photo` (first photo URL), `owner` (nested: `id`, `username`, `avatar`, `neighborhood`, `avg_rating`), `created_at`
- `BookSerializer` (full detail): all `BookListSerializer` fields + `description`, `isbn`, `genres`, `notes`, `page_count`, `publish_year`, `photos` (nested list), `owner` (full public info)
- `BookCreateSerializer`: `isbn`, `title`, `author`, `description`, `cover_url`, `condition`, `genres`, `language`, `notes`, `page_count`, `publish_year`. Validates: title required, author required, condition required, language required, genres max 3.

**Permission class**:
- `IsBookOwner` — allows PATCH/DELETE only if `request.user == book.owner`

**Nimoh-stack conventions to follow**:
- UUID PKs, `created_at`/`updated_at` on every model
- `get_queryset()` scoped appropriately: My Shelf → `owner=request.user`, public → `status='available'`
- `permission_classes` declared explicitly on every view
- Split `BookListSerializer` (card data) from `BookSerializer` (full detail)

**Acceptance criteria addressed**: US-301 AC3–AC6 (ISBN lookup + auto-fill), US-302 AC1–AC5 (manual search + entry), US-303 AC1–AC9 (photo upload/reorder/delete), US-304 AC1–AC5 (condition/genre/language/notes), US-305 AC1–AC4 (CRUD endpoints), US-306 AC1–AC4 (wishlist CRUD)

---

### Phase 3 — Frontend Services & Hooks

**Goal**: Wire the new Book and Wishlist API endpoints into the frontend data layer with TypeScript types, Zod schemas, service wrappers, and TanStack Query hooks.

**Files to create**:
- `frontend/src/features/books/types/book.types.ts` — `Book`, `BookListItem`, `BookPhoto`, `BookMetadata`, `BookCondition`, `BookStatus`, `BookLanguage`, `CreateBookPayload`, `UpdateBookPayload`, `WishlistItem`, `CreateWishlistPayload`
- `frontend/src/features/books/services/bookService.ts` — axios wrappers for all Book endpoints
- `frontend/src/features/books/services/isbnService.ts` — ISBN lookup + external search wrappers
- `frontend/src/features/books/services/wishlistService.ts` — wishlist CRUD wrappers
- `frontend/src/features/books/hooks/bookKeys.ts` — TanStack Query key factory for books + wishlist
- `frontend/src/features/books/hooks/useBooks.ts` — query hook for book list (with filter params)
- `frontend/src/features/books/hooks/useBook.ts` — query hook for single book detail
- `frontend/src/features/books/hooks/useMyShelf.ts` — query hook for `?owner=me`
- `frontend/src/features/books/hooks/useCreateBook.ts` — mutation hook for `POST /books/`
- `frontend/src/features/books/hooks/useUpdateBook.ts` — mutation hook for `PATCH /books/{id}/`
- `frontend/src/features/books/hooks/useDeleteBook.ts` — mutation hook for `DELETE /books/{id}/`
- `frontend/src/features/books/hooks/useUploadBookPhoto.ts` — mutation hook for photo upload
- `frontend/src/features/books/hooks/useDeleteBookPhoto.ts` — mutation hook for photo delete
- `frontend/src/features/books/hooks/useReorderPhotos.ts` — mutation hook for photo reorder
- `frontend/src/features/books/hooks/useISBNLookup.ts` — query hook for ISBN lookup (enabled on demand)
- `frontend/src/features/books/hooks/useExternalBookSearch.ts` — query hook for title/author search (debounced)
- `frontend/src/features/books/hooks/useWishlist.ts` — query hook for wishlist items
- `frontend/src/features/books/hooks/useAddWishlistItem.ts` — mutation hook
- `frontend/src/features/books/hooks/useRemoveWishlistItem.ts` — mutation hook
- `frontend/src/features/books/schemas/bookSchema.ts` — Zod schemas: `createBookSchema`, `updateBookSchema`, `wishlistItemSchema`

**Files to modify**:
- `frontend/src/configs/apiEndpoints.ts` — add `books` and `wishlist` endpoint groups:
  ```typescript
  const BOOKS = `${V1}/books` as const;
  const WISHLIST = `${V1}/wishlist` as const;

  books: {
    list: `${BOOKS}/`,
    detail: (id: string) => `${BOOKS}/${id}/`,
    create: `${BOOKS}/`,
    isbnLookup: `${BOOKS}/isbn-lookup/`,
    searchExternal: `${BOOKS}/search-external/`,
    photos: (bookId: string) => `${BOOKS}/${bookId}/photos/`,
    photoDetail: (bookId: string, photoId: string) => `${BOOKS}/${bookId}/photos/${photoId}/`,
    photosReorder: (bookId: string) => `${BOOKS}/${bookId}/photos/reorder/`,
  },
  wishlist: {
    list: `${WISHLIST}/`,
    create: `${WISHLIST}/`,
    detail: (id: string) => `${WISHLIST}/${id}/`,
  },
  ```

**Key factory pattern** (`bookKeys.ts`):
```typescript
export const bookKeys = {
  all: ['books'] as const,
  lists: () => [...bookKeys.all, 'list'] as const,
  list: (filters: Record<string, unknown>) => [...bookKeys.lists(), filters] as const,
  myShelf: () => [...bookKeys.all, 'my-shelf'] as const,
  details: () => [...bookKeys.all, 'detail'] as const,
  detail: (id: string) => [...bookKeys.details(), id] as const,
  isbnLookup: (isbn: string) => [...bookKeys.all, 'isbn', isbn] as const,
  externalSearch: (query: string) => [...bookKeys.all, 'search', query] as const,
};

export const wishlistKeys = {
  all: ['wishlist'] as const,
  list: () => [...wishlistKeys.all, 'list'] as const,
};
```

**Nimoh-stack conventions to follow**:
- `credentials: 'include'` on the API client (already configured in `http.ts`)
- Key factory pattern matching `profileKeys` convention
- No access token in localStorage — Zustand memory store for auth (already in place)
- Zod schemas for all form validation
- `multipart/form-data` for photo uploads via `FormData`

**Acceptance criteria addressed**: US-301 AC3 (ISBN lookup hook), US-302 AC1–AC2 (search hook), US-303 AC1–AC7 (photo hooks), US-305 AC1–AC2 (shelf query)

---

### Phase 4 — Frontend UI

**Goal**: Build the Add Book flow (ISBN scan + manual search + photo upload + condition/details), My Shelf dashboard, Book Detail page, and Wishlist tab.

**Files to create**:

#### 4a. Add Book Flow (US-301, US-302, US-303, US-304)
- `frontend/src/features/books/pages/AddBookPage.tsx` — multi-step wizard: (1) Find book, (2) Upload photos, (3) Set details, (4) Review & submit
- `frontend/src/features/books/components/AddBookWizard/AddBookWizard.tsx` — wizard state management (step navigation)
- `frontend/src/features/books/components/AddBookWizard/index.ts` — barrel export
- `frontend/src/features/books/components/ISBNScanner/ISBNScanner.tsx` — camera barcode scanner using `@aspect-software/barcode-reader` or `@nicepkg/gpt-barcode` or equivalent. Uses `navigator.mediaDevices.getUserMedia`. Progressive enhancement: only shows "Scan Barcode" button when `getUserMedia` is available.
- `frontend/src/features/books/components/ISBNScanner/index.ts`
- `frontend/src/features/books/components/ManualBookSearch/ManualBookSearch.tsx` — debounced search input (300ms), results as book cards from Open Library proxy, "Can't find your book?" fallback to manual entry form
- `frontend/src/features/books/components/ManualBookSearch/index.ts`
- `frontend/src/features/books/components/ManualBookForm/ManualBookForm.tsx` — fully manual entry: title, author, description, cover upload, genre, language
- `frontend/src/features/books/components/ManualBookForm/index.ts`
- `frontend/src/features/books/components/BookPhotoUpload/BookPhotoUpload.tsx` — upload 1–3 photos with drag-and-drop reorder, progress indicator, remove button, client-side compression (browser-image-compression lib → max 1200px longest edge, ~80% quality, max 1MB)
- `frontend/src/features/books/components/BookPhotoUpload/index.ts`
- `frontend/src/features/books/components/ConditionSelector/ConditionSelector.tsx` — 4-option radio/card selector with tooltip descriptions for each condition level
- `frontend/src/features/books/components/ConditionSelector/index.ts`
- `frontend/src/features/books/components/BookGenrePicker/BookGenrePicker.tsx` — multi-select (max 3) from predefined genre list
- `frontend/src/features/books/components/BookGenrePicker/index.ts`
- `frontend/src/features/books/components/LanguageSelector/LanguageSelector.tsx` — dropdown: English, Dutch, German, French, Spanish, Other
- `frontend/src/features/books/components/LanguageSelector/index.ts`
- `frontend/src/features/books/components/BookReviewStep/BookReviewStep.tsx` — review all fields before submit, all editable

#### 4b. My Shelf Dashboard (US-305)
- `frontend/src/features/books/pages/MyShelfPage.tsx` — grid/list of user's books with status badges, sort controls, "Add Book" CTA
- `frontend/src/features/books/components/BookCard/BookCard.tsx` — reusable card: cover thumbnail, title, author, condition badge, status badge, date listed
- `frontend/src/features/books/components/BookCard/index.ts`
- `frontend/src/features/books/components/StatusBadge/StatusBadge.tsx` — colored badge: Available (green), In Exchange (orange), Returned (blue)
- `frontend/src/features/books/components/StatusBadge/index.ts`
- `frontend/src/features/books/components/ConditionBadge/ConditionBadge.tsx` — condition display badge
- `frontend/src/features/books/components/ConditionBadge/index.ts`
- `frontend/src/features/books/components/EmptyShelf/EmptyShelf.tsx` — friendly empty state with illustration + "List your first book" CTA
- `frontend/src/features/books/components/EmptyShelf/index.ts`
- `frontend/src/features/books/components/DeleteBookDialog/DeleteBookDialog.tsx` — confirmation dialog for book removal

#### 4c. Edit Book (US-305)
- `frontend/src/features/books/pages/EditBookPage.tsx` — pre-filled form with existing book data (reuses condition/genre/language components)
- `frontend/src/features/books/components/EditBookForm/EditBookForm.tsx` — React Hook Form + Zod for updating book fields + managing photos

#### 4d. Book Detail Page (shared with Epic 4 but owned here)
- `frontend/src/features/books/pages/BookDetailPage.tsx` — full book view: photos carousel, metadata, condition, owner preview card, "Request Swap" button (disabled/placeholder until Epic 5)

#### 4e. Wishlist (US-306)
- `frontend/src/features/books/components/WishlistTab/WishlistTab.tsx` — tab within My Shelf or separate section: list of wishlist items with remove button, "Add to Wishlist" search/entry form
- `frontend/src/features/books/components/WishlistTab/index.ts`

**Files to modify**:
- `frontend/src/routes/config/paths.ts` — add:
  ```
  ADD_BOOK: '/books/add'
  MY_SHELF: '/my-shelf'
  BOOK_DETAIL: '/books/:id'
  EDIT_BOOK: '/books/:id/edit'
  ```
- `frontend/src/routes/config/routesConfig.tsx` — register new routes with `ProtectedRoute` guard
- `frontend/src/components/common/Header/` or navigation — add "My Shelf" nav link

**Routes to register**:

| Path | Component | Guard | Notes |
|------|-----------|-------|-------|
| `/books/add` | `AddBookPage` | `ProtectedRoute` | Multi-step book listing wizard |
| `/my-shelf` | `MyShelfPage` | `ProtectedRoute` | User's book inventory |
| `/books/:id` | `BookDetailPage` | `ProtectedRoute` | Public book detail view |
| `/books/:id/edit` | `EditBookPage` | `ProtectedRoute` + `IsOwner` (FE guard) | Edit own book listing |

**UX notes** (from user stories):
- US-301: "Scan Barcode" only shown when `getUserMedia` is available. Camera permission prompt with explanation text. Auto-filled data is fully editable before saving.
- US-302: Search debounced 300ms with loading state. "Can't find your book?" fallback to manual form. "Powered by Open Library" attribution.
- US-303: Min 1, max 3 photos. Client-side compression before upload. Drag-and-drop reorder. Progress indicator. First photo = primary thumbnail.
- US-304: Condition tooltip descriptions. Genre max 3. Language required. Notes max 200 chars.
- US-305: Status badges: Available (green), In Exchange (orange), Returned (blue). Sort by date/title/status. Empty state with illustration. "You have X books listed (Y available)" count.
- US-306: Wishlist visible on profile. Max 20 items. Add by ISBN search, title/author search, or just genre.

**i18n**: Add book-related strings to `en.json`, `fr.json`, and `nl.json` (when created) translation files. Namespace: `books`, `shelf`, `wishlist`.

**Acceptance criteria addressed**: US-301 AC1–AC7, US-302 AC1–AC6, US-303 AC1–AC9, US-304 AC1–AC5, US-305 AC1–AC8, US-306 AC1–AC5

---

### Phase 5 — Integration & Acceptance Criteria Check

**Goal**: Connect everything end-to-end and verify every AC is met.

**Tasks**:
- [ ] Register Book and Wishlist URL routes in `backend/bookswap/urls.py` (via DRF router)
- [ ] Ensure `bookswap.urls` is already included in `config/urls.py` (it is: `path('api/v1/', include('bookswap.urls'))`)
- [ ] Configure `MEDIA_URL` and `MEDIA_ROOT` in settings for local photo storage (MVP: `/mnt/bookswap-media/` or Docker volume)
- [ ] Add Nginx media serving config for development (or Django `static()` for `DEBUG=True`)
- [ ] Add MSW handlers in `frontend/src/test/mocks/handlers/` for:
  - `GET /api/v1/books/`, `POST /api/v1/books/`, `GET /api/v1/books/:id/`, `PATCH /api/v1/books/:id/`, `DELETE /api/v1/books/:id/`
  - `GET /api/v1/books/isbn-lookup/`, `GET /api/v1/books/search-external/`
  - `POST /api/v1/books/:id/photos/`, `DELETE /api/v1/books/:id/photos/:photoId/`
  - `GET /api/v1/wishlist/`, `POST /api/v1/wishlist/`, `DELETE /api/v1/wishlist/:id/`
- [ ] Write backend tests in `backend/bookswap/tests/`:
  - **Model tests**: Book creation, status transitions, search vector update, BookPhoto ordering, WishlistItem validation
  - **API tests (happy path)**: Create book via ISBN, create book manually, upload photo, list my shelf, edit book, delete book, CRUD wishlist
  - **API tests (error path)**: Create book without photo (deferred to publish), duplicate ISBN for same owner, delete book in exchange, upload 4th photo, upload non-image file, exceed wishlist limit
  - **Service tests**: ISBNLookupService with mocked httpx responses (Open Library success, fallback to Google Books, both fail)
- [ ] Write frontend tests:
  - `BookCard` renders title, author, condition badge, status badge
  - `AddBookWizard` step navigation works
  - `ManualBookSearch` debounces and displays results
  - `BookPhotoUpload` accepts JPEG/PNG, rejects other formats, enforces max 3
  - `ConditionSelector` selects and shows tooltip
  - `MyShelfPage` renders book list, handles empty state
  - `BookDetailPage` displays all book metadata
  - `WishlistTab` adds/removes items
- [ ] Verify all i18n strings are present in `en.json` and `fr.json`
- [ ] Wire "My Shelf" link into main navigation (Header component)
- [ ] Verify `bookKeys` cache invalidation: creating a book invalidates `myShelf` and `lists` queries

**Acceptance Criteria Checklist**:

| Story | AC | Acceptance Criterion | Covered in Phase |
|-------|----|---------------------|-----------------|
| US-301 | AC1 | "Add Book" opens screen with "Scan Barcode" and "Search Manually" options | Phase 4a (AddBookPage) |
| US-301 | AC2 | "Scan Barcode" activates device camera (MediaDevices API) | Phase 4a (ISBNScanner) |
| US-301 | AC3 | ISBN extracted → Open Library API (fallback: Google Books) | Phase 2 (ISBNLookupService) + Phase 3 (useISBNLookup) |
| US-301 | AC4 | API returns: title, author, cover, description, page count, year | Phase 2 (ISBNLookupService normalize) |
| US-301 | AC5 | Auto-filled data displayed for review — all editable | Phase 4a (BookReviewStep) |
| US-301 | AC6 | ISBN not found → "Book not found" → manual flow (US-302) | Phase 4a (fallback navigation) |
| US-301 | AC7 | Camera permission prompt handled gracefully | Phase 4a (ISBNScanner) |
| US-302 | AC1 | Search input accepts title, author, or combination | Phase 4a (ManualBookSearch) |
| US-302 | AC2 | Results from Open Library API shown as cards | Phase 4a (ManualBookSearch) + Phase 2 (search-external) |
| US-302 | AC3 | Select match → auto-fill | Phase 4a (ManualBookSearch → wizard state) |
| US-302 | AC4 | "Can't find?" → manual entry form | Phase 4a (ManualBookForm) |
| US-302 | AC5 | Manual form: title, author, description, cover, genre, language | Phase 4a (ManualBookForm) |
| US-302 | AC6 | Search debounced (300ms) with loading state | Phase 3 (useExternalBookSearch) + Phase 4a (UI) |
| US-303 | AC1 | Photo upload in "Add Book" and "Edit Book" flows | Phase 4a + 4c (BookPhotoUpload) |
| US-303 | AC2 | Min 1 photo required before listing | Phase 2 (serializer) + Phase 4a (wizard validation) |
| US-303 | AC3 | Max 3 photos | Phase 2 (serializer) + Phase 4a (UI limit) |
| US-303 | AC4 | JPEG, PNG only | Phase 2 (backend magic-byte) + Phase 4a (frontend type check) |
| US-303 | AC5 | Client-side compression: 1200px max, ~80% quality, max 1MB | Phase 4a (BookPhotoUpload + browser-image-compression) |
| US-303 | AC6 | Upload progress indicator | Phase 4a (BookPhotoUpload) |
| US-303 | AC7 | Reorder photos (drag/arrows) — first = thumbnail | Phase 4a (BookPhotoUpload) + Phase 2 (reorder endpoint) |
| US-303 | AC8 | Remove photos individually | Phase 3 (useDeleteBookPhoto) + Phase 4a (UI) |
| US-303 | AC9 | Photos served with responsive sizing | Phase 2 (backend Pillow resize) + Nginx config |
| US-304 | AC1 | Condition selector: 4 options with tooltips | Phase 4a (ConditionSelector) |
| US-304 | AC2 | Genre multi-select: max 3 | Phase 4a (BookGenrePicker) |
| US-304 | AC3 | Language selector: en, nl, de, fr, es, other (required) | Phase 4a (LanguageSelector) |
| US-304 | AC4 | Notes field: max 200 chars | Phase 4a (wizard) + Phase 2 (serializer) |
| US-304 | AC5 | All selections on listing card and detail page | Phase 4b (BookCard) + Phase 4d (BookDetailPage) |
| US-305 | AC1 | "My Shelf" accessible from main nav | Phase 4b (nav link) |
| US-305 | AC2 | Cards with: cover, title, author, condition, status, date | Phase 4b (BookCard) |
| US-305 | AC3 | Status badges: Available (green), In Exchange (orange), Returned (blue) | Phase 4b (StatusBadge) |
| US-305 | AC4 | Actions: Edit, Remove (with confirmation) | Phase 4b (BookCard actions + DeleteBookDialog) |
| US-305 | AC5 | "Add Book" CTA prominent (especially when empty) | Phase 4b (EmptyShelf + page header) |
| US-305 | AC6 | Sort: date added, title A–Z, status | Phase 4b (MyShelfPage sort controls) |
| US-305 | AC7 | Empty state with illustration + message | Phase 4b (EmptyShelf) |
| US-305 | AC8 | Count: "X books listed (Y available)" | Phase 4b (MyShelfPage header count) |
| US-306 | AC1 | "Looking For" as tab on My Shelf or profile section | Phase 4e (WishlistTab) |
| US-306 | AC2 | Add by ISBN search, title/author search, or genre | Phase 4e (WishlistTab search form) |
| US-306 | AC3 | Visible on public profile | Deferred: PublicProfilePage update after wishlist API exists |
| US-306 | AC4 | Max 20 items | Phase 2 (serializer) + Phase 4e (UI limit) |
| US-306 | AC5 | Remove items individually | Phase 3 (useRemoveWishlistItem) + Phase 4e (UI) |

**Edge Cases to handle**:

| Story | EC | Edge Case | Where to handle |
|-------|----|-----------|----------------|
| US-301 | EC1 | Book has no barcode → manual search | Phase 4a (ISBNScanner fallback link) |
| US-301 | EC2 | Camera permission denied | Phase 4a (ISBNScanner explanation + manual link) |
| US-301 | EC3 | ISBN scan returns wrong book (different edition) | Phase 4a (all fields editable in ReviewStep) |
| US-301 | EC4 | Multiple ISBNs (ISBN-10 + ISBN-13) → try ISBN-13 first | Phase 2 (ISBNLookupService) |
| US-302 | EC1 | Very common title → paginated results | Phase 2 (search-external pagination) + Phase 4a (scroll) |
| US-302 | EC2 | Non-Latin script search | Phase 2 (Open Library supports multilingual) |
| US-302 | EC3 | Partial title → fuzzy matching | Phase 2 (Open Library fuzzy search) |
| US-303 | EC1 | Non-image file upload | Phase 2 (magic-byte validation) + Phase 4a (file type check) |
| US-303 | EC2 | Upload fails mid-way (network) | Phase 4a (retry button per image) |
| US-303 | EC3 | User tries > 3 photos | Phase 4a (disable upload after 3) + Phase 2 (reject at API) |
| US-304 | EC1 | No condition selected → block listing | Phase 4a (wizard validation) + Phase 2 (serializer required) |
| US-305 | EC1 | Remove book with pending partner request → auto-decline | Phase 2 (delete view checks pending requests — deferred to Epic 5) |
| US-305 | EC2 | Remove book in active exchange → block removal | Phase 2 (delete view rejects if `status='in_exchange'`) |
| US-306 | EC1 | Wishlist book available nearby → "Available now!" badge | Deferred to Phase 2 (P2 feature per user story) |

---

## 4. What's Not in This Plan

| Item | Reason |
|------|--------|
| **US-305 EC1 — Auto-decline pending requests on book removal** | Depends on Epic 5 (`ExchangeRequest` model). The delete endpoint will return a clean error for now; auto-decline wired in Epic 5. |
| **US-306 AC3 — Wishlist visible on public profile** | Minor wiring: after the wishlist API exists, update `PublicProfilePage` to show wishlist section. Can be a follow-up PR or done in Epic 5 integration. |
| **Full-text search endpoints for Discovery (Epic 4)** | The `search_vector` column and GIN index are created in Phase 1, but the spatial browse/filter/search UI is Epic 4. The Book model is search-ready. |
| **"Request Swap" button on BookDetailPage** | Placeholder/disabled in Phase 4d. Functional button depends on Epic 5 (Exchange model). |
| **Nearby book counter on Landing Page** | Requires a spatial count query (PostGIS `ST_DWithin`). After the Book model exists, this can be added as a follow-up; the query itself belongs to Epic 4. |

---

## 5. Suggested Commit Sequence

1. `feat(bookswap): add Book, BookPhoto, WishlistItem models + migrations with FTS vector`
2. `feat(bookswap): add ISBNLookupService with Open Library + Google Books fallback`
3. `feat(bookswap): expose Book CRUD API with BookViewSet, serializers, and IsBookOwner permission`
4. `feat(bookswap): add photo upload/delete/reorder endpoints with Pillow validation`
5. `feat(bookswap): add WishlistItem CRUD API endpoints`
6. `feat(books): add TanStack Query hooks, Zod schemas, and API endpoint constants`
7. `feat(books): build AddBookPage wizard with ISBN scanner, manual search, and photo upload`
8. `feat(books): build MyShelfPage with BookCard, StatusBadge, sort, and empty state`
9. `feat(books): build BookDetailPage with photo carousel and owner preview`
10. `feat(books): build EditBookPage and WishlistTab`
11. `test(bookswap): add Book model, API, and ISBNLookupService acceptance-criteria tests`
12. `test(books): add frontend component and integration tests for book features`
13. `chore(i18n): add en/fr/nl translations for books, shelf, and wishlist namespaces`

---

*— End of Action Plan —*
