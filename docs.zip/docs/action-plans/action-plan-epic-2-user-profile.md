# Action Plan — Epic 2: User Profile

> Generated: 2026-03-22
> Next partially-implemented epic in dependency order — Epic 1 (auth) is complete.

---

## 1. Story Status Overview

| ID | Title | Priority | Status | Notes |
|----|-------|----------|--------|-------|
| US-201 | Create & Edit Profile | P0 | ⚠️ Partial | Backend: `UserMeView` (GET+PATCH) + `UserUpdateSerializer` + `UserPrivateSerializer` done. Frontend: `ProfilePage` (read-only view with stats, genres, bio, avatar), `useProfile` hook, `useUpdateProfile` mutation hook, `profileEditSchema` (Zod), `profileService.updateMe()`. **Missing**: Edit Profile form UI (the "Edit Profile" button opens nothing), display name uniqueness check (debounced), avatar upload with client-side resize, genre multi-select UI |
| US-202 | View Another User's Profile | P0 | ⚠️ Partial | Backend: `UserDetailView` (GET `/api/v1/users/<uuid>/`) + `UserPublicSerializer`. Frontend: `usePublicProfile` hook + `profileService.getPublicProfile()` + `UserPublicProfile` type. **Missing**: `PublicProfilePage` component, route `/profile/:id`, "New member" badge for 0-swap users, avg_rating hide when < 3 ratings, listed books section (deferred to Epic 3) |
| US-203 | Account Deletion (GDPR) | P1 | ❌ Pending | No `deletion_requested_at` field on User model, no soft-delete flow, no anonymization Celery task, no "Delete Account" UI, no re-auth confirmation, no grace period cancellation, no confirmation email |

**Legend**: ✅ Implemented · ⚠️ Partial · ❌ Pending

---

## 2. Gaps in Previously Implemented Stories

> Concrete ACs from US-201/US-202 that are "done on paper" but have gaps.

### Gap: [US-201] — No Edit Profile Form UI

- **AC not met**: AC4 — "All fields editable at any time from a 'Settings' or 'Edit Profile' page"
- **Evidence**: `ProfilePage.tsx` has an "Edit Profile" button that renders `<button>` with no `onClick` handler or linked route. No `EditProfileForm` component exists anywhere in the codebase.
- **Fix needed**: Build `EditProfileForm` component using React Hook Form + Zod (`profileEditSchema` already exists) that calls `useUpdateProfile` mutation.

### Gap: [US-201] — No Display Name Uniqueness Check

- **AC not met**: AC2 — "Display name uniqueness checked in real-time (debounced 300ms)"
- **Evidence**: The current User model uses `username` (from `AbstractNimohUser`) rather than a separate `display_name` field. No username/display-name availability endpoint exists. No frontend debounced check exists.
- **Fix needed**: Add `GET /api/v1/users/check-username/?q=<name>` endpoint on backend. Add debounced availability check in the edit profile form. (Note: the PRD says "display name" but the implementation uses `username` as the public display identifier — this plan continues with `username` to stay consistent with the existing model.)

### Gap: [US-201] — No Avatar Upload with Client-Side Resize

- **AC not met**: AC3 — "Profile photo: upload JPEG/PNG, max 2MB, auto-cropped to square, resized to 200×200px"
- **Evidence**: `UserUpdateSerializer` accepts `avatar` as `ImageField` and the `UpdateProfilePayload` type includes `avatar?: File | null`, but there is no file upload UI, no client-side image compression, and no server-side file-type/size validation.
- **Fix needed**: Add avatar upload section to EditProfileForm with client-side canvas resize (200×200 square crop, JPEG/PNG only, max 2MB). Add `FileUploadField` component. Add backend `validate_avatar()` method on `UserUpdateSerializer`.

### Gap: [US-201] — No Genre Multi-Select UI

- **AC not met**: AC1 (partial) — "preferred genres (multi-select, max 5)"
- **Evidence**: `ProfilePage` displays genres as read-only chips. `profileEditSchema` validates `preferred_genres` array max 5. But no genre picker component exists.
- **Fix needed**: Build `GenrePicker` component with the 21 predefined genre options from the user story, wire into EditProfileForm.

### Gap: [US-202] — Rating Display Logic Missing

- **AC not met**: AC1 (partial) — "average rating (if 3+ ratings)" and EC2 — "User with 0 swaps and no ratings → show 'New member' badge"
- **Evidence**: `ProfilePage` always displays `avg_rating` regardless of `rating_count`. `UserPublicSerializer` always includes `avg_rating`. No "New member" badge logic exists.
- **Fix needed**: Frontend conditional: show star rating only when `rating_count >= 3`, otherwise show "New member" badge. Backend `UserPublicSerializer` could optionally null out `avg_rating` when `rating_count < 3` for extra safety.

### Gap: [US-202] — Deactivated User Handling Missing

- **AC not met**: EC1 — "Profile of a deleted/deactivated user → show 'This user is no longer active'"
- **Evidence**: `UserDetailView` filters `is_active=True` (returns 404 for inactive users). No custom error message on the frontend for this case.
- **Fix needed**: Frontend `PublicProfilePage` should detect a 404 response and show "This user is no longer active" rather than a generic error.

---

## 3. Implementation Plan — Epic 2: User Profile

### Context

Epic 2 completes the user profile experience: letting users edit their profiles (bio, avatar, genres), view each other's public profiles, and exercise their GDPR right to erasure. This is foundational for trust — before Epic 5 (exchanges), users need to assess each other. US-201 and US-202 are P0 (must-have for launch); US-203 is P1 but legally required before going live in the EU.

### Stories Covered

- **US-201**: Create & Edit Profile (completing the partial implementation)
- **US-202**: View Another User's Profile (completing the partial implementation)
- **US-203**: Account Deletion / GDPR (full implementation from scratch)

---

### Phase 1 — Data Layer (Backend Model Updates)

**Goal**: Add the `deletion_requested_at` field for GDPR soft-delete and add server-side avatar validation. No new models needed — the `User` model already has all profile fields.

**Files to modify**:
- `backend/bookswap/models.py` — add `deletion_requested_at` field
- `backend/bookswap/migrations/` — new migration

**What to build**:
- **`deletion_requested_at`**: `DateTimeField(null=True, blank=True)` — set when user requests account deletion, cleared if they cancel within the 30-day grace period. As specified in the Technical Architecture doc and PRD requirement A-6.

**No changes to existing profile fields** — `bio`, `avatar`, `preferred_genres`, `preferred_language`, `preferred_radius` are already on the `User` model.

**Acceptance criteria addressed**: US-203 AC4 (anonymized within 30 days), US-203 EC2 (grace period / cancel deletion)

---

### Phase 2 — Backend API

**Goal**: Add the missing endpoints for username availability check, account deletion request, account deletion cancellation, and GDPR anonymization task. Enhance existing serializers with avatar validation and rating display logic.

**Files to create / modify**:
- `backend/bookswap/serializers.py` — add `CheckUsernameSerializer`, `AccountDeletionSerializer`, avatar validation on `UserUpdateSerializer`, rating display logic on `UserPublicSerializer`
- `backend/bookswap/views.py` — add `CheckUsernameView`, `AccountDeletionRequestView`, `AccountDeletionCancelView`
- `backend/bookswap/urls.py` — register new routes
- `backend/bookswap/tasks.py` — new file: `anonymize_deleted_accounts` Celery Beat task, `send_deletion_confirmation_email` task
- `backend/config/settings/base.py` — add anonymization task to `CELERY_BEAT_SCHEDULE`

**Endpoints to build**:

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/v1/users/check-username/?q=<name>` | IsAuthenticated | Check if username is available (returns `{ available: bool, suggestions?: string[] }`) |
| POST | `/api/v1/users/me/delete/` | IsAuthenticated | Request account deletion — requires password re-entry. Sets `deletion_requested_at`, `is_active=False`. Sends confirmation email. |
| POST | `/api/v1/users/me/delete/cancel/` | AllowAny (with signed token) | Cancel pending deletion within 30-day grace period. Clears `deletion_requested_at`, re-enables account. |

**Serializer changes**:
- `UserUpdateSerializer`: add `validate_avatar()` — reject non-JPEG/PNG, reject > 2MB
- `UserPublicSerializer`: add `get_avg_rating()` method field — return `null` when `rating_count < 3`
- `AccountDeletionSerializer`: validate password (or OAuth re-auth), check no active exchanges

**Celery tasks**:
- `anonymize_deleted_accounts()` — runs daily via Beat. Finds users where `deletion_requested_at` is > 30 days ago and `is_active=False`. Anonymizes: `username` → `deleted_<hash[:8]>`, `email` → SHA-256 hash, `first_name`/`last_name` → "Deleted", `bio` → "", `date_of_birth` → null, `location` → null, `avatar` → hard-delete file + set null. Irreversible.
- `send_deletion_confirmation_email()` — sends "Your account has been scheduled for deletion. You have 30 days to cancel." with a signed cancellation link.

**Nimoh-stack conventions to follow**:
- UUID PKs, `created_at`/`updated_at` on every model (inherited from `AbstractNimohUser`)
- `permission_classes` declared explicitly on every view
- Split list/detail serializers where appropriate
- Signed token for deletion cancellation link (using `django.core.signing`)

**Acceptance criteria addressed**: US-201 AC2 (display name uniqueness), US-203 AC1-AC7 (full deletion flow)

---

### Phase 3 — Frontend Services & Hooks

**Goal**: Wire the new backend endpoints into the frontend data layer and add missing mutation hooks.

**Files to create**:
- `frontend/src/features/profile/services/profileService.ts` — add `checkUsername()`, `requestDeletion()`, `cancelDeletion()` methods to existing `profileService` (modify existing file)
- `frontend/src/features/profile/hooks/useCheckUsername.ts` — debounced query hook for username availability
- `frontend/src/features/profile/hooks/useDeleteAccount.ts` — mutation hook for `POST /users/me/delete/`
- `frontend/src/features/profile/types/profile.types.ts` — add `CheckUsernameResponse`, `AccountDeletionPayload` types (modify existing file)

**Files to modify**:
- `frontend/src/configs/apiEndpoints.ts` — add `users.checkUsername`, `users.meDelete`, `users.meDeleteCancel` endpoints

**Nimoh-stack conventions to follow**:
- `credentials: 'include'` on the API client (already configured)
- Key factory pattern: extend `profileKeys` with `.checkUsername(query)` key
- No access token in localStorage — Zustand memory store for auth (already in place)

**Acceptance criteria addressed**: US-201 AC2, US-203 AC1-AC2

---

### Phase 4 — Frontend UI

**Goal**: Build the Edit Profile form, Public Profile page, and Account Deletion flow UI.

**Files to create**:
- `frontend/src/features/profile/components/EditProfileForm/EditProfileForm.tsx` — React Hook Form + Zod, avatar upload, genre picker, username check
- `frontend/src/features/profile/components/EditProfileForm/index.ts` — barrel export
- `frontend/src/features/profile/components/GenrePicker/GenrePicker.tsx` — multi-select checkbox grid for 21 genre options
- `frontend/src/features/profile/components/GenrePicker/index.ts` — barrel export
- `frontend/src/features/profile/components/AvatarUpload/AvatarUpload.tsx` — image upload with client-side canvas resize (200×200 square crop, JPEG/PNG, max 2MB)
- `frontend/src/features/profile/components/AvatarUpload/index.ts` — barrel export
- `frontend/src/features/profile/pages/EditProfilePage.tsx` — wraps `EditProfileForm` with page layout
- `frontend/src/features/profile/pages/PublicProfilePage.tsx` — shows another user's public profile (similar layout to `ProfilePage` but with public data, "New member" badge, no edit button)
- `frontend/src/features/profile/components/DeleteAccountDialog/DeleteAccountDialog.tsx` — confirmation dialog with password re-entry
- `frontend/src/features/profile/components/DeleteAccountDialog/index.ts` — barrel export
- `frontend/src/features/profile/components/NewMemberBadge/NewMemberBadge.tsx` — "New Member" badge for users with 0 swaps/ratings

**Files to modify**:
- `frontend/src/features/profile/pages/ProfilePage.tsx` — wire "Edit Profile" button to navigate to `/profile/edit`. Add "New member" badge logic. Hide `avg_rating` when `rating_count < 3`.
- `frontend/src/pages/SettingsPage/SettingsPage.tsx` — add "Delete Account" section with `DeleteAccountDialog` trigger
- `frontend/src/routes/config/paths.ts` — add `PROFILE_EDIT: '/profile/edit'`, `PUBLIC_PROFILE: '/profile/:id'`
- `frontend/src/routes/config/routesConfig.tsx` — register `EditProfilePage` and `PublicProfilePage` routes
- `frontend/src/features/profile/index.ts` — export new components and pages

**Routes to register**:

| Path | Component | Guard | Notes |
|------|-----------|-------|-------|
| `/profile/edit` | `EditProfilePage` | `ProtectedRoute` | Authenticated user edits own profile |
| `/profile/:id` | `PublicProfilePage` | `ProtectedRoute` | View another user's public profile |

**UX notes** (from user stories):
- US-201: Display name uniqueness checked with debounced inline feedback (300ms). Avatar upload shows preview before submit. Genre picker shows all 21 options as a checkbox grid. Success toast on save.
- US-202: Show "New member" badge instead of rating when `rating_count < 3`. Show "This user is no longer active" for 404 responses. Listed books section shows placeholder "No books listed yet" (actual book listings depend on Epic 3).
- US-203: "Delete Account" behind a confirmation dialog. User must re-enter password. Copy: "This will permanently delete your account, all your book listings, exchange history, and messages. This cannot be undone." Active exchange blocks deletion.

**i18n**: Add profile-related strings to both `en` and `nl` translation namespaces.

**Acceptance criteria addressed**: US-201 AC1-AC6, US-202 AC1-AC2, US-203 AC1-AC2

---

### Phase 5 — Integration & Acceptance Criteria Check

**Goal**: Connect everything end-to-end and verify every AC is met.

**Tasks**:
- [ ] Ensure new backend URLs are registered in `config/urls.py` (already included via `bookswap.urls`)
- [ ] Add `anonymize_deleted_accounts` Celery Beat task to `CELERY_BEAT_SCHEDULE` in `config/settings/base.py`
- [ ] Add MSW handlers in `frontend/src/test/mocks/handlers/` for: `PATCH /users/me/`, `GET /users/check-username/`, `POST /users/me/delete/`, `GET /users/:id/`
- [ ] Write backend tests in `backend/bookswap/tests/test_api.py`:
  - Happy path: edit profile (PATCH), check username availability, request deletion, cancel deletion
  - Error path: upload non-image avatar, duplicate username, delete with active exchange, under-age deletion
  - Celery task: anonymization after 30 days (mock `timezone.now`)
- [ ] Write frontend tests:
  - `EditProfileForm` renders and submits correctly
  - `PublicProfilePage` displays correct data, handles 404
  - `DeleteAccountDialog` requires password, shows confirmation
  - `GenrePicker` enforces max 5 selection
  - `AvatarUpload` rejects non-image files
- [ ] Verify all translations are in both `en` and `nl` JSON files
- [ ] Verify `profileKeys` cache invalidation works correctly after mutations

**Acceptance Criteria Checklist**:

| Story | AC | Acceptance Criterion | Covered in Phase |
|-------|----|---------------------|-----------------|
| US-201 | AC1 | Profile fields: display name, bio, photo, genres, language | Phase 4 (EditProfileForm) |
| US-201 | AC2 | Display name uniqueness checked in real-time (debounced 300ms) | Phase 2 (endpoint) + Phase 3 (hook) + Phase 4 (form) |
| US-201 | AC3 | Photo: JPEG/PNG, max 2MB, auto-cropped to square 200×200px | Phase 2 (validation) + Phase 4 (AvatarUpload) |
| US-201 | AC4 | All fields editable from "Edit Profile" page | Phase 4 (EditProfilePage) |
| US-201 | AC5 | Changes saved on submit with success confirmation | Phase 4 (toast on mutation success) |
| US-201 | AC6 | Profile visible to other users | Phase 4 (PublicProfilePage) — already served by backend |
| US-202 | AC1 | Public profile shows: name, bio, photo, neighborhood, genres, member since, swap count, avg rating (if 3+) | Phase 4 (PublicProfilePage) + Phase 2 (serializer fix) |
| US-202 | AC2 | "Send Partner Request" button on available book listings | Deferred to Epic 5 (depends on Book + Exchange models) |
| US-202 | AC3 | "Report User" and "Block User" options | Deferred to Epic 8 (depends on Block/Report models) |
| US-202 | AC4 | Blocked user sees 404 | Deferred to Epic 8 (depends on Block model) |
| US-203 | AC1 | "Delete Account" in Settings with confirmation dialog | Phase 4 (DeleteAccountDialog + SettingsPage) |
| US-203 | AC2 | Re-enter password to confirm | Phase 2 (serializer) + Phase 4 (dialog) |
| US-203 | AC3 | Book listings removed immediately | Phase 2 (set `is_active=False` hides user from queries) |
| US-203 | AC4 | Personal data anonymized within 30 days | Phase 1 (field) + Phase 2 (Celery task) |
| US-203 | AC5 | Exchange history retained anonymized | Phase 2 (anonymization task preserves exchange rows) |
| US-203 | AC6 | Ratings given anonymized as "Former member" | Phase 2 (anonymization task) |
| US-203 | AC7 | Confirmation email sent | Phase 2 (Celery email task) |

**Edge Cases to handle**:

| Story | EC | Edge Case | Where to handle |
|-------|----|-----------|----------------|
| US-201 | EC1 | Display name taken → suggestions | Phase 2 (CheckUsernameView returns suggestions) + Phase 4 (form inline error) |
| US-201 | EC2 | Non-image file upload | Phase 2 (backend validation) + Phase 4 (frontend file type check) |
| US-201 | EC3 | Extremely large image → client-side resize | Phase 4 (AvatarUpload canvas resize before upload) |
| US-202 | EC1 | Deleted/deactivated user profile | Phase 4 (PublicProfilePage 404 → "no longer active" message) |
| US-202 | EC2 | User with 0 swaps/ratings → "New member" badge | Phase 4 (NewMemberBadge conditional display) |
| US-203 | EC1 | Active exchange blocks deletion | Phase 2 (AccountDeletionSerializer validates no active exchanges) |
| US-203 | EC2 | User cancels deletion within 30 days | Phase 2 (cancellation endpoint) + confirmation email link |

---

## 4. What's Not in This Plan

| Item | Reason |
|------|--------|
| US-202 AC2 — "Send Partner Request" button on book listings | Depends on Epic 3 (Book model) and Epic 5 (Exchange model) — will be implemented in those epics |
| US-202 AC3 — "Report User" and "Block User" options | Depends on Epic 8: Trust & Safety (Block/Report models) |
| US-202 AC4 — Blocked user sees 404 | Depends on Epic 8 Block model for query filtering |
| Listed books on public profile | Depends on Epic 3: Book Listing & Management |
| OAuth re-authentication for deletion | Full implementation requires Epic 1 OAuth exchange flow to be wired up. For now, password re-entry only; OAuth users will be handled once US-103 is fully complete. |

---

## 5. Suggested Commit Sequence

1. `feat(bookswap): add deletion_requested_at field + migration for GDPR soft-delete`
2. `feat(bookswap): add CheckUsername endpoint, avatar validation, and rating display logic`
3. `feat(bookswap): add account deletion request/cancel endpoints + anonymization Celery task`
4. `feat(profile): add useCheckUsername, useDeleteAccount hooks + API endpoint constants`
5. `feat(profile): build EditProfileForm with AvatarUpload and GenrePicker components`
6. `feat(profile): build PublicProfilePage with NewMemberBadge and deactivated-user handling`
7. `feat(profile): add DeleteAccountDialog to SettingsPage`
8. `test(bookswap): add acceptance-criteria tests for profile edit, public profile, and account deletion`
9. `chore(i18n): add en/nl translations for profile and account deletion strings`
